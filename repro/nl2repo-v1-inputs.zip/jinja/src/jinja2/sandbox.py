# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
F = ...
MAX_RANGE = ...
UNSAFE_FUNCTION_ATTRIBUTES = ...
UNSAFE_METHOD_ATTRIBUTES = ...
UNSAFE_GENERATOR_ATTRIBUTES = ...
UNSAFE_COROUTINE_ATTRIBUTES = ...
UNSAFE_ASYNC_GENERATOR_ATTRIBUTES = ...
_mutable_spec = ...

def safe_range(*args: int) -> range:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def unsafe(f: F) -> F:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def is_internal_attribute(obj: t.Any, attr: str) -> bool:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def modifies_known_mutable(obj: t.Any, attr: str) -> bool:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class SandboxedEnvironment:
    sandboxed = ...
    default_binop_table = ...
    default_unop_table = ...
    intercepted_binops = ...
    intercepted_unops = ...

    def __init__(self, *args: t.Any, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def is_safe_attribute(self, obj: t.Any, attr: str, value: t.Any) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def is_safe_callable(self, obj: t.Any) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def call_binop(self, context: Context, operator: str, left: t.Any, right: t.Any) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def call_unop(self, context: Context, operator: str, arg: t.Any) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getitem(self, obj: t.Any, argument: str | t.Any) -> t.Any | Undefined:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getattr(self, obj: t.Any, attribute: str) -> t.Any | Undefined:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def unsafe_undefined(self, obj: t.Any, attribute: str) -> Undefined:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def wrap_str_format(self, value: t.Any) -> t.Callable[..., str] | None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def call(__self, __context: Context, __obj: t.Any, *args: t.Any, **kwargs: t.Any) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class ImmutableSandboxedEnvironment:

    def is_safe_attribute(self, obj: t.Any, attr: str, value: t.Any) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class SandboxedFormatter:

    def __init__(self, env: Environment, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_field(self, field_name: str, args: t.Sequence[t.Any], kwargs: t.Mapping[str, t.Any]) -> tuple[t.Any, str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class SandboxedEscapeFormatter:
    pass
