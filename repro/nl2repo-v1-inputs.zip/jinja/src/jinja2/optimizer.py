# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

def optimize(node: nodes.Node, environment: 'Environment') -> nodes.Node:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class Optimizer:

    def __init__(self, environment: 'Environment | None') -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def generic_visit(self, node: nodes.Node, *args: t.Any, **kwargs: t.Any) -> nodes.Node:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
