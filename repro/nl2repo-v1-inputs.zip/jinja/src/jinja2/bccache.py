# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class _MemcachedClient:

    def get(self, key: str) -> bytes:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def set(self, key: str, value: bytes, timeout: int | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
bc_version = ...
bc_magic = ...

class Bucket:

    def __init__(self, environment: 'Environment', key: str, checksum: str) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def reset(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def load_bytecode(self, f: t.BinaryIO) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write_bytecode(self, f: t.IO[bytes]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def bytecode_from_string(self, string: bytes) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def bytecode_to_string(self) -> bytes:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class BytecodeCache:

    def load_bytecode(self, bucket: Bucket) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dump_bytecode(self, bucket: Bucket) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def clear(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_cache_key(self, name: str, filename: str | None=...) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_source_checksum(self, source: str) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_bucket(self, environment: 'Environment', name: str, filename: str | None, source: str) -> Bucket:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def set_bucket(self, bucket: Bucket) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class FileSystemBytecodeCache:

    def __init__(self, directory: str | None=..., pattern: str=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_default_cache_dir(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_cache_filename(self, bucket: Bucket) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def load_bytecode(self, bucket: Bucket) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dump_bytecode(self, bucket: Bucket) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def clear(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class MemcachedBytecodeCache:

    def __init__(self, client: '_MemcachedClient', prefix: str=..., timeout: int | None=..., ignore_memcache_errors: bool=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def load_bytecode(self, bucket: Bucket) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dump_bytecode(self, bucket: Bucket) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
