# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

def split_template_path(template: str) -> list[str]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class BaseLoader:
    has_source_access = ...

    def get_source(self, environment: 'Environment', template: str) -> tuple[str, str | None, t.Callable[[], bool] | None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def list_templates(self) -> list[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def load(self, environment: 'Environment', name: str, globals: t.MutableMapping[str, t.Any] | None=...) -> 'Template':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class FileSystemLoader:

    def __init__(self, searchpath: t.Union[str, 'os.PathLike[str]', t.Sequence[t.Union[str, 'os.PathLike[str]']]], encoding: str=..., followlinks: bool=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_source(self, environment: 'Environment', template: str) -> tuple[str, str, t.Callable[[], bool]]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def list_templates(self) -> list[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_zipimporter_files(z: t.Any) -> dict[str, object]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_zipimporter_files(z: t.Any) -> dict[str, object]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class PackageLoader:

    def __init__(self, package_name: str, package_path: 'str'=..., encoding: str=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_source(self, environment: 'Environment', template: str) -> tuple[str, str, t.Callable[[], bool] | None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def list_templates(self) -> list[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class DictLoader:

    def __init__(self, mapping: t.Mapping[str, str]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_source(self, environment: 'Environment', template: str) -> tuple[str, None, t.Callable[[], bool]]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def list_templates(self) -> list[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class FunctionLoader:

    def __init__(self, load_func: t.Callable[[str], str | tuple[str, str | None, t.Callable[[], bool] | None] | None]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_source(self, environment: 'Environment', template: str) -> tuple[str, str | None, t.Callable[[], bool] | None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class PrefixLoader:

    def __init__(self, mapping: t.Mapping[str, BaseLoader], delimiter: str=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_loader(self, template: str) -> tuple[BaseLoader, str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_source(self, environment: 'Environment', template: str) -> tuple[str, str | None, t.Callable[[], bool] | None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def load(self, environment: 'Environment', name: str, globals: t.MutableMapping[str, t.Any] | None=...) -> 'Template':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def list_templates(self) -> list[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class ChoiceLoader:

    def __init__(self, loaders: t.Sequence[BaseLoader]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_source(self, environment: 'Environment', template: str) -> tuple[str, str | None, t.Callable[[], bool] | None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def load(self, environment: 'Environment', name: str, globals: t.MutableMapping[str, t.Any] | None=...) -> 'Template':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def list_templates(self) -> list[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class _TemplateModule:
    pass

class ModuleLoader:
    has_source_access = ...

    def __init__(self, path: t.Union[str, 'os.PathLike[str]', t.Sequence[t.Union[str, 'os.PathLike[str]']]]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_template_key(name: str) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_module_filename(name: str) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def load(self, environment: 'Environment', name: str, globals: t.MutableMapping[str, t.Any] | None=...) -> 'Template':
        raise NotImplementedError('NL2Repo skeleton: implement this API')
