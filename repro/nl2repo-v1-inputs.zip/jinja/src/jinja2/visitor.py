# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class VisitCallable:

    def __call__(self, node: Node, *args: t.Any, **kwargs: t.Any) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class NodeVisitor:

    def get_visitor(self, node: Node) -> 'VisitCallable | None':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit(self, node: Node, *args: t.Any, **kwargs: t.Any) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def generic_visit(self, node: Node, *args: t.Any, **kwargs: t.Any) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class NodeTransformer:

    def generic_visit(self, node: Node, *args: t.Any, **kwargs: t.Any) -> Node:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_list(self, node: Node, *args: t.Any, **kwargs: t.Any) -> list[Node]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
