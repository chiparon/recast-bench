# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

def native_concat(values: t.Iterable[t.Any]) -> t.Any | None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class NativeCodeGenerator:

    def _default_finalize(value: t.Any) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _output_const_repr(self, group: t.Iterable[t.Any]) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _output_child_to_const(self, node: nodes.Expr, frame: Frame, finalize: CodeGenerator._FinalizeInfo) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _output_child_pre(self, node: nodes.Expr, frame: Frame, finalize: CodeGenerator._FinalizeInfo) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _output_child_post(self, node: nodes.Expr, frame: Frame, finalize: CodeGenerator._FinalizeInfo) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class NativeEnvironment:
    code_generator_class = ...
    concat = ...

class NativeTemplate:
    environment_class = ...

    def render(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def render_async(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
NativeEnvironment = ...
