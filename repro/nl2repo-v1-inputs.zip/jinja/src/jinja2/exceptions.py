# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class TemplateError:

    def __init__(self, message: str | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def message(self) -> str | None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TemplateNotFound:
    message = ...

    def __init__(self, name: t.Union[str, 'Undefined'] | None, message: str | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TemplatesNotFound:

    def __init__(self, names: t.Sequence[t.Union[str, 'Undefined']]=..., message: str | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TemplateSyntaxError:

    def __init__(self, message: str, lineno: int, name: str | None=..., filename: str | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __reduce__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TemplateAssertionError:
    pass

class TemplateRuntimeError:
    pass

class UndefinedError:
    pass

class SecurityError:
    pass

class FilterArgumentError:
    pass
