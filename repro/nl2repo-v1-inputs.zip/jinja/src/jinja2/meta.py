# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class TrackingCodeGenerator:

    def __init__(self, environment: 'Environment') -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write(self, x: str) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def enter_frame(self, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def find_undeclared_variables(ast: nodes.Template) -> set[str]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_ref_types = ...
_RefType = ...

def find_referenced_templates(ast: nodes.Template) -> t.Iterator[str | None]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
