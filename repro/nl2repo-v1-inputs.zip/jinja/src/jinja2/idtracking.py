# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
VAR_LOAD_PARAMETER = ...
VAR_LOAD_RESOLVE = ...
VAR_LOAD_ALIAS = ...
VAR_LOAD_UNDEFINED = ...

def find_symbols(nodes: t.Iterable[nodes.Node], parent_symbols: t.Optional['Symbols']=...) -> 'Symbols':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def symbols_for_node(node: nodes.Node, parent_symbols: t.Optional['Symbols']=...) -> 'Symbols':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class Symbols:

    def __init__(self, parent: t.Optional['Symbols']=..., level: int | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def analyze_node(self, node: nodes.Node, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _define_ref(self, name: str, load: tuple[str, str | None] | None=...) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def find_load(self, target: str) -> t.Any | None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def find_ref(self, name: str) -> str | None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def ref(self, name: str) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def copy(self) -> 'te.Self':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def store(self, name: str) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def declare_parameter(self, name: str) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def load(self, name: str) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def branch_update(self, branch_symbols: t.Sequence['Symbols']) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dump_stores(self) -> dict[str, str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dump_param_targets(self) -> set[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class RootVisitor:

    def __init__(self, symbols: 'Symbols') -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _simple_visit(self, node: nodes.Node, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    visit_Template = ...
    visit_Block = ...
    visit_Macro = ...
    visit_FilterBlock = ...
    visit_Scope = ...
    visit_If = ...
    visit_ScopedEvalContextModifier = ...

    def visit_AssignBlock(self, node: nodes.AssignBlock, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_CallBlock(self, node: nodes.CallBlock, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_OverlayScope(self, node: nodes.OverlayScope, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_For(self, node: nodes.For, for_branch: str=..., **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_With(self, node: nodes.With, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def generic_visit(self, node: nodes.Node, *args: t.Any, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class FrameSymbolVisitor:

    def __init__(self, symbols: 'Symbols') -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Name(self, node: nodes.Name, store_as_param: bool=..., **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_NSRef(self, node: nodes.NSRef, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_If(self, node: nodes.If, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Macro(self, node: nodes.Macro, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Import(self, node: nodes.Import, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_FromImport(self, node: nodes.FromImport, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Assign(self, node: nodes.Assign, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_For(self, node: nodes.For, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_CallBlock(self, node: nodes.CallBlock, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_FilterBlock(self, node: nodes.FilterBlock, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_With(self, node: nodes.With, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_AssignBlock(self, node: nodes.AssignBlock, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Scope(self, node: nodes.Scope, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Block(self, node: nodes.Block, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_OverlayScope(self, node: nodes.OverlayScope, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
