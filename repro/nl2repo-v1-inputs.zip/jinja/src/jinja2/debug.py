# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

def rewrite_traceback_stack(source: str | None=...) -> BaseException:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def fake_traceback(exc_value: BaseException, tb: TracebackType | None, filename: str, lineno: int) -> TracebackType:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def get_template_locals(real_locals: t.Mapping[str, t.Any]) -> dict[str, t.Any]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
