# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class _TranslationsBasic:

    def gettext(self, message: str) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def ngettext(self, singular: str, plural: str, n: int) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class _TranslationsContext:

    def pgettext(self, context: str, message: str) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def npgettext(self, context: str, singular: str, plural: str, n: int) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
_SupportedTranslations = ...
GETTEXT_FUNCTIONS = ...
_ws_re = ...

class Extension:
    identifier = ...

    def __init_subclass__(cls) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    tags = ...
    priority = ...

    def __init__(self, environment: Environment) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def bind(self, environment: Environment) -> 'te.Self':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def preprocess(self, source: str, name: str | None, filename: str | None=...) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def filter_stream(self, stream: 'TokenStream') -> t.Union['TokenStream', t.Iterable['Token']]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse(self, parser: 'Parser') -> nodes.Node | list[nodes.Node]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def attr(self, name: str, lineno: int | None=...) -> nodes.ExtensionAttribute:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def call_method(self, name: str, args: list[nodes.Expr] | None=..., kwargs: list[nodes.Keyword] | None=..., dyn_args: nodes.Expr | None=..., dyn_kwargs: nodes.Expr | None=..., lineno: int | None=...) -> nodes.Call:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def _gettext_alias(__context: Context, *args: t.Any, **kwargs: t.Any) -> t.Any | Undefined:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _make_new_gettext(func: t.Callable[[str], str]) -> t.Callable[..., str]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _make_new_ngettext(func: t.Callable[[str, str, int], str]) -> t.Callable[..., str]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _make_new_pgettext(func: t.Callable[[str, str], str]) -> t.Callable[..., str]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _make_new_npgettext(func: t.Callable[[str, str, str, int], str]) -> t.Callable[..., str]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class InternationalizationExtension:
    tags = ...

    def __init__(self, environment: Environment) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _install(self, translations: '_SupportedTranslations', newstyle: bool | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _install_null(self, newstyle: bool | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _install_callables(self, gettext: t.Callable[[str], str], ngettext: t.Callable[[str, str, int], str], newstyle: bool | None=..., pgettext: t.Callable[[str, str], str] | None=..., npgettext: t.Callable[[str, str, str, int], str] | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _uninstall(self, translations: '_SupportedTranslations') -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _extract(self, source: str | nodes.Template, gettext_functions: t.Sequence[str]=...) -> t.Iterator[tuple[int, str, str | None | tuple[str | None, ...]]]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse(self, parser: 'Parser') -> nodes.Node | list[nodes.Node]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _trim_whitespace(self, string: str, _ws_re: t.Pattern[str]=...) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _parse_block(self, parser: 'Parser', allow_pluralize: bool) -> tuple[list[str], str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _make_node(self, singular: str, plural: str | None, context: str | None, variables: dict[str, nodes.Expr], plural_expr: nodes.Expr | None, vars_referenced: bool, num_called_num: bool) -> nodes.Output:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class ExprStmtExtension:
    tags = ...

    def parse(self, parser: 'Parser') -> nodes.ExprStmt:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class LoopControlExtension:
    tags = ...

    def parse(self, parser: 'Parser') -> nodes.Break | nodes.Continue:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class DebugExtension:
    tags = ...

    def parse(self, parser: 'Parser') -> nodes.Output:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _render(self, context: Context) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def extract_from_ast(ast: nodes.Template, gettext_functions: t.Sequence[str]=..., babel_style: bool=...) -> t.Iterator[tuple[int, str, str | None | tuple[str | None, ...]]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class _CommentFinder:

    def __init__(self, tokens: t.Sequence[tuple[int, str, str]], comment_tags: t.Sequence[str]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def find_backwards(self, offset: int) -> list[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def find_comments(self, lineno: int) -> list[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def babel_extract(fileobj: t.BinaryIO, keywords: t.Sequence[str], comment_tags: t.Sequence[str], options: dict[str, t.Any]) -> t.Iterator[tuple[int, str, str | None | tuple[str | None, ...], list[str]]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
i18n = ...
do = ...
loopcontrols = ...
debug = ...
