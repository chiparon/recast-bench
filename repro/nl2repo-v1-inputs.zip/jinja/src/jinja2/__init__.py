# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

def __getattr__(name: str) -> t.Any:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
