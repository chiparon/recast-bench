# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
F = ...

class _MissingType:

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __reduce__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
missing = ...
internal_code = ...
concat = ...

def pass_context(f: F) -> F:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def pass_eval_context(f: F) -> F:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def pass_environment(f: F) -> F:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class _PassArg:
    context = ...
    eval_context = ...
    environment = ...

    def from_obj(cls, obj: F) -> t.Optional['_PassArg']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def internalcode(f: F) -> F:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def is_undefined(obj: t.Any) -> bool:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def consume(iterable: t.Iterable[t.Any]) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def clear_caches() -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def import_string(import_name: str, silent: bool=...) -> t.Any:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def open_if_exists(filename: str, mode: str=...) -> t.IO[t.Any] | None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def object_type_repr(obj: t.Any) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def pformat(obj: t.Any) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_http_re = ...
_email_re = ...

def urlize(text: str, trim_url_limit: int | None=..., rel: str | None=..., target: str | None=..., extra_schemes: t.Iterable[str] | None=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def generate_lorem_ipsum(n: int=..., html: bool=..., min: int=..., max: int=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def url_quote(obj: t.Any, charset: str=..., for_qs: bool=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class LRUCache:

    def __init__(self, capacity: int) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _postinit(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getstate__(self) -> t.Mapping[str, t.Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __setstate__(self, d: t.Mapping[str, t.Any]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getnewargs__(self) -> tuple[t.Any, ...]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def copy(self) -> 'te.Self':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get(self, key: t.Any, default: t.Any=...) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def setdefault(self, key: t.Any, default: t.Any=...) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def clear(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __contains__(self, key: t.Any) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, key: t.Any) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __setitem__(self, key: t.Any, value: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __delitem__(self, key: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def items(self) -> t.Iterable[tuple[t.Any, t.Any]]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def values(self) -> t.Iterable[t.Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def keys(self) -> t.Iterable[t.Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self) -> t.Iterator[t.Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __reversed__(self) -> t.Iterator[t.Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __copy__ = ...

def select_autoescape(enabled_extensions: t.Collection[str]=..., disabled_extensions: t.Collection[str]=..., default_for_string: bool=..., default: bool=...) -> t.Callable[[str | None], bool]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def htmlsafe_json_dumps(obj: t.Any, dumps: t.Callable[..., str] | None=..., **kwargs: t.Any) -> markupsafe.Markup:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class Cycler:

    def __init__(self, *items: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def reset(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def current(self) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def next(self) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __next__ = ...

class Joiner:

    def __init__(self, sep: str=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __call__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Namespace:

    def __init__(*args: t.Any, **kwargs: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getattribute__(self, name: str) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __setitem__(self, name: str, value: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
