# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
V = ...

def async_variant(normal_func):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_common_primitives = ...

async def auto_await(value: t.Union[t.Awaitable['V'], 'V']) -> 'V':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class _IteratorToAsyncIterator:

    def __init__(self, iterator: 't.Iterator[V]'):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __aiter__(self) -> 'te.Self':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def __anext__(self) -> V:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def auto_aiter(iterable: 't.AsyncIterable[V] | t.Iterable[V]') -> 't.AsyncIterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def auto_to_list(value: 't.AsyncIterable[V] | t.Iterable[V]') -> list['V']:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
