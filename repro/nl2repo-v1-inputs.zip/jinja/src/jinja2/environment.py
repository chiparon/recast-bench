# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
_env_bound = ...

def get_spontaneous_environment(cls: type[_env_bound], *args: t.Any) -> _env_bound:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def create_cache(size: int) -> t.MutableMapping[tuple['weakref.ref[BaseLoader]', str], 'Template'] | None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def copy_cache(cache: t.MutableMapping[tuple['weakref.ref[BaseLoader]', str], 'Template'] | None) -> t.MutableMapping[tuple['weakref.ref[BaseLoader]', str], 'Template'] | None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def load_extensions(environment: 'Environment', extensions: t.Sequence[str | type['Extension']]) -> dict[str, 'Extension']:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _environment_config_check(environment: _env_bound) -> _env_bound:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class Environment:
    sandboxed = ...
    overlayed = ...
    linked_to = ...
    shared = ...
    code_generator_class = ...
    concat = ...
    context_class = ...
    template_class = ...

    def __init__(self, block_start_string: str=..., block_end_string: str=..., variable_start_string: str=..., variable_end_string: str=..., comment_start_string: str=..., comment_end_string: str=..., line_statement_prefix: str | None=..., line_comment_prefix: str | None=..., trim_blocks: bool=..., lstrip_blocks: bool=..., newline_sequence: "te.Literal['\\n', '\\r\\n', '\\r']"=..., keep_trailing_newline: bool=..., extensions: t.Sequence[str | type['Extension']]=..., optimized: bool=..., undefined: type[Undefined]=..., finalize: t.Callable[..., t.Any] | None=..., autoescape: bool | t.Callable[[str | None], bool]=..., loader: t.Optional['BaseLoader']=..., cache_size: int=..., auto_reload: bool=..., bytecode_cache: t.Optional['BytecodeCache']=..., enable_async: bool=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add_extension(self, extension: str | type['Extension']) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def extend(self, **attributes: t.Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def overlay(self, block_start_string: str=..., block_end_string: str=..., variable_start_string: str=..., variable_end_string: str=..., comment_start_string: str=..., comment_end_string: str=..., line_statement_prefix: str | None=..., line_comment_prefix: str | None=..., trim_blocks: bool=..., lstrip_blocks: bool=..., newline_sequence: "te.Literal['\\n', '\\r\\n', '\\r']"=..., keep_trailing_newline: bool=..., extensions: t.Sequence[str | type['Extension']]=..., optimized: bool=..., undefined: type[Undefined]=..., finalize: t.Callable[..., t.Any] | None=..., autoescape: bool | t.Callable[[str | None], bool]=..., loader: t.Optional['BaseLoader']=..., cache_size: int=..., auto_reload: bool=..., bytecode_cache: t.Optional['BytecodeCache']=..., enable_async: bool=...) -> 'te.Self':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def lexer(self) -> Lexer:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def iter_extensions(self) -> t.Iterator['Extension']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getitem(self, obj: t.Any, argument: str | t.Any) -> t.Any | Undefined:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getattr(self, obj: t.Any, attribute: str) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _filter_test_common(self, name: str | Undefined, value: t.Any, args: t.Sequence[t.Any] | None, kwargs: t.Mapping[str, t.Any] | None, context: Context | None, eval_ctx: EvalContext | None, is_filter: bool) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def call_filter(self, name: str, value: t.Any, args: t.Sequence[t.Any] | None=..., kwargs: t.Mapping[str, t.Any] | None=..., context: Context | None=..., eval_ctx: EvalContext | None=...) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def call_test(self, name: str, value: t.Any, args: t.Sequence[t.Any] | None=..., kwargs: t.Mapping[str, t.Any] | None=..., context: Context | None=..., eval_ctx: EvalContext | None=...) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse(self, source: str, name: str | None=..., filename: str | None=...) -> nodes.Template:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _parse(self, source: str, name: str | None, filename: str | None) -> nodes.Template:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def lex(self, source: str, name: str | None=..., filename: str | None=...) -> t.Iterator[tuple[int, str, str]]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def preprocess(self, source: str, name: str | None=..., filename: str | None=...) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _tokenize(self, source: str, name: str | None, filename: str | None=..., state: str | None=...) -> TokenStream:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _generate(self, source: nodes.Template, name: str | None, filename: str | None, defer_init: bool=...) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _compile(self, source: str, filename: str) -> CodeType:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def compile(self, source: str | nodes.Template, name: str | None=..., filename: str | None=..., raw: 'te.Literal[False]'=..., defer_init: bool=...) -> CodeType:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def compile(self, source: str | nodes.Template, name: str | None=..., filename: str | None=..., raw: 'te.Literal[True]'=..., defer_init: bool=...) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def compile(self, source: str | nodes.Template, name: str | None=..., filename: str | None=..., raw: bool=..., defer_init: bool=...) -> str | CodeType:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def compile_expression(self, source: str, undefined_to_none: bool=...) -> 'TemplateExpression':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def compile_templates(self, target: t.Union[str, 'os.PathLike[str]'], extensions: t.Collection[str] | None=..., filter_func: t.Callable[[str], bool] | None=..., zip: str | None=..., log_function: t.Callable[[str], None] | None=..., ignore_errors: bool=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def list_templates(self, extensions: t.Collection[str] | None=..., filter_func: t.Callable[[str], bool] | None=...) -> list[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def handle_exception(self, source: str | None=...) -> 'te.NoReturn':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def join_path(self, template: str, parent: str) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _load_template(self, name: str, globals: t.MutableMapping[str, t.Any] | None) -> 'Template':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_template(self, name: t.Union[str, 'Template'], parent: str | None=..., globals: t.MutableMapping[str, t.Any] | None=...) -> 'Template':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def select_template(self, names: t.Iterable[t.Union[str, 'Template']], parent: str | None=..., globals: t.MutableMapping[str, t.Any] | None=...) -> 'Template':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_or_select_template(self, template_name_or_list: t.Union[str, 'Template', list[t.Union[str, 'Template']]], parent: str | None=..., globals: t.MutableMapping[str, t.Any] | None=...) -> 'Template':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_string(self, source: str | nodes.Template, globals: t.MutableMapping[str, t.Any] | None=..., template_class: type['Template'] | None=...) -> 'Template':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def make_globals(self, d: t.MutableMapping[str, t.Any] | None) -> t.MutableMapping[str, t.Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Template:
    environment_class = ...
    environment = ...
    globals = ...
    name = ...
    filename = ...
    blocks = ...
    root_render_func = ...
    _module = ...
    _debug_info = ...
    _uptodate = ...

    def __new__(cls, source: str | nodes.Template, block_start_string: str=..., block_end_string: str=..., variable_start_string: str=..., variable_end_string: str=..., comment_start_string: str=..., comment_end_string: str=..., line_statement_prefix: str | None=..., line_comment_prefix: str | None=..., trim_blocks: bool=..., lstrip_blocks: bool=..., newline_sequence: "te.Literal['\\n', '\\r\\n', '\\r']"=..., keep_trailing_newline: bool=..., extensions: t.Sequence[str | type['Extension']]=..., optimized: bool=..., undefined: type[Undefined]=..., finalize: t.Callable[..., t.Any] | None=..., autoescape: bool | t.Callable[[str | None], bool]=..., enable_async: bool=...) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_code(cls, environment: Environment, code: CodeType, globals: t.MutableMapping[str, t.Any], uptodate: t.Callable[[], bool] | None=...) -> 'Template':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_module_dict(cls, environment: Environment, module_dict: t.MutableMapping[str, t.Any], globals: t.MutableMapping[str, t.Any]) -> 'Template':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_namespace(cls, environment: Environment, namespace: t.MutableMapping[str, t.Any], globals: t.MutableMapping[str, t.Any]) -> 'Template':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def render(self, *args: t.Any, **kwargs: t.Any) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def render_async(self, *args: t.Any, **kwargs: t.Any) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def stream(self, *args: t.Any, **kwargs: t.Any) -> 'TemplateStream':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def generate(self, *args: t.Any, **kwargs: t.Any) -> t.Iterator[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def generate_async(self, *args: t.Any, **kwargs: t.Any) -> t.AsyncGenerator[str, object]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def new_context(self, vars: dict[str, t.Any] | None=..., shared: bool=..., locals: t.Mapping[str, t.Any] | None=...) -> Context:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def make_module(self, vars: dict[str, t.Any] | None=..., shared: bool=..., locals: t.Mapping[str, t.Any] | None=...) -> 'TemplateModule':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def make_module_async(self, vars: dict[str, t.Any] | None=..., shared: bool=..., locals: t.Mapping[str, t.Any] | None=...) -> 'TemplateModule':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_default_module(self, ctx: Context | None=...) -> 'TemplateModule':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def _get_default_module_async(self, ctx: Context | None=...) -> 'TemplateModule':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def module(self) -> 'TemplateModule':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_corresponding_lineno(self, lineno: int) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def is_up_to_date(self) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def debug_info(self) -> list[tuple[int, int]]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TemplateModule:

    def __init__(self, template: Template, context: Context, body_stream: t.Iterable[str] | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __html__(self) -> Markup:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TemplateExpression:

    def __init__(self, template: Template, undefined_to_none: bool) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __call__(self, *args: t.Any, **kwargs: t.Any) -> t.Any | None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TemplateStream:

    def __init__(self, gen: t.Iterator[str]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dump(self, fp: str | t.IO[bytes], encoding: str | None=..., errors: str | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def disable_buffering(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _buffered_generator(self, size: int) -> t.Iterator[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def enable_buffering(self, size: int=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self) -> 'TemplateStream':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __next__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
Environment = ...
