# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
_ImportInclude = ...
_MacroCall = ...
_statement_keywords = ...
_compare_operators = ...
_math_nodes = ...

class Parser:

    def __init__(self, environment: 'Environment', source: str, name: str | None=..., filename: str | None=..., state: str | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def fail(self, msg: str, lineno: int | None=..., exc: type[TemplateSyntaxError]=...) -> 'te.NoReturn':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _fail_ut_eof(self, name: str | None, end_token_stack: list[tuple[str, ...]], lineno: int | None) -> 'te.NoReturn':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def fail_unknown_tag(self, name: str, lineno: int | None=...) -> 'te.NoReturn':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def fail_eof(self, end_tokens: tuple[str, ...] | None=..., lineno: int | None=...) -> 'te.NoReturn':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def is_tuple_end(self, extra_end_rules: tuple[str, ...] | None=...) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def free_identifier(self, lineno: int | None=...) -> nodes.InternalName:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_statement(self) -> nodes.Node | list[nodes.Node]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_statements(self, end_tokens: tuple[str, ...], drop_needle: bool=...) -> list[nodes.Node]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_set(self) -> nodes.Assign | nodes.AssignBlock:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_for(self) -> nodes.For:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_if(self) -> nodes.If:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_with(self) -> nodes.With:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_autoescape(self) -> nodes.Scope:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_block(self) -> nodes.Block:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_extends(self) -> nodes.Extends:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_import_context(self, node: _ImportInclude, default: bool) -> _ImportInclude:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_include(self) -> nodes.Include:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_import(self) -> nodes.Import:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_from(self) -> nodes.FromImport:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_signature(self, node: _MacroCall) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_call_block(self) -> nodes.CallBlock:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_filter_block(self) -> nodes.FilterBlock:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_macro(self) -> nodes.Macro:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_print(self) -> nodes.Output:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_assign_target(self, with_tuple: bool=..., name_only: 'te.Literal[True]'=...) -> nodes.Name:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_assign_target(self, with_tuple: bool=..., name_only: bool=..., extra_end_rules: tuple[str, ...] | None=..., with_namespace: bool=...) -> nodes.NSRef | nodes.Name | nodes.Tuple:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_assign_target(self, with_tuple: bool=..., name_only: bool=..., extra_end_rules: tuple[str, ...] | None=..., with_namespace: bool=...) -> nodes.NSRef | nodes.Name | nodes.Tuple:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_expression(self, with_condexpr: bool=...) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_condexpr(self) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_or(self) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_and(self) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_not(self) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_compare(self) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_math1(self) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_concat(self) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_math2(self) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_pow(self) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_unary(self, with_filter: bool=...) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_primary(self, with_namespace: bool=...) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_tuple(self, simplified: bool=..., with_condexpr: bool=..., extra_end_rules: tuple[str, ...] | None=..., explicit_parentheses: bool=..., with_namespace: bool=...) -> nodes.Tuple | nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_list(self) -> nodes.List:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_dict(self) -> nodes.Dict:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_postfix(self, node: nodes.Expr) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_filter_expr(self, node: nodes.Expr) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_subscript(self, node: nodes.Expr) -> nodes.Getattr | nodes.Getitem:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_subscribed(self) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_call_args(self) -> tuple[list[nodes.Expr], list[nodes.Keyword], nodes.Expr | None, nodes.Expr | None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_call(self, node: nodes.Expr) -> nodes.Call:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_filter(self, node: nodes.Expr | None, start_inline: bool=...) -> nodes.Expr | None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse_test(self, node: nodes.Expr) -> nodes.Expr:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def subparse(self, end_tokens: tuple[str, ...] | None=...) -> list[nodes.Node]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parse(self) -> nodes.Template:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
