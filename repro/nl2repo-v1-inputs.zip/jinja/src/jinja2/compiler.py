# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
F = ...
operators = ...

def optimizeconst(f: F) -> F:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _make_binop(op: str) -> t.Callable[['CodeGenerator', nodes.BinExpr, 'Frame'], None]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _make_unop(op: str) -> t.Callable[['CodeGenerator', nodes.UnaryExpr, 'Frame'], None]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def generate(node: nodes.Template, environment: 'Environment', name: str | None, filename: str | None, stream: t.TextIO | None=..., defer_init: bool=..., optimized: bool=...) -> str | None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def has_safe_repr(value: t.Any) -> bool:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def find_undeclared(nodes: t.Iterable[nodes.Node], names: t.Iterable[str]) -> set[str]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class MacroRef:

    def __init__(self, node: nodes.Macro | nodes.CallBlock) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Frame:

    def __init__(self, eval_ctx: EvalContext, parent: t.Optional['Frame']=..., level: int | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def copy(self) -> 'te.Self':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def inner(self, isolated: bool=...) -> 'Frame':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def soft(self) -> 'te.Self':
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __copy__ = ...

class VisitorExit:
    pass

class DependencyFinderVisitor:

    def __init__(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Filter(self, node: nodes.Filter) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Test(self, node: nodes.Test) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Block(self, node: nodes.Block) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class UndeclaredNameVisitor:

    def __init__(self, names: t.Iterable[str]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Name(self, node: nodes.Name) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Block(self, node: nodes.Block) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class CompilerExit:
    pass

class CodeGenerator:

    def __init__(self, environment: 'Environment', name: str | None, filename: str | None, stream: t.TextIO | None=..., defer_init: bool=..., optimized: bool=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def optimized(self) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def fail(self, msg: str, lineno: int) -> 'te.NoReturn':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def temporary_identifier(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def buffer(self, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def return_buffer_contents(self, frame: Frame, force_unescaped: bool=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def indent(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def outdent(self, step: int=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def start_write(self, frame: Frame, node: nodes.Node | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def end_write(self, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def simple_write(self, s: str, frame: Frame, node: nodes.Node | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def blockvisit(self, nodes: t.Iterable[nodes.Node], frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write(self, x: str) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def writeline(self, x: str, node: nodes.Node | None=..., extra: int=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def newline(self, node: nodes.Node | None=..., extra: int=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def signature(self, node: nodes.Call | nodes.Filter | nodes.Test, frame: Frame, extra_kwargs: t.Mapping[str, t.Any] | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pull_dependencies(self, nodes: t.Iterable[nodes.Node]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def enter_frame(self, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def leave_frame(self, frame: Frame, with_python_scope: bool=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def choose_async(self, async_value: str=..., sync_value: str=...) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def func(self, name: str) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def macro_body(self, node: nodes.Macro | nodes.CallBlock, frame: Frame) -> tuple[Frame, MacroRef]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def macro_def(self, macro_ref: MacroRef, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def position(self, node: nodes.Node) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dump_local_context(self, frame: Frame) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write_commons(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def push_parameter_definitions(self, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pop_parameter_definitions(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def mark_parameter_stored(self, target: str) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def push_context_reference(self, target: str) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pop_context_reference(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_context_ref(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_resolve_func(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def derive_context(self, frame: Frame) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def parameter_is_undeclared(self, target: str) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def push_assign_tracking(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pop_assign_tracking(self, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Template(self, node: nodes.Template, frame: Frame | None=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Block(self, node: nodes.Block, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Extends(self, node: nodes.Extends, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Include(self, node: nodes.Include, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _import_common(self, node: nodes.Import | nodes.FromImport, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Import(self, node: nodes.Import, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_FromImport(self, node: nodes.FromImport, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_For(self, node: nodes.For, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_If(self, node: nodes.If, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Macro(self, node: nodes.Macro, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_CallBlock(self, node: nodes.CallBlock, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_FilterBlock(self, node: nodes.FilterBlock, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_With(self, node: nodes.With, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_ExprStmt(self, node: nodes.ExprStmt, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    class _FinalizeInfo:
        const = ...
        src = ...

    def _default_finalize(value: t.Any) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    _finalize = ...

    def _make_finalize(self) -> _FinalizeInfo:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _output_const_repr(self, group: t.Iterable[t.Any]) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _output_child_to_const(self, node: nodes.Expr, frame: Frame, finalize: _FinalizeInfo) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _output_child_pre(self, node: nodes.Expr, frame: Frame, finalize: _FinalizeInfo) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _output_child_post(self, node: nodes.Expr, frame: Frame, finalize: _FinalizeInfo) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Output(self, node: nodes.Output, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Assign(self, node: nodes.Assign, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_AssignBlock(self, node: nodes.AssignBlock, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Name(self, node: nodes.Name, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_NSRef(self, node: nodes.NSRef, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Const(self, node: nodes.Const, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_TemplateData(self, node: nodes.TemplateData, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Tuple(self, node: nodes.Tuple, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_List(self, node: nodes.List, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Dict(self, node: nodes.Dict, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    visit_Add = ...
    visit_Sub = ...
    visit_Mul = ...
    visit_Div = ...
    visit_FloorDiv = ...
    visit_Pow = ...
    visit_Mod = ...
    visit_And = ...
    visit_Or = ...
    visit_Pos = ...
    visit_Neg = ...
    visit_Not = ...

    def visit_Concat(self, node: nodes.Concat, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Compare(self, node: nodes.Compare, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Operand(self, node: nodes.Operand, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Getattr(self, node: nodes.Getattr, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Getitem(self, node: nodes.Getitem, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Slice(self, node: nodes.Slice, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _filter_test_common(self, node: nodes.Filter | nodes.Test, frame: Frame, is_filter: bool) -> t.Iterator[None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Filter(self, node: nodes.Filter, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Test(self, node: nodes.Test, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_CondExpr(self, node: nodes.CondExpr, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Call(self, node: nodes.Call, frame: Frame, forward_caller: bool=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Keyword(self, node: nodes.Keyword, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_MarkSafe(self, node: nodes.MarkSafe, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_MarkSafeIfAutoescape(self, node: nodes.MarkSafeIfAutoescape, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_EnvironmentAttribute(self, node: nodes.EnvironmentAttribute, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_ExtensionAttribute(self, node: nodes.ExtensionAttribute, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_ImportedName(self, node: nodes.ImportedName, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_InternalName(self, node: nodes.InternalName, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_ContextReference(self, node: nodes.ContextReference, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_DerivedContextReference(self, node: nodes.DerivedContextReference, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Continue(self, node: nodes.Continue, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Break(self, node: nodes.Break, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_Scope(self, node: nodes.Scope, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_OverlayScope(self, node: nodes.OverlayScope, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_EvalContextModifier(self, node: nodes.EvalContextModifier, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def visit_ScopedEvalContextModifier(self, node: nodes.ScopedEvalContextModifier, frame: Frame) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
