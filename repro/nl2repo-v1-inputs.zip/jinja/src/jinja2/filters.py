# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class HasHTML:

    def __html__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
F = ...
K = ...
V = ...

def ignore_case(value: V) -> V:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def make_attrgetter(environment: 'Environment', attribute: str | int | None, postprocess: t.Callable[[t.Any], t.Any] | None=..., default: t.Any | None=...) -> t.Callable[[t.Any], t.Any]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def make_multi_attrgetter(environment: 'Environment', attribute: str | int | None, postprocess: t.Callable[[t.Any], t.Any] | None=...) -> t.Callable[[t.Any], list[t.Any]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _prepare_attribute_parts(attr: str | int | None) -> list[str | int]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_forceescape(value: 'str | HasHTML') -> Markup:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_urlencode(value: str | t.Mapping[str, t.Any] | t.Iterable[tuple[str, t.Any]]) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_replace(eval_ctx: 'EvalContext', s: str, old: str, new: str, count: int | None=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_upper(s: str) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_lower(s: str) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_items(value: t.Mapping[K, V] | Undefined) -> t.Iterator[tuple[K, V]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_attr_key_re = ...

def do_xmlattr(eval_ctx: 'EvalContext', d: t.Mapping[str, t.Any], autospace: bool=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_capitalize(s: str) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_word_beginning_split_re = ...

def do_title(s: str) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_dictsort(value: t.Mapping[K, V], case_sensitive: bool=..., by: 'te.Literal["key", "value"]'=..., reverse: bool=...) -> list[tuple[K, V]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_sort(environment: 'Environment', value: 't.Iterable[V]', reverse: bool=..., case_sensitive: bool=..., attribute: str | int | None=...) -> 'list[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_unique(environment: 'Environment', value: 't.Iterable[V]', case_sensitive: bool=..., attribute: str | int | None=...) -> 't.Iterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def do_unique(environment: 'Environment', value: 't.AsyncIterable[V] | t.Iterable[V]', case_sensitive: bool=..., attribute: str | int | None=...) -> 't.Iterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _min_or_max(environment: 'Environment', value: 't.Iterable[V]', func: 't.Callable[..., V]', case_sensitive: bool, attribute: str | int | None) -> 'V | Undefined':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_min(environment: 'Environment', value: 't.Iterable[V]', case_sensitive: bool=..., attribute: str | int | None=...) -> 'V | Undefined':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_max(environment: 'Environment', value: 't.Iterable[V]', case_sensitive: bool=..., attribute: str | int | None=...) -> 'V | Undefined':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_default(value: V, default_value: V=..., boolean: bool=...) -> V:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_join(eval_ctx: 'EvalContext', value: t.Iterable[t.Any], d: str=..., attribute: str | int | None=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def do_join(eval_ctx: 'EvalContext', value: t.AsyncIterable[t.Any] | t.Iterable[t.Any], d: str=..., attribute: str | int | None=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_center(value: str, width: int=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_first(environment: 'Environment', seq: 't.Iterable[V]') -> 'V | Undefined':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def do_first(environment: 'Environment', seq: 't.AsyncIterable[V] | t.Iterable[V]') -> 'V | Undefined':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_last(environment: 'Environment', seq: 't.Reversible[V]') -> 'V | Undefined':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_random(context: 'Context', seq: 't.Sequence[V]') -> 'V | Undefined':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_filesizeformat(value: str | float | int, binary: bool=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_pprint(value: t.Any) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_uri_scheme_re = ...

def do_urlize(eval_ctx: 'EvalContext', value: str, trim_url_limit: int | None=..., nofollow: bool=..., target: str | None=..., rel: str | None=..., extra_schemes: t.Iterable[str] | None=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_indent(s: str, width: int | str=..., first: bool=..., blank: bool=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_truncate(env: 'Environment', s: str, length: int=..., killwords: bool=..., end: str=..., leeway: int | None=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_wordwrap(environment: 'Environment', s: str, width: int=..., break_long_words: bool=..., wrapstring: str | None=..., break_on_hyphens: bool=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_word_re = ...

def do_wordcount(s: str) -> int:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_int(value: t.Any, default: int=..., base: int=...) -> int:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_float(value: t.Any, default: float=...) -> float:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_format(value: str, *args: t.Any, **kwargs: t.Any) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_trim(value: str, chars: str | None=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_striptags(value: 'str | HasHTML') -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_slice(value: 't.Collection[V]', slices: int, fill_with: 'V | None'=...) -> 't.Iterator[list[V]]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def do_slice(value: 't.AsyncIterable[V] | t.Iterable[V]', slices: int, fill_with: t.Any | None=...) -> 't.Iterator[list[V]]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_batch(value: 't.Iterable[V]', linecount: int, fill_with: 'V | None'=...) -> 't.Iterator[list[V]]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_round(value: float, precision: int=..., method: 'te.Literal["common", "ceil", "floor"]'=...) -> float:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class _GroupTuple:
    grouper = ...
    list = ...

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_groupby(environment: 'Environment', value: 't.Iterable[V]', attribute: str | int, default: t.Any | None=..., case_sensitive: bool=...) -> 'list[_GroupTuple]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def do_groupby(environment: 'Environment', value: 't.AsyncIterable[V] | t.Iterable[V]', attribute: str | int, default: t.Any | None=..., case_sensitive: bool=...) -> 'list[_GroupTuple]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_sum(environment: 'Environment', iterable: 't.Iterable[V]', attribute: str | int | None=..., start: V=...) -> V:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def do_sum(environment: 'Environment', iterable: 't.AsyncIterable[V] | t.Iterable[V]', attribute: str | int | None=..., start: V=...) -> V:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_list(value: 't.Iterable[V]') -> 'list[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def do_list(value: 't.AsyncIterable[V] | t.Iterable[V]') -> 'list[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_mark_safe(value: str) -> Markup:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_mark_unsafe(value: str) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_reverse(value: str) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_reverse(value: 't.Iterable[V]') -> 't.Iterable[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_reverse(value: str | t.Iterable[V]) -> str | t.Iterable[V]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_attr(environment: 'Environment', obj: t.Any, name: str) -> Undefined | t.Any:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_map(context: 'Context', value: t.Iterable[t.Any], name: str, *args: t.Any, **kwargs: t.Any) -> t.Iterable[t.Any]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_map(context: 'Context', value: t.Iterable[t.Any], *, attribute: str=..., default: t.Any | None=...) -> t.Iterable[t.Any]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_map(context: 'Context', value: t.Iterable[t.Any], *args: t.Any, **kwargs: t.Any) -> t.Iterable[t.Any]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_map(context: 'Context', value: t.AsyncIterable[t.Any] | t.Iterable[t.Any], name: str, *args: t.Any, **kwargs: t.Any) -> t.Iterable[t.Any]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_map(context: 'Context', value: t.AsyncIterable[t.Any] | t.Iterable[t.Any], *, attribute: str=..., default: t.Any | None=...) -> t.Iterable[t.Any]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def do_map(context: 'Context', value: t.AsyncIterable[t.Any] | t.Iterable[t.Any], *args: t.Any, **kwargs: t.Any) -> t.AsyncIterable[t.Any]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_select(context: 'Context', value: 't.Iterable[V]', *args: t.Any, **kwargs: t.Any) -> 't.Iterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def do_select(context: 'Context', value: 't.AsyncIterable[V] | t.Iterable[V]', *args: t.Any, **kwargs: t.Any) -> 't.AsyncIterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_reject(context: 'Context', value: 't.Iterable[V]', *args: t.Any, **kwargs: t.Any) -> 't.Iterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def do_reject(context: 'Context', value: 't.AsyncIterable[V] | t.Iterable[V]', *args: t.Any, **kwargs: t.Any) -> 't.AsyncIterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_selectattr(context: 'Context', value: 't.Iterable[V]', *args: t.Any, **kwargs: t.Any) -> 't.Iterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def do_selectattr(context: 'Context', value: 't.AsyncIterable[V] | t.Iterable[V]', *args: t.Any, **kwargs: t.Any) -> 't.AsyncIterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sync_do_rejectattr(context: 'Context', value: 't.Iterable[V]', *args: t.Any, **kwargs: t.Any) -> 't.Iterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def do_rejectattr(context: 'Context', value: 't.AsyncIterable[V] | t.Iterable[V]', *args: t.Any, **kwargs: t.Any) -> 't.AsyncIterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def do_tojson(eval_ctx: 'EvalContext', value: t.Any, indent: int | None=...) -> Markup:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def prepare_map(context: 'Context', args: tuple[t.Any, ...], kwargs: dict[str, t.Any]) -> t.Callable[[t.Any], t.Any]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def prepare_select_or_reject(context: 'Context', args: tuple[t.Any, ...], kwargs: dict[str, t.Any], modfunc: t.Callable[[t.Any], t.Any], lookup_attr: bool) -> t.Callable[[t.Any], t.Any]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def select_or_reject(context: 'Context', value: 't.Iterable[V]', args: tuple[t.Any, ...], kwargs: dict[str, t.Any], modfunc: t.Callable[[t.Any], t.Any], lookup_attr: bool) -> 't.Iterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

async def async_select_or_reject(context: 'Context', value: 't.AsyncIterable[V] | t.Iterable[V]', args: tuple[t.Any, ...], kwargs: dict[str, t.Any], modfunc: t.Callable[[t.Any], t.Any], lookup_attr: bool) -> 't.AsyncIterator[V]':
    raise NotImplementedError('NL2Repo skeleton: implement this API')
FILTERS = ...
