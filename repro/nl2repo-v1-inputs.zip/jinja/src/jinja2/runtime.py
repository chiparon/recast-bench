# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
V = ...
F = ...

class LoopRenderFunc:

    def __call__(self, reciter: t.Iterable[V], loop_render_func: 'LoopRenderFunc', depth: int=...) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
exported = ...
async_exported = ...

def identity(x: V) -> V:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def markup_join(seq: t.Iterable[t.Any]) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def str_join(seq: t.Iterable[t.Any]) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def new_context(environment: 'Environment', template_name: str | None, blocks: dict[str, t.Callable[['Context'], t.Iterator[str]]], vars: dict[str, t.Any] | None=..., shared: bool=..., globals: t.MutableMapping[str, t.Any] | None=..., locals: t.Mapping[str, t.Any] | None=...) -> 'Context':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class TemplateReference:

    def __init__(self, context: 'Context') -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, name: str) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def _dict_method_all(dict_method: F) -> F:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class Context:

    def __init__(self, environment: 'Environment', parent: dict[str, t.Any], name: str | None, blocks: dict[str, t.Callable[['Context'], t.Iterator[str]]], globals: t.MutableMapping[str, t.Any] | None=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def super(self, name: str, current: t.Callable[['Context'], t.Iterator[str]]) -> t.Union['BlockReference', 'Undefined']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get(self, key: str, default: t.Any=...) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def resolve(self, key: str) -> t.Union[t.Any, 'Undefined']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def resolve_or_missing(self, key: str) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_exported(self) -> dict[str, t.Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_all(self) -> dict[str, t.Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def call(__self, __obj: t.Callable[..., t.Any], *args: t.Any, **kwargs: t.Any) -> t.Union[t.Any, 'Undefined']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def derived(self, locals: dict[str, t.Any] | None=...) -> 'Context':
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    keys = ...
    values = ...
    items = ...

    def __contains__(self, name: str) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, key: str) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class BlockReference:

    def __init__(self, name: str, context: 'Context', stack: list[t.Callable[['Context'], t.Iterator[str]]], depth: int) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def super(self) -> t.Union['BlockReference', 'Undefined']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def _async_call(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __call__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class LoopContext:
    index0 = ...
    _length = ...
    _after = ...
    _current = ...
    _before = ...
    _last_changed_value = ...

    def __init__(self, iterable: t.Iterable[V], undefined: type['Undefined'], recurse: t.Optional['LoopRenderFunc']=..., depth0: int=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _to_iterator(iterable: t.Iterable[V]) -> t.Iterator[V]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def length(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def depth(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def index(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def revindex0(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def revindex(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def first(self) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _peek_next(self) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def last(self) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def previtem(self) -> t.Union[t.Any, 'Undefined']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def nextitem(self) -> t.Union[t.Any, 'Undefined']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def cycle(self, *args: V) -> V:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def changed(self, *value: t.Any) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self) -> 'LoopContext':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __next__(self) -> tuple[t.Any, 'LoopContext']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __call__(self, iterable: t.Iterable[V]) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class AsyncLoopContext:
    _iterator = ...

    def _to_iterator(iterable: t.Iterable[V] | t.AsyncIterable[V]) -> t.AsyncIterator[V]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def length(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def revindex0(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def revindex(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def _peek_next(self) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def last(self) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def nextitem(self) -> t.Union[t.Any, 'Undefined']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __aiter__(self) -> 'AsyncLoopContext':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def __anext__(self) -> tuple[t.Any, 'AsyncLoopContext']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Macro:

    def __init__(self, environment: 'Environment', func: t.Callable[..., str], name: str, arguments: list[str], catch_kwargs: bool, catch_varargs: bool, caller: bool, default_autoescape: bool | None=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __call__(self, *args: t.Any, **kwargs: t.Any) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def _async_invoke(self, arguments: list[t.Any], autoescape: bool) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _invoke(self, arguments: list[t.Any], autoescape: bool) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Undefined:
    __slots__ = ...

    def __init__(self, hint: str | None=..., obj: t.Any=..., name: str | None=..., exc: type[TemplateRuntimeError]=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _undefined_message(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _fail_with_undefined_error(self, *args: t.Any, **kwargs: t.Any) -> 'te.NoReturn':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getattr__(self, name: str) -> t.Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __add__ = ...
    __radd__ = ...
    __sub__ = ...
    __rsub__ = ...
    __mul__ = ...
    __rmul__ = ...
    __div__ = ...
    __rdiv__ = ...
    __truediv__ = ...
    __rtruediv__ = ...
    __floordiv__ = ...
    __rfloordiv__ = ...
    __mod__ = ...
    __rmod__ = ...
    __pos__ = ...
    __neg__ = ...
    __call__ = ...
    __getitem__ = ...
    __lt__ = ...
    __le__ = ...
    __gt__ = ...
    __ge__ = ...
    __int__ = ...
    __float__ = ...
    __complex__ = ...
    __pow__ = ...
    __rpow__ = ...

    def __eq__(self, other: t.Any) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ne__(self, other: t.Any) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __hash__(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self) -> t.Iterator[t.Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    async def __aiter__(self) -> t.AsyncIterator[t.Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __bool__(self) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def make_logging_undefined(logger: t.Optional['logging.Logger']=..., base: type[Undefined]=...) -> type[Undefined]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class ChainableUndefined:
    __slots__ = ...

    def __html__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getattr__(self, name: str) -> 'ChainableUndefined':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, _name: str) -> 'ChainableUndefined':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class DebugUndefined:
    __slots__ = ...

    def __str__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class StrictUndefined:
    __slots__ = ...
    __iter__ = ...
    __str__ = ...
    __len__ = ...
    __eq__ = ...
    __ne__ = ...
    __bool__ = ...
    __hash__ = ...
    __contains__ = ...
