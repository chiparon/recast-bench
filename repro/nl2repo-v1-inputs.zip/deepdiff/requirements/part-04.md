    def __search(self, obj: Any, item: Any, parent: str = "root", parents_ids: FrozenSet[int] = frozenset()) -> None:
        """The main search method"""
       
```


### 5. DeepHash Class

**Function**: Calculate the hash of objects based on their contents in a deterministic way.

**Class Definition**:
```python
class DeepHash(Base):
    """
    Generate deep hash values for complex objects
    
    Used to generate consistent hash values for nested Python objects, 
    supporting custom hash algorithms and type handling rules. 
    Mainly used for internal optimization of DeepDiff.
    """
    __doc__ = doc
    
    # Class attributes
    hashes: Dict[Any, Any]
    exclude_types_tuple: Tuple[type, ...]
    ignore_repetition: bool
    exclude_paths: Optional[Set[str]]
    include_paths: Optional[Set[str]]
    exclude_regex_paths: Optional[List[re.Pattern[str]]]
    hasher: Callable[[Union[str, bytes]], str]
    use_enum_value: bool
    default_timezone: Union[datetime.timezone, "BaseTzInfo"]
    significant_digits: Optional[int]
    truncate_datetime: Optional[str]
    number_format_notation: str
    ignore_type_in_groups: Any
    ignore_string_type_changes: bool
    ignore_numeric_type_changes: bool
    ignore_string_case: bool
    exclude_obj_callback: Optional[Callable[[Any, str], bool]]
    apply_hash: bool
    type_check_func: Callable[[type, Any], bool]
    number_to_string: Any
    ignore_private_variables: bool
    encodings: Optional[List[str]]
    ignore_encoding_errors: bool
    ignore_iterable_order: bool
    custom_operators: Optional[List[Any]]

    def __init__(self,
                 obj: Any,
                 *,
                 apply_hash: bool = True,
                 custom_operators: Optional[List[Any]] = None,
                 default_timezone: Union[datetime.timezone, "BaseTzInfo"] = datetime.timezone.utc,
                 encodings: Optional[List[str]] = None,
                 exclude_obj_callback: Optional[Callable[[Any, str], bool]] = None,
                 exclude_paths: Optional[PathType] = None,
                 exclude_regex_paths: Optional[RegexType] = None,
                 exclude_types: Optional[Union[List[type], Set[type], Tuple[type, ...]]] = None,
                 hasher: Optional[Callable[[Union[str, bytes]], str]] = None,
                 hashes: Optional[Union[Dict[Any, Any], "DeepHash"]] = None,
                 ignore_encoding_errors: bool = False,
                 ignore_iterable_order: bool = True,
                 ignore_numeric_type_changes: bool = False,
                 ignore_private_variables: bool = True,
                 ignore_repetition: bool = True,
                 ignore_string_case: bool = False,
                 ignore_string_type_changes: bool = False,
                 ignore_type_in_groups: Any = None,
                 ignore_type_subclasses: bool = False,
                 ignore_uuid_types: bool = False,
                 include_paths: Optional[PathType] = None,
                 number_format_notation: str = "f",
                 number_to_string_func: Optional[NumberToStringFunc] = None,
                 parent: str = "root",
                 significant_digits: Optional[int] = None,
                 truncate_datetime: Optional[str] = None,
                 use_enum_value: bool = False,
                 **kwargs) -> None:
        if kwargs:
            raise ValueError(
                ("The following parameter(s) are not valid: %s\n"
                 "The valid parameters are obj, hashes, exclude_types, significant_digits, truncate_datetime,"
                 "exclude_paths, include_paths, exclude_regex_paths, hasher, ignore_repetition, "
                 "number_format_notation, apply_hash, ignore_type_in_groups, ignore_string_type_changes, "
                 "ignore_numeric_type_changes, ignore_type_subclasses, ignore_string_case, ignore_uuid_types, "
                 "number_to_string_func, ignore_private_variables, parent, use_enum_value, default_timezone "
                 "encodings, ignore_encoding_errors") % ', '.join(kwargs.keys()))
        if isinstance(hashes, MutableMapping):
            self.hashes = hashes
        elif isinstance(hashes, DeepHash):
            self.hashes = hashes.hashes
        else:
            self.hashes = dict_()
        exclude_types = set() if exclude_types is None else set(exclude_types)
        self.exclude_types_tuple = tuple(exclude_types)  # we need tuple for checking isinstance
        self.ignore_repetition = ignore_repetition
        self.exclude_paths = add_root_to_paths(convert_item_or_items_into_set_else_none(exclude_paths))
        self.include_paths = add_root_to_paths(convert_item_or_items_into_set_else_none(include_paths))
        self.exclude_regex_paths = convert_item_or_items_into_compiled_regexes_else_none(exclude_regex_paths)
        self.hasher = default_hasher if hasher is None else hasher
        self.hashes[UNPROCESSED_KEY] = []  # type: ignore
        self.use_enum_value = use_enum_value
        self.default_timezone = default_timezone
        self.significant_digits = self.get_significant_digits(significant_digits, ignore_numeric_type_changes)
        self.truncate_datetime = get_truncate_datetime(truncate_datetime)
        self.number_format_notation = number_format_notation
        self.ignore_type_in_groups = self.get_ignore_types_in_groups(
            ignore_type_in_groups=ignore_type_in_groups,
            ignore_string_type_changes=ignore_string_type_changes,
            ignore_numeric_type_changes=ignore_numeric_type_changes,
            ignore_type_subclasses=ignore_type_subclasses,
            ignore_uuid_types=ignore_uuid_types,
        )
        self.ignore_string_type_changes = ignore_string_type_changes
        self.ignore_numeric_type_changes = ignore_numeric_type_changes
        self.ignore_string_case = ignore_string_case
        self.exclude_obj_callback = exclude_obj_callback
        # makes the hash return constant size result if true
        # the only time it should be set to False is when
        # testing the individual hash functions for different types of objects.
        self.apply_hash = apply_hash
        self.type_check_func = type_in_type_group if ignore_type_subclasses else type_is_subclass_of_type_group
        # self.type_check_func = type_is_subclass_of_type_group if ignore_type_subclasses else type_in_type_group
        self.number_to_string = number_to_string_func or number_to_string
        self.ignore_private_variables = ignore_private_variables
        self.encodings = encodings
        self.ignore_encoding_errors = ignore_encoding_errors
        self.ignore_iterable_order = ignore_iterable_order
        self.custom_operators = custom_operators

        self._hash(obj, parent=parent, parents_ids=frozenset({get_id(obj)}))

        if self.hashes[UNPROCESSED_KEY]:
            logger.warning("Can not hash the following items: {}.".format(self.hashes[UNPROCESSED_KEY]))
        else:
            del self.hashes[UNPROCESSED_KEY]

    sha256hex: Callable[[Union[str, bytes]], str] = sha256hex
    sha1hex: Callable[[Union[str, bytes]], str] = sha1hex

    def __getitem__(self, obj: Any, extract_index: Optional[int] = 0) -> Any:
        """
        Get item from hashes dictionary
        
        Args:
            obj: Object to get hash for
            extract_index: Index to extract (0 for hash, 1 for count)
            
        Returns:
            Any: Hash value or count
        """


    @staticmethod
    def _getitem(hashes: Dict[Any, Any], obj: Any, extract_index: Optional[int] = 0, use_enum_value: bool = False) -> Any:
        """
        extract_index is zero for hash and 1 for count and None to get them both.
        To keep it backward compatible, we only get the hash by default so it is set to zero by default.
        """

       

    def __contains__(self, obj: Any) -> bool:
        """
        Check if object is in hashes dictionary
        
        Args:
            obj: Object to check
            
        Returns:
            bool: True if object is in hashes, False otherwise
        """


    def get(self, key: Any, default: Any = None, extract_index: Optional[int] = 0) -> Any:
        """
        Get method for the hashes dictionary.
        It can extract the hash for a given key that is already calculated when extract_index=0
        or the count of items that went to building the object whenextract_index=1.
        """


    @staticmethod
    def get_key(hashes: Dict[Any, Any], key: Any, default: Any = None, extract_index: Optional[int] = 0, use_enum_value: bool = False) -> Any:
        """
        get_key method for the hashes dictionary.
        It can extract the hash for a given key that is already calculated when extract_index=0
        or the count of items that went to building the object whenextract_index=1.
        """


    def _get_objects_to_hashes_dict(self, extract_index: Optional[int] = 0) -> Dict[Any, Any]:
        """
        A dictionary containing only the objects to hashes,
        or a dictionary of objects to the count of items that went to build them.
        extract_index=0 for hashes and extract_index=1 for counts.
        """


    def __eq__(self, other: Any) -> bool:


    __req__ = __eq__

    def __repr__(self) -> str:
        """
        Hide the counts since it will be confusing to see them when they are hidden everywhere else.
        """
        from deepdiff.summarize import summarize

    def __str__(self) -> str:
        """
        Return string representation of the DeepHash object
        
        Returns:
            str: String representation of the hash
        """

    def __bool__(self) -> bool:
        """
        Return boolean representation of the DeepHash object
        
        Returns:
            bool: True if hashes exist, False otherwise
        """

    def keys(self) -> Any:
        """
        Return keys from the hashes dictionary
        
        Returns:
            Any: Keys from the hashes dictionary
        """


    def values(self) -> Generator[Any, None, None]:
        """
        Return values from the hashes dictionary
        
        Returns:
            Generator[Any, None, None]: Values from the hashes dictionary
        """

    def items(self) -> Generator[Tuple[Any, Any], None, None]:
        """
        Return items from the hashes dictionary
        
        Returns:
            Generator[Tuple[Any, Any], None, None]: Items from the hashes dictionary
        """

    def _prep_obj(self, obj: Any, parent: str, parents_ids: frozenset = EMPTY_FROZENSET, is_namedtuple: bool = False, is_pydantic_object: bool = False) -> HashTuple:
        """prepping objects"""
       

    def _skip_this(self, obj: Any, parent: str) -> bool:
        """
        Check if object should be skipped during hashing
        
        Args:
            obj: Object to check
            parent: Parent path string
            
        Returns:
            bool: True if object should be skipped, False otherwise
        """
        

    def _prep_dict(self, obj: Union[Dict[Any, Any], MutableMapping], parent: str, parents_ids: frozenset = EMPTY_FROZENSET, print_as_attribute: bool = False, original_type: Optional[type] = None) -> HashTuple:
        """
        Prepare dictionary for hashing
        
        Args:
            obj: Dictionary to prepare
            parent: Parent path string
            parents_ids: Set of parent object IDs
            print_as_attribute: Whether to print as attribute
            original_type: Original type of the object
            
        Returns:
            HashTuple: Hash tuple for the dictionary
        """

        

    def _prep_iterable(self, obj: Iterable[Any], parent: str, parents_ids: frozenset = EMPTY_FROZENSET) -> HashTuple:
        """
        Prepare iterable for hashing
        
        Args:
            obj: Iterable to prepare
            parent: Parent path string
            parents_ids: Set of parent object IDs
            
        Returns:
            HashTuple: Hash tuple for the iterable
        """

        

    def _prep_bool(self, obj: bool) -> BoolObj:
        """
        Prepare boolean for hashing
        
        Args:
            obj: Boolean to prepare
            
        Returns:
            BoolObj: Boolean object for hashing
        """


    def _prep_path(self, obj: Path) -> str:
        """
        Prepare path for hashing
        
        Args:
            obj: Path object to prepare
            
        Returns:
            str: String representation of the path
        """

    def _prep_number(self, obj: Union[int, float, complex]) -> str:
        """
        Prepare number for hashing
        
        Args:
            obj: Number to prepare
            
        Returns:
            str: String representation of the number
        """

    def _prep_ipranges(self, obj) -> str:
        """
        Prepare IP ranges for hashing
        
        Args:
            obj: IP range object to prepare
            
        Returns:
            str: String representation of the IP range
        """

    def _prep_datetime(self, obj: datetime.datetime) -> str:
        """
        Prepare datetime for hashing
        
        Args:
            obj: Datetime object to prepare
            
        Returns:
            str: String representation of the datetime
        """

    def _prep_date(self, obj: datetime.date) -> str:
        """
        Prepare date for hashing
        
        Args:
            obj: Date object to prepare
            
        Returns:
            str: String representation of the date
        """

    def _prep_tuple(self, obj: tuple, parent: str, parents_ids: frozenset) -> HashTuple:
        # Checking to see if it has _fields. Which probably means it is a named
        # tuple.

    def _hash(self, obj: Any, parent: str, parents_ids: frozenset = EMPTY_FROZENSET) -> HashTuple:
        """The main hash method"""
       
```

### 6. extract() Function - Path Extraction

**Function**: Extract the value at a specified path from an object.

**Function Signature**:

```python
from deepdiff.path import extract
def extract(
    obj: Any,
    path: str
) -> Any:
```

**Parameter Description**:
- `obj` (Any): The object to be extracted from
- `path` (str): The path string

**Return Value**: The extracted value

### 7. parse_path() Function - Path Parsing

**Function**: Parse a path string.

**Function Signature**:
```python
def parse_path(
    path: str,
    root_element: Tuple[str, str] = ('root', 'GETATTR'),
    include_actions: bool = False
) -> List[Tuple[Any, str]]:
```

**Parameter Description**:
- `path` (str): The path string
- `root_element` (Tuple): The root element, default is ('root', 'GETATTR')
- `include_actions` (bool): Whether to include actions, default is False

**Return Value**: A list of parsed elements

### 8. grep() Function - Object Search

**Function**: Search for a specific value in an object.

**Function Signature**:
```python
def grep(item, path, debug, **kwargs):
```

**Parameter Description**:
- `item` (Any): The item to be searched for
- `**kwargs`: Other parameters (same as DeepSearch)

**Return Value**: A DeepSearch object

### 9.pytest_addoption() Function - Add Options

**Function**: Add options to the pytest command line.

**Function Signature**:
```python
def pytest_addoption(parser):
```

**Parameter Description**:
- `parser`: The parser object

**Return Value**: None

### 10.pytest_configure() Function - Configure pytest

**Function**: Configure the pytest command line.

**Function Signature**:
```python
def pytest_configure(config):
```

**Parameter Description**:
- `config`: The config object

**Return Value**: None

### 11.pytest_collection_modifyitems() Function - Modify Collection Items

**Function**: Modify the collection items.

**Function Signature**:
```python
def pytest_collection_modifyitems(config, items):
```

**Parameter Description**:
- `config`: The config object
- `items`: The collection items

**Return Value**: None

### 12.nested_a_t1() Function - Nested A T1

**Function**: Load the nested A T1 fixture.

**Function Signature**:
```python
@pytest.fixture(scope='class')
def nested_a_t1():
```

**Parameter Description**: None

**Return Value**: The nested A T1 fixture

### 13.nested_a_t2() Function - Nested A T2

**Function**: Load the nested A T2 fixture.

**Function Signature**:
```python
@pytest.fixture(scope='class')
def nested_a_t2():
```

**Parameter Description**: None

**Return Value**: The nested A T2 fixture

### 14.nested_a_result() Function - Nested A Result

**Function**: Load the nested A result fixture.

**Function Signature**:
```python
@pytest.fixture(scope='class')
def nested_a_result():
```

**Parameter Description**: None

**Return Value**: The nested A result fixture

### 15.compounds() Function - Compounds

**Function**: Load the compounds fixture.

**Function Signature**:
```python
@pytest.fixture(scope='function')
def compounds():
```

**Parameter Description**: None

**Return Value**: The compounds fixture

### 16.nested_a_affected_paths() Function - Nested A Affected Paths

**Function**: Load the nested A affected paths fixture.

**Function Signature**:
```python
@pytest.fixture(scope='class')
def nested_a_affected_paths():
```

**Parameter Description**: None

**Return Value**: The nested A affected paths fixture

### 17.nested_b_t1() Function - Nested B T1

**Function**: Load the nested B T1 fixture.

**Function Signature**:
```python
@pytest.fixture(scope='class')
def nested_b_t1():
```

**Parameter Description**: None

**Return Value**: The nested B T1 fixture

### 18.nested_b_t2() Function - Nested B T2

**Function**: Load the nested B T2 fixture.

**Function Signature**:
```python
@pytest.fixture(scope='class')
def nested_b_t2():
```

**Parameter Description**: None

**Return Value**: The nested B T2 fixture

### 19.nested_b_result() Function - Nested B Result

**Function**: Load the nested B result fixture.

**Function Signature**:
```python
@pytest.fixture(scope='class')
def nested_b_result():
```

**Parameter Description**: None

**Return Value**: The nested B result fixture

### 20.compare_func_t1() Function - Compare Func T1

**Function**: Load the compare func T1 fixture.

**Function Signature**:
```python
@pytest.fixture(scope='class')
def compare_func_t1():
```

**Parameter Description**: None

**Return Value**: The compare func T1 fixture

### 21.compare_func_t2() Function - Compare Func T2

**Function**: Load the compare func T2 fixture.

**Function Signature**:
```python
@pytest.fixture(scope='class')
def compare_func_t2():
```

**Parameter Description**: None

**Return Value**: The compare func T2 fixture

### 22.compare_func_result1() Function - Compare Func Result1

**Function**: Load the compare func result1 fixture.

**Function Signature**:
```python
@pytest.fixture(scope='class')
def compare_func_result1():
```

**Parameter Description**: None

**Return Value**: The compare func result1 fixture

### 23.flake8() Function - Flake8

**Function**: Run the flake8 command.

**Function Signature**:
```python
def flake8(session) -> None:
```

**Parameter Description**: None

**Return Value**: None

### 24. calculate_weights() Function - Calculate Node Weights

**Function**: Recursively calculates the weight of each node in any data structure and builds node structure information.

**Function Signature**:
```python
def calculate_weights(node) -> Tuple[int, Tuple[SummaryNodeType, Any]]
```

**Parameter Description**:
- `node` (Any): The node for which to calculate the weight, supports data types such as dictionaries, lists, strings, numbers, None, etc.

**Return Value**: A tuple containing weight and node structure information
- For dictionary nodes: returns `(total_weight, (SummaryNodeType.dict, child_node_weight_info))`
- For list nodes: returns `(total_weight, (SummaryNodeType.list, child_node_weight_info))`
- For leaf nodes: returns `(node_weight, (SummaryNodeType.leaf, original_value))`

### 25.shrink_tree_balanced() Function - Shrink Tree Balanced

**Function**: Shrink the tree balanced.

**Function Signature**:
```python
def shrink_tree_balanced(node_structure, max_weight: int, balance_threshold: float) -> Tuple[JSON, float]:
```

**Parameter Description**:
- `node_structure` (Tuple): The node structure to shrink
- `max_weight` (int): The maximum weight
- `balance_threshold` (float): The balance threshold

**Return Value**: A tuple containing the shrunk node structure and the weight

### 26.greedy_tree_summarization_balanced() Function - Greedy Tree Summarization Balanced

**Function**: Greedy tree summarization balanced.

**Function Signature**:
```python
def greedy_tree_summarization_balanced(json_data: JSON, max_weight: int, balance_threshold=0.6) -> JSON:
```

**Parameter Description**:
- `json_data` (JSON): The JSON data to summarize
- `max_weight` (int): The maximum weight
- `balance_threshold` (float): The balance threshold

**Return Value**: The summarized JSON data

### 27._numpy_div() Function - Numpy Div

**Function**: Divide two numpy arrays.

**Function Signature**:
```python
def _numpy_div(a, b, replace_inf_with=1):
```

**Parameter Description**:
- `a` (np.ndarray): The first numpy array
- `b` (np.ndarray): The second numpy array
- `replace_inf_with` (int): The value to replace infinity with

**Return Value**: The divided numpy array

### 28.numpy_apply_log_keep_sign() Function - Numpy Apply Log Keep Sign

**Function**: Apply the log to a numpy array and keep the sign.

**Function Signature**:
```python
def numpy_apply_log_keep_sign(array, offset=MATH_LOG_OFFSET) -> np.ndarray:
```

**Parameter Description**:
- `array` (np.ndarray): The numpy array to apply the log to
- `offset` (float): The offset to add to the array

**Return Value**: The logged numpy array

### 29.logarithmic_similarity() Function - Logarithmic Similarity

**Function**: Calculate the logarithmic similarity between two values.

**Function Signature**:
```python
def logarithmic_similarity(a: NumberType, b: NumberType, threshold: float=0.1) -> float:
```

**Parameter Description**:
- `a` (float): The first value
- `b` (float): The second value
- `threshold` (float): The threshold for the similarity

**Return Value**: The logarithmic similarity

### 30.logarithmic_distance() Function - Logarithmic Distance

**Function**: Calculate the logarithmic distance between two values.

**Function Signature**:
```python
def logarithmic_distance(a: NumberType, b: NumberType) -> float:
```

**Parameter Description**:
- `a` (NumberType): The first value
- `b` (NumberType): The second value

**Return Value**: The logarithmic distance

### 31._get_numpy_array_distance() Function - Get Numpy Array Distance

**Function**: Get the distance between two numpy arrays.

**Function Signature**:
```python
def _get_numpy_array_distance(num1, num2, max_=1, use_log_scale=False, log_scale_similarity_threshold=0.1):
```

**Parameter Description**:
- `num1` (np.ndarray): The first numpy array
- `num2` (np.ndarray): The second numpy array
- `max_` (int): The maximum value
- `use_log_scale` (bool): Whether to use log scale
- `log_scale_similarity_threshold` (float): The threshold for the similarity

**Return Value**: The distance between the two numpy arrays

### 32._get_datetime_distance() Function - Get Datetime Distance

**Function**: Get the distance between two datetime objects.

**Function Signature**:
```python
def _get_datetime_distance(date1, date2, max_, use_log_scale, log_scale_similarity_threshold):
```

**Parameter Description**:
- `date1` (datetime.datetime): The first datetime object
- `date2` (datetime.datetime): The second datetime object
- `max_` (int): The maximum value
- `use_log_scale` (bool): Whether to use log scale
- `log_scale_similarity_threshold` (float): The threshold for the similarity

**Return Value**: The distance between the two datetime objects

