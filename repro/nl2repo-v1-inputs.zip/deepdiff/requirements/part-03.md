                                    **op_code
                                )
                            )
                    result['_iterable_opcodes'] = _iterable_opcodes
                return result


        self._reversed_diff = None

        if verify_symmetry is not None:
            logger.warning(
                "DeepDiff Deprecation: use bidirectional instead of verify_symmetry parameter."
            )
            bidirectional = verify_symmetry

        self.bidirectional = bidirectional
        if bidirectional:
            self.always_include_values = True  # We need to include the values in bidirectional deltas
        else:
            self.always_include_values = always_include_values

        if diff is not None:
            if isinstance(diff, DeepDiff):
                self.diff = diff._to_delta_dict(directed=not bidirectional, always_include_values=self.always_include_values)
            elif isinstance(diff, Mapping):
                self.diff = diff
            elif isinstance(diff, strings):
                self.diff = _deserializer(diff, safe_to_import=safe_to_import)
        elif delta_path:
            with open(delta_path, 'rb') as the_file:
                content = the_file.read()
            self.diff = _deserializer(content, safe_to_import=safe_to_import)
        elif delta_diff:
            self.diff = delta_diff
        elif delta_file:
            try:
                content = delta_file.read()
            except UnicodeDecodeError as e:
                raise ValueError(BINIARY_MODE_NEEDED_MSG.format(e)) from None
            self.diff = _deserializer(content, safe_to_import=safe_to_import)
        elif flat_dict_list:
            # Use copy to preserve original value of flat_dict_list in calling module
            self.diff = self._from_flat_dicts(copy.deepcopy(flat_dict_list))
        elif flat_rows_list:
            self.diff = self._from_flat_rows(copy.deepcopy(flat_rows_list))
        else:
            raise ValueError(DELTA_AT_LEAST_ONE_ARG_NEEDED)

        self.mutate = mutate
        self.raise_errors = raise_errors
        self.log_errors = log_errors
        self._numpy_paths = self.diff.get('_numpy_paths', False)
        # When we create the delta from a list of flat dictionaries, details such as iterable_compare_func_was_used get lost.
        # That's why we allow iterable_compare_func_was_used to be explicitly set.
        self._iterable_compare_func_was_used = self.diff.get('_iterable_compare_func_was_used', iterable_compare_func_was_used)
        self.serializer = serializer
        self.deserializer = deserializer
        self.force = force
        self.fill = fill
        if force:
            self.get_nested_obj = _get_nested_obj_and_force
        else:
            self.get_nested_obj = _get_nested_obj
        self.reset()

    def __repr__(self):
        """
        Return string representation of the Delta object
        
        Returns:
            str: String representation of the delta
        """


    def reset(self):
        """
        Reset the delta object to initial state
        """


    def __add__(self, other):
        """
        Add another delta to this delta
        
        Args:
            other: Another delta object to add
            
        Returns:
            Delta: Combined delta object
        """
        
    __radd__ = __add__

    def __rsub__(self, other):
        """
        Subtract this delta from another delta
        
        Args:
            other: Another delta object
            
        Returns:
            Delta: Resulting delta object
        """


    def _raise_or_log(self, msg, level='error'):
        """
        Raise an error or log a message based on configuration
        
        Args:
            msg: Error message to raise or log
            level: Log level ('error', 'warning', etc.)
        """


    def _do_verify_changes(self, path, expected_old_value, current_old_value):
        """
        Verify that changes match expected values
        
        Args:
            path: Path to the changed item
            expected_old_value: Expected old value
            current_old_value: Current old value
        """
       
    def _get_elem_and_compare_to_old_value(
        self,
        obj,
        path_for_err_reporting,
        expected_old_value,
        elem=None,
        action=None,
        forced_old_value=None,
        next_element=None,
    ):
        """
        Get element and compare to old value for verification
        
        Args:
            obj: Object to get element from
            path_for_err_reporting: Path for error reporting
            expected_old_value: Expected old value
            elem: Element to compare
            action: Action being performed
            forced_old_value: Forced old value
            next_element: Next element in path
        """
        

    def _simple_set_elem_value(self, obj, path_for_err_reporting, elem=None, value=None, action=None):
        """
        Set the element value directly on an object
        """
        

    def _coerce_obj(self, parent, obj, path, parent_to_obj_elem,
                    parent_to_obj_action, elements, to_type, from_type):
        """
        Coerce obj and mark it in post_process_paths_to_convert for later to be converted back.
        Also reassign it to its parent to replace the old object.
        """
        self.post_process_paths_to_convert[elements[:-1]] = {'old_type': to_type, 'new_type': from_type}
        # If this function is going to ever be used to convert numpy arrays, uncomment these lines:
        # if from_type is np_ndarray:
        #     obj = obj.tolist()
        # else:
        

    def _set_new_value(self, parent, parent_to_obj_elem, parent_to_obj_action,
                       obj, elements, path, elem, action, new_value):
        """
        Set the element value on an object and if necessary convert the object to the proper mutable type
        """
        

    def _simple_delete_elem(self, obj, path_for_err_reporting, elem=None, action=None):
        """
        Delete the element directly on an object
        """


    def _del_elem(self, parent, parent_to_obj_elem, parent_to_obj_action,
                  obj, elements, path, elem, action):
        """
        Delete the element value on an object and if necessary convert the object to the proper mutable type
        """
       

    def _do_iterable_item_added(self):
        """
        Process iterable items that were added
        """
        

    def _do_dictionary_item_added(self):
        """
        Process dictionary items that were added
        """
       
    def _do_attribute_added(self):
        """
        Process attributes that were added
        """


    @staticmethod
    def _sort_key_for_item_added(path_and_value):
        """
        Get sort key for item added operations
        
        Args:
            path_and_value: Tuple containing path and value
            
        Returns:
            Sort key for ordering
        """


    @staticmethod
    def _sort_comparison(left, right):
        """
        We use sort comparison instead of _sort_key_for_item_added when we run into comparing element types that can not
        be compared with each other, such as None to None. Or integer to string.
        """
        # Example elements: [(4.3, 'GET'), ('b', 'GETATTR'), ('a3', 'GET')]
        # We only care about the values in the elements not how to get the values.
        


    def _do_item_added(self, items, sort=True, insert=False):
        """
        Process items that were added
        
        Args:
            items: Items that were added
            sort: Whether to sort the items
            insert: Whether to insert items
        """
        

    def _do_values_changed(self):
        """
        Process values that were changed
        """


    def _do_type_changes(self):
        """
        Process type changes
        """


    def _do_post_process(self):
        """
        Perform post-processing operations
        """


    def _do_pre_process(self):
        """
        Perform pre-processing operations
        """
        

    def _get_elements_and_details(self, path):
        """
        Get elements and details for a given path
        
        Args:
            path: The path to get elements for
            
        Returns:
            tuple: Elements and details for the path
        """
        

    def _do_values_or_type_changed(self, changes, is_type_change=False, verify_changes=True):
        """
        Process values or type changes
        
        Args:
            changes: List of changes to process
            is_type_change: Whether this is a type change
            verify_changes: Whether to verify changes
        """
        

    def _do_item_removed(self, items):
        """
        Handle removing items.
        """
        # Sorting the iterable_item_removed in reverse order based on the paths.
        # So that we delete a bigger index before a smaller index
        

    def _find_closest_iterable_element_for_index(self, obj, elem, expected_old_value):
        """
        Find the closest iterable element for a given index
        
        Args:
            obj: The object to search in
            elem: The element to find
            expected_old_value: Expected old value
            
        Returns:
            The closest element found
        """
        

    def _do_iterable_opcodes(self):
        """
        Process iterable opcodes for delta operations
        """
        



                # obj = self.get_nested_obj(obj=self, elements=elements)
                # for


    def _do_iterable_item_removed(self):
        """
        Process iterable items that were removed
        """
        

    def _do_dictionary_item_removed(self):
        """
        Process dictionary items that were removed
        """
        

    def _do_attribute_removed(self):
        """
        Process attributes that were removed
        """
        

    def _do_set_item_added(self):
        """
        Process set items that were added
        """
        

    def _do_set_item_removed(self):
        """
        Process set items that were removed
        """
        
    def _do_set_or_frozenset_item(self, items, func):
        """
        Process set or frozenset items
        
        Args:
            items: Items to process
            func: Function to apply to items
        """
        

    def _do_ignore_order_get_old(self, obj, remove_indexes_per_path, fixed_indexes_values, path_for_err_reporting):
        """
        A generator that gets the old values in an iterable when the order was supposed to be ignored.
        """
       

    def _do_ignore_order(self):
        """

            't1': [5, 1, 1, 1, 6],
            't2': [7, 1, 1, 1, 8],

            'iterable_items_added_at_indexes': {
                'root': {
                    0: 7,
                    4: 8
                }
            },
            'iterable_items_removed_at_indexes': {
                'root': {
                    4: 6,
                    0: 5
                }
            }

        """
        

    def _get_reverse_diff(self):
        """
        Get the reverse diff for bidirectional operations
        
        Returns:
            Delta: Reverse delta object
        """
        

    def dump(self, file):
        """
        Dump into file object
        """
        # Small optimization: Our internal pickle serializer can just take a file object
        # and directly write to it. However if a user defined serializer is passed
        # we want to make it compatible with the expectation that self.serializer(self.diff)
        # will give the user the serialization and then it can be written to
        # a file object when using the dump(file) function.


    def dumps(self):
        """
        Return the serialized representation of the object as a bytes object, instead of writing it to a file.
        """


    def to_dict(self):
        """
        Convert delta to dictionary representation
        
        Returns:
            dict: Dictionary representation of the delta
        """


    def _flatten_iterable_opcodes(self, _parse_path):
        """
        Converts op_codes to FlatDeltaRows
        """
        

    @staticmethod
    def _get_flat_row(action, info, _parse_path, keys_and_funcs, report_type_changes=True):
        """
        Get a flat row for delta operations
        
        Args:
            action: Action being performed
            info: Information about the action
            _parse_path: Path parsing function
            keys_and_funcs: Keys and functions for processing
            report_type_changes: Whether to report type changes
            
        Returns:
            FlatDeltaRow: Flat row representation
        """
        

    @staticmethod
    def _from_flat_rows(flat_rows_list: List[FlatDeltaRow]):
        """
        Create delta from flat rows list
        
        Args:
            flat_rows_list: List of flat delta rows
            
        Returns:
            dict: Delta dictionary
        """


    @staticmethod
    def _from_flat_dicts(flat_dict_list):
        """
        Create the delta's diff object from the flat_dict_list
        """
        

    def to_flat_dicts(self, include_action_in_path=False, report_type_changes=True) -> List[FlatDeltaRow]:
        """
        Returns a flat list of actions that is easily machine readable.

        For example:
            {'iterable_item_added': {'root[3]': 5, 'root[2]': 3}}

        Becomes:
            [
                {'path': [3], 'value': 5, 'action': 'iterable_item_added'},
                {'path': [2], 'value': 3, 'action': 'iterable_item_added'},
            ]

        
        **Parameters**

        include_action_in_path : Boolean, default=False
            When False, we translate DeepDiff's paths like root[3].attribute1 into a [3, 'attribute1'].
            When True, we include the action to retrieve the item in the path: [(3, 'GET'), ('attribute1', 'GETATTR')]
            Note that the "action" here is the different than the action reported by to_flat_dicts. The action here is just about the "path" output.

        report_type_changes : Boolean, default=True
            If False, we don't report the type change. Instead we report the value change.

        Example:
            t1 = {"a": None}
            t2 = {"a": 1}

            dump = Delta(DeepDiff(t1, t2)).dumps()
            delta = Delta(dump)
            assert t2 == delta + t1

            flat_result = delta.to_flat_dicts()
            flat_expected = [{'path': ['a'], 'action': 'type_changes', 'value': 1, 'new_type': int, 'old_type': type(None)}]
            assert flat_expected == flat_result

            flat_result2 = delta.to_flat_dicts(report_type_changes=False)
            flat_expected2 = [{'path': ['a'], 'action': 'values_changed', 'value': 1}]

        **List of actions**

        Here are the list of actions that the flat dictionary can return.
            iterable_item_added
            iterable_item_removed
            iterable_item_moved
            values_changed
            type_changes
            set_item_added
            set_item_removed
            dictionary_item_added
            dictionary_item_removed
            attribute_added
            attribute_removed
        """
        

    def to_flat_rows(self, include_action_in_path=False, report_type_changes=True) -> List[FlatDeltaRow]:
        """
        Just like to_flat_dicts but returns FlatDeltaRow Named Tuples
        """
        
```

### 4. DeepSearch Class

**Function**: Search for a specific value in a complex data structure and return the paths and values of the found items.

**Class Definition**:
```python
class DeepSearch(Dict[str, Union[Dict[str, Any], SetOrdered, List[str]]]):
    """
    Deep search for matching items within objects
    
    Used to search for specific values or patterns in complex data structures.
    Supports string matching, regular expressions, type filtering, etc.
    """
    r"""
    **DeepSearch**

    Deep Search inside objects to find the item matching your criteria.

    **Parameters**

    obj : The object to search within

    item : The item to search for

    verbose_level : int >= 0, default = 1.
        Verbose level one shows the paths of found items.
        Verbose level 2 shows the path and value of the found items.

    exclude_paths: list, default = None.
        List of paths to exclude from the report.

    exclude_types: list, default = None.
        List of object types to exclude from the report.

    case_sensitive: Boolean, default = False

    match_string: Boolean, default = False
        If True, the value of the object or its children have to exactly match the item.
        If False, the value of the item can be a part of the value of the object or its children

    use_regexp: Boolean, default = False

    strict_checking: Boolean, default = True
        If True, it will check the type of the object to match, so when searching for '1234',
        it will NOT match the int 1234. Currently this only affects the numeric values searching.

    **Returns**

        A DeepSearch object that has the matched paths and matched values.

    **Supported data types**

    int, string, unicode, dictionary, list, tuple, set, frozenset, OrderedDict, NamedTuple and custom objects!

    **Examples**

    Importing
        >>> from deepdiff import DeepSearch
        >>> from pprint import pprint

    Search in list for string
        >>> obj = ["long somewhere", "string", 0, "somewhere great!"]
        >>> item = "somewhere"
        >>> ds = DeepSearch(obj, item, verbose_level=2)
        >>> print(ds)
        {'matched_values': {'root[3]': 'somewhere great!', 'root[0]': 'long somewhere'}}

    Search in nested data for string
        >>> obj = ["something somewhere", {"long": "somewhere", "string": 2, 0: 0, "somewhere": "around"}]
        >>> item = "somewhere"
        >>> ds = DeepSearch(obj, item, verbose_level=2)
        >>> pprint(ds, indent=2)
        { 'matched_paths': {"root[1]['somewhere']": 'around'},
          'matched_values': { 'root[0]': 'something somewhere',
                              "root[1]['long']": 'somewhere'}}

    """

    warning_num: int = 0

    def __init__(self,
                 obj: Any,
                 item: Any,
                 exclude_paths: Union[SetOrdered, Set[str], List[str]] = SetOrdered(),
                 exclude_regex_paths: Union[SetOrdered, Set[Union[str, Pattern[str]]], List[Union[str, Pattern[str]]]] = SetOrdered(),
                 exclude_types: Union[SetOrdered, Set[type], List[type]] = SetOrdered(),
                 verbose_level: int = 1,
                 case_sensitive: bool = False,
                 match_string: bool = False,
                 use_regexp: bool = False,
                 strict_checking: bool = True,
                 **kwargs: Any) -> None:
        if kwargs:
            raise ValueError((
                "The following parameter(s) are not valid: %s\n"
                "The valid parameters are obj, item, exclude_paths, exclude_types,\n"
                "case_sensitive, match_string and verbose_level."
            ) % ', '.join(kwargs.keys()))

        self.obj: Any = obj
        self.case_sensitive: bool = case_sensitive if isinstance(item, strings) else True
        item = item if self.case_sensitive else (item.lower() if isinstance(item, str) else item)
        self.exclude_paths: SetOrdered = SetOrdered(exclude_paths)
        self.exclude_regex_paths: List[Pattern[str]] = [re.compile(exclude_regex_path) for exclude_regex_path in exclude_regex_paths]
        self.exclude_types: SetOrdered = SetOrdered(exclude_types)
        self.exclude_types_tuple: tuple[type, ...] = tuple(
            exclude_types)  # we need tuple for checking isinstance
        self.verbose_level: int = verbose_level
        self.update(
            matched_paths=self.__set_or_dict(),
            matched_values=self.__set_or_dict(),
            unprocessed=[])
        # Type narrowing for mypy/pyright
        self.matched_paths: Union[Dict[str, Any], SetOrdered]
        self.matched_values: Union[Dict[str, Any], SetOrdered]
        self.unprocessed: List[str]
        self.use_regexp: bool = use_regexp
        if not strict_checking and (isinstance(item, numbers) or isinstance(item, ipranges)):
            item = str(item)
        if self.use_regexp:
            try:
                item = re.compile(item)
            except TypeError as e:
                raise TypeError(f"The passed item of {item} is not usable for regex: {e}") from None
        self.strict_checking: bool = strict_checking

        # Cases where user wants to match exact string item
        self.match_string: bool = match_string

        self.__search(obj, item, parents_ids=frozenset({id(obj)}))

        empty_keys = [k for k, v in self.items() if not v]

        for k in empty_keys:
            del self[k]

    def __set_or_dict(self) -> Union[Dict[str, Any], SetOrdered]:
        """
        Get set or dictionary for storing results
        
        Returns:
            Union[Dict[str, Any], SetOrdered]: Result container
        """


    def __report(self, report_key: str, key: str, value: Any) -> None:
        """
        Report a search result
        
        Args:
            report_key: Key for the report type
            key: The key/path of the found item
            value: The value of the found item
        """


    def __search_obj(self,
                     obj: Any,
                     item: Any,
                     parent: str,
                     parents_ids: FrozenSet[int] = frozenset(),
                     is_namedtuple: bool = False) -> None:
        """Search objects"""
       



    def __skip_this(self, item: Any, parent: str) -> bool:
        """
        Check if the current item should be skipped during search
        
        Args:
            item: The item to check
            parent: The parent path string
            
        Returns:
            bool: True if item should be skipped, False otherwise
        """
       

    def __search_dict(self,
                      obj: Union[Dict[Any, Any], MutableMapping[Any, Any]],
                      item: Any,
                      parent: str,
                      parents_ids: FrozenSet[int] = frozenset(),
                      print_as_attribute: bool = False) -> None:
        """Search dictionaries"""
        

    def __search_iterable(self,
                          obj: Iterable[Any],
                          item: Any,
                          parent: str = "root",
                          parents_ids: FrozenSet[int] = frozenset()) -> None:
        """Search iterables except dictionaries, sets and strings."""
        

    def __search_str(self, obj: Union[str, bytes, memoryview], item: Union[str, bytes, memoryview, Pattern[str]], parent: str) -> None:
        """Compare strings"""
        

    def __search_numbers(self, obj: Any, item: Any, parent: str) -> None:
        """
        Search for numbers in objects
        
        Args:
            obj: The object to search in
            item: The number to search for
            parent: Parent path string
        """
        
    def __search_tuple(self, obj: Tuple[Any, ...], item: Any, parent: str, parents_ids: FrozenSet[int]) -> None:
        """
        Search for items in tuples
        
        Args:
            obj: The tuple to search in
            item: The item to search for
            parent: Parent path string
            parents_ids: Set of parent object IDs
        """
        # Checking to see if it has _fields. Which probably means it is a named
        # tuple.
        

