    """A simple command line tool."""
    pass  # pragma: no cover.
```

### 160.AnySet Class

**Function**: A set that can contain any object, whether hashable or not.

**Class Definition**:
```python
class AnySet:
    """
    Any object can be in this set whether hashable or not.
    Note that the current implementation has memory leak and keeps
    traces of objects in itself even after popping.
    However one the AnySet object is deleted, all those traces will be gone too.
    """
    def __init__(self, items=None):
        self._set = SetOrdered()
        self._hashes = dict_()
        self._hash_to_objects = dict_()
        if items:
            for item in items:
                self.add(item)
        


    def add(self, item):
        """
        Add an item to the set
        
        Args:
            item: The item to add to the set
        """


    def __contains__(self, item):
        """
        Check if an item is in the set
        
        Args:
            item: The item to check for
            
        Returns:
            bool: True if item is in the set, False otherwise
        """


    def pop(self):
        """
        Remove and return an arbitrary item from the set
        
        Returns:
            The removed item
            
        Raises:
            KeyError: If the set is empty
        """


    def __eq__(self, other):
        """
        Check equality with another set
        
        Args:
            other: Another set to compare with
            
        Returns:
            bool: True if sets are equal, False otherwise
        """


    __req__ = __eq__

    def __repr__(self):
        """
        Return string representation of the set
        
        Returns:
            str: String representation of the set
        """


    __str__ = __repr__

    def __len__(self):
        """
        Return the number of items in the set
        
        Returns:
            int: Number of items in the set
        """


    def __iter__(self):
        """
        Return an iterator over the set items
        
        Returns:
            Iterator: Iterator over the set items
        """


    def __bool__(self):
        """
        Return True if the set is not empty
        
        Returns:
            bool: True if set has items, False if empty
        """

```

### 161.CannotCompare Class

**Function**: An exception that is raised when two items cannot be compared in the compare function.

**Class Definition**:
```python
class CannotCompare(Exception):
    """
    Exception when two items cannot be compared in the compare function.
    """
    pass
```

### 162.FlatDataAction Class

**Function**: An enum that represents the action of a flat data.

**Class Definition**:
```python
class FlatDataAction(EnumBase):
    values_changed = 'values_changed'
    type_changes = 'type_changes'
    set_item_added = 'set_item_added'
    set_item_removed = 'set_item_removed'
    dictionary_item_added = 'dictionary_item_added'
    dictionary_item_removed = 'dictionary_item_removed'
    iterable_item_added = 'iterable_item_added'
    iterable_item_removed = 'iterable_item_removed'
    iterable_item_moved = 'iterable_item_moved'
    iterable_items_inserted = 'iterable_items_inserted'  # opcode
    iterable_items_deleted = 'iterable_items_deleted'  # opcode
    iterable_items_replaced = 'iterable_items_replaced'  # opcode
    iterable_items_equal = 'iterable_items_equal'  # opcode
    attribute_removed = 'attribute_removed'
    attribute_added = 'attribute_added'
    unordered_iterable_item_added = 'unordered_iterable_item_added'
    unordered_iterable_item_removed = 'unordered_iterable_item_removed'
    initiated = "initiated"
```

### 163.DictRelationship Class

**Function**: A relationship that describes the relationship between a container object (the "parent") and the contained "child" object.

**Class Definition**:
```python
class DictRelationship(ChildRelationship):
    param_repr_format: Optional[str] = "[{}]"
    quote_str: Optional[str] = "'{}'"

```

### 164.SubscriptableIterableRelationship Class

**Function**: A relationship that describes the relationship between a container object (the "parent") and the contained "child" object.

**Class Definition**:
```python
class SubscriptableIterableRelationship(DictRelationship):
    pass
```

### 165.NonSubscriptableIterableRelationship Class

**Function**: A relationship that describes the relationship between a container object (the "parent") and the contained "child" object.

**Class Definition**:
```python
class NonSubscriptableIterableRelationship(InaccessibleRelationship):



    def get_param_repr(self, force: Optional[str] = None) -> Optional[str]:
        """
        Get parameter representation for the relationship
        
        Args:
            force: Optional force parameter for representation
            
        Returns:
            Optional[str]: String representation of the parameter
        """

```

### 166.AttributeRelationship Class

**Function**: A relationship that describes the relationship between a container object (the "parent") and the contained "child" object.

**Class Definition**:
```python
class AttributeRelationship(ChildRelationship):
    param_repr_format: Optional[str] = ".{}"
```

### 167.BaseOperatorPlus Class

**Function**: A base class for custom operators.

**Class Definition**:
```python
class BaseOperatorPlus(metaclass=ABCMeta):

    @abstractmethod
    def match(self, level) -> bool:
        """
        Given a level which includes t1 and t2 in the tree view, is this operator a good match to compare t1 and t2?
        If yes, we will run the give_up_diffing to compare t1 and t2 for this level.
        """
        pass

    @abstractmethod
    def give_up_diffing(self, level, diff_instance: "DeepDiff") -> bool:
        """
        Given a level which includes t1 and t2 in the tree view, and the "distance" between l1 and l2.
        do we consider t1 and t2 to be equal or not. The distance is a number between zero to one and is calculated by DeepDiff to measure how similar objects are.
        """

    @abstractmethod
    def normalize_value_for_hashing(self, parent: Any, obj: Any) -> Any:
        """
        You can use this function to normalize values for ignore_order=True

        For example, you may want to turn all the words to be lowercase. Then you return obj.lower()
        """
        pass
```

### 168.BaseOperator Class

**Function**: A base class for custom operators.

**Class Definition**:
```python
class BaseOperator:

    def __init__(self, regex_paths:Optional[List[str]]=None, types:Optional[List[type]]=None):
        if regex_paths:
            self.regex_paths = convert_item_or_items_into_compiled_regexes_else_none(regex_paths)
        else:
            self.regex_paths = None
        self.types = types

    def match(self, level) -> bool:
        """
        Check if this operator matches the given level
        
        Args:
            level: The comparison level to check
            
        Returns:
            bool: True if this operator should handle the comparison
        """

    def give_up_diffing(self, level, diff_instance) -> bool:
        """
        Determine if two objects should be considered equal
        
        Args:
            level: The comparison level containing objects to compare
            diff_instance: The DeepDiff instance performing the comparison
            
        Returns:
            bool: True if objects should be considered equal
            
        Raises:
            NotImplementedError: If not implemented by subclass
        """
        raise NotImplementedError('Please implement the diff function.')
```

### 169.PrefixOrSuffixOperator Class

**Function**: A custom operator that matches strings that start or end with the same string.

**Class Definition**:
```python
class PrefixOrSuffixOperator:

    def match(self, level) -> bool:
        return level.t1 and level.t2 and isinstance(level.t1, str) and isinstance(level.t2, str)

    def give_up_diffing(self, level, diff_instance) -> bool:
        t1 = level.t1
        t2 = level.t2
        return t1.startswith(t2) or t2.startswith(t1)

```

### 170.patch() Function

**Function**: A function that patches a file based on the information in a delta file.

**Function Signature**:
```python
def patch(
    path, delta_path, backup, raise_errors, debug
):
    """
    Deep Patch Commandline

    Patches a file based on the information in a delta file.
    The delta file can be created by the deep diff command and
    passing the --create-patch argument.

    Deep Patch is similar to Linux's patch command.
    The difference is that it is made for patching data.
    It can read csv, tsv, json, yaml, and toml files.

    """

```

**Parameter Description**:
- `path` (str): The path to the file to patch
- `delta_path` (str): The path to the delta file
- `backup` (bool): Whether to keep a backup of the original file
- `raise_errors` (bool): Whether to raise errors
- `debug` (bool): Whether to debug the function

**Return Value**: None

### 171.combine_hashes_lists() Function

**Function**: A function that combines lists of hashes into one hash.

**Function Signature**:
```python
def combine_hashes_lists(items: List[List[str]], prefix: Union[str, bytes]) -> str:
    """
    Combines lists of hashes into one hash
    This can be optimized in future.
    It needs to work with both murmur3 hashes (int) and sha256 (str)
    Although murmur3 is not used anymore.
    """
```

**Parameter Description**:
- `items` (List[List[str]]): The lists of hashes to combine
- `prefix` (Union[str, bytes]): The prefix to add to the hash

**Return Value**: The combined hash

### 172.prepare_string_for_hashing() Function

**Function**: A function that prepares a string for hashing.

**Function Signature**:
```python
def prepare_string_for_hashing(
        obj: Union[str, bytes, memoryview],
        ignore_string_type_changes: bool = False,
        ignore_string_case: bool = False,
        encodings: Optional[List[str]] = None,
        ignore_encoding_errors: bool = False,
) -> str:
    """
    Clean type conversions
    """
    original_type = obj.__class__.__name__
    # https://docs.python.org/3/library/codecs.html#codecs.decode
```

**Parameter Description**:
- `obj` (Union[str, bytes, memoryview]): The object to prepare for hashing
- `ignore_string_type_changes` (bool): Whether to ignore string type changes
- `ignore_string_case` (bool): Whether to ignore string case
- `encodings` (Optional[List[str]]): The encodings to try
- `ignore_encoding_errors` (bool): Whether to ignore encoding errors

**Return Value**: The prepared string

### 173._get_item_length() Function

**Function**: A function that gets the length of an item.

**Function Signature**:
```python
def _get_item_length(item, parents_ids=frozenset([])):
    """
    Get the number of operations in a diff object.
    It is designed mainly for the delta view output
    but can be used with other dictionary types of view outputs too.
    """
```

**Parameter Description**:
- `item`: The item to get the length of
- `parents_ids` (frozenset): The parent ids

**Return Value**: The length of the item

### 174.get_numeric_types_distance() Function

**Function**: A function that gets the distance between two numeric types.

**Function Signature**:
```python
def get_numeric_types_distance(num1, num2, max_, use_log_scale=False, log_scale_similarity_threshold=0.1):
```

**Parameter Description**:
- `num1`: The first numeric type
- `num2`: The second numeric type
- `max_`: The maximum value
- `use_log_scale` (bool): Whether to use log scale
- `log_scale_similarity_threshold` (float): The threshold for the similarity

**Return Value**: The distance between the two numeric types

### 175.get_semvar_as_integer() Function

**Function**: A function that gets the semvar as an integer.

**Function Signature**:
```python
def get_semvar_as_integer(version: str) -> int:
    """
    Converts:

    '1.23.5' to 1023005
    """
```

**Parameter Description**:
- `version` (str): The version to convert

**Return Value**: The semvar as an integer

### 176.short_repr() Function

**Function**: A function that shortens the representation of an item.

**Function Signature**:
```python
def short_repr(item: Any, max_length: int = 15) -> str:
    """Short representation of item if it is too long"""
```

**Parameter Description**:
- `item`: The item to shorten the representation of
- `max_length` (int): The maximum length of the representation

**Return Value**: The shortened representation of the item

### 177.cartesian_product() Function

**Function**: A function that returns the cartesian product of two lists.

**Function Signature**:
```python
def cartesian_product(a: Iterable[Tuple[Any, ...]], b: Iterable[Any]) -> Iterator[Tuple[Any, ...]]:
    """
    Get the Cartesian product of two iterables

    **parameters**

    a: list of lists
    b: iterable to do the Cartesian product
    """

```

**Parameter Description**:
- `a` (Iterable[Tuple[Any, ...]]): The first iterable
- `b` (Iterable[Any]): The second iterable

**Return Value**: The cartesian product of the two iterables

### 178.cartesian_product_of_shape() Function

**Function**: A function that returns the cartesian product of a shape.

**Function Signature**:
```python
def cartesian_product_of_shape(dimentions: Iterable[int], result: Optional[Tuple[Tuple[Any, ...], ...]] = None) -> Iterator[Tuple[Any, ...]]:
    """
    Cartesian product of a dimentions iterable.
    This is mainly used to traverse Numpy ndarrays.

    Each array has dimentions that are defines in ndarray.shape
    """
```

**Parameter Description**:
- `dimentions` (Iterable[int]): The dimensions to get the cartesian product of
- `result` (Optional[Tuple[Tuple[Any, ...], ...]]): The result to get the cartesian product of

**Return Value**: The cartesian product of the shape

### 179.get_numpy_ndarray_rows() Function

**Function**: A function that returns the rows of a numpy array.

**Function Signature**:
```python
def get_numpy_ndarray_rows(obj: Any, shape: Optional[Tuple[int, ...]] = None) -> Generator[Tuple[Tuple[int, ...], Any], None, None]:
    """
    Convert a multi dimensional numpy array to list of rows
    """
```

**Parameter Description**:
- `obj` (Any): The numpy array to get the rows of
- `shape` (Optional[Tuple[int, ...]]): The shape of the numpy array

**Return Value**: The rows of the numpy array

### 180.literal_eval_extended() Function

**Function**: A function that evaluates a string as a literal.

**Function Signature**:
```python
def literal_eval_extended(item: str) -> Any:
    """
    An extended version of literal_eval
    """
```

**Parameter Description**:
- `item` (str): The string to evaluate

**Return Value**: The evaluated literal

### 181.datetime_normalize() Function

**Function**: A function that normalizes a datetime object.

**Function Signature**:
```python
def datetime_normalize(
    truncate_datetime:Union[str, None],
    obj:Union[datetime.datetime, datetime.time],
    default_timezone: Union[
        datetime.timezone, "BaseTzInfo"
    ] = datetime.timezone.utc,
) -> Any:
```

**Parameter Description**:
- `truncate_datetime` (Union[str, None]): The truncate datetime
- `obj` (Union[datetime.datetime, datetime.time]): The datetime object to normalize
- `default_timezone` (Union[datetime.timezone, "BaseTzInfo"]): The default timezone

**Return Value**: The normalized datetime object

### 182.cartesian_product_numpy() Function

**Function**: A function that returns the cartesian product of numpy arrays.

**Function Signature**:
```python
def cartesian_product_numpy(*arrays: Any) -> Any:
    """
    Cartesian product of Numpy arrays by Paul Panzer
    https://stackoverflow.com/a/49445693/1497443
    """
```

**Parameter Description**:
- `arrays` (Any): The numpy arrays to get the cartesian product of

**Return Value**: The cartesian product of the numpy arrays

### 183.detailed__dict__() Function

**Function**: A function that returns the truncate datetime.

**Function Signature**:
```python
def detailed__dict__(obj: Any, ignore_private_variables: bool = True, ignore_keys: FrozenSet[str] = frozenset(), include_keys: Optional[List[str]] = None) -> Dict[str, Any]:
    """
    Get the detailed dictionary of an object.

    This is used so we retrieve object properties too.
    """
```

**Parameter Description**:
- `obj` (Any): The object to get the detailed dictionary of
- `ignore_private_variables` (bool): Whether to ignore private variables
- `ignore_keys` (FrozenSet[str]): The keys to ignore
- `include_keys` (Optional[List[str]]): The keys to include

**Return Value**: The detailed dictionary of the object

### 184._add_to_elements() Function

**Function**: A function that adds an element to a list of elements.

**Function Signature**:
```python
def _add_to_elements(elements, elem, inside):
    # Ignore private items
```

**Parameter Description**:
- `elements` (List[Tuple[Any, Any]]): The list of elements to add the element to
- `elem` (Any): The element to add
- `inside` (str): The inside of the element

**Return Value**: None

### 185._path_to_elements() Function

**Function**: A function that returns the elements of a path.

**Function Signature**:
```python
@lru_cache(maxsize=1024 * 128)
def _path_to_elements(path, root_element=DEFAULT_FIRST_ELEMENT):
    """
    Given a path, it extracts the elements that form the path and their relevant most likely retrieval action.

        >>> from deepdiff import _path_to_elements
        >>> path = "root[4.3].b['a3']"
        >>> _path_to_elements(path, root_element=None)
        [(4.3, 'GET'), ('b', 'GETATTR'), ('a3', 'GET')]
    """
```

**Parameter Description**:
- `path` (str): The path to get the elements of
- `root_element` (Optional[Tuple[Any, Any]]): The root element

**Return Value**: The elements of the path

### 186.stringify_path() Function

**Function**: A function that stringifies a path.

**Function Signature**:
```python
def stringify_path(path, root_element=DEFAULT_FIRST_ELEMENT, quote_str="'{}'"):
    """
    Gets the path as an string.

    For example [1, 2, 'age'] should become
    root[1][2]['age']
    """
```

**Parameter Description**:
- `path` (str): The path to stringify
- `root_element` (Optional[Tuple[Any, Any]]): The root element
- `quote_str` (Optional[str]): The quote string

**Return Value**: The stringified path

### 187.pretty_print_diff() Function

**Function**: A function that pretty prints a diff.

**Function Signature**:
```python
def pretty_print_diff(diff):
```

**Parameter Description**:
- `diff` (Diff): The diff to pretty print

**Return Value**: The pretty printed diff

### 188.load_path_content() Function

**Function**: A function that loads the content of a path.

**Function Signature**:
```python
def load_path_content(path, file_type=None):
    """
    Loads and deserializes the content of the path.
    """

```

**Parameter Description**:
- `path` (str): The path to load the content of
- `file_type` (Optional[str]): The type of the file

**Return Value**: The content of the path

### 189.json_dumps() Function

**Function**: A function that dumps a json object.

**Function Signature**:
```python
@overload
def json_dumps(
    item: Any,
    **kwargs,
) -> str:
    ...


@overload
def json_dumps(
    item: Any,
    default_mapping:Optional[dict],
    force_use_builtin_json: bool,
    return_bytes:Literal[True],
    **kwargs,
) -> bytes:
    ...


@overload
def json_dumps(
    item: Any,
    default_mapping:Optional[dict],
    force_use_builtin_json: bool,
    return_bytes:Literal[False],
    **kwargs,
) -> str:
    ...


def json_dumps(
    item: Any,
    default_mapping:Optional[dict]=None,
    force_use_builtin_json: bool = False,
    return_bytes: bool = False,
    **kwargs,
) -> Union[str, bytes]:
    """
    Dump json with extra details that are not normally json serializable

    parameters
    ----------

    force_use_builtin_json: Boolean, default = False
        When True, we use Python's builtin Json library for serialization,
        even if Orjson is installed.
    """
    
```

**Parameter Description**:
- `item` (Any): The item to dump
- `default_mapping` (Optional[dict]): The default mapping
- `force_use_builtin_json` (bool): Whether to force use the builtin json
- `return_bytes` (bool): Whether to return the bytes

**Return Value**: The dumped json object

### Constants and Aliases
```python
# in deephash.py
HASH_LOOKUP_ERR_MSG: str = '{} is not one of the hashed items.'

# in delta.py
VERIFICATION_MSG = 'Expected the old value for {} to be {} but it is {}. Error found on: {}. You may want to set force=True, especially if this delta is created by passing flat_rows_list or flat_dict_list'
ELEM_NOT_FOUND_TO_ADD_MSG = 'Key or index of {} is not found for {} for setting operation.'
VERIFY_BIDIRECTIONAL_MSG = ('You have applied the delta to an object that has '
                            'different values than the original object the delta was made from.')
FAIL_TO_REMOVE_ITEM_IGNORE_ORDER_MSG = 'Failed to remove index[{}] on {}. It was expected to be {} but got {}'
INVALID_ACTION_WHEN_CALLING_GET_ELEM = 'invalid action of {} when calling _get_elem_and_compare_to_old_value'
INVALID_ACTION_WHEN_CALLING_SIMPLE_SET_ELEM = 'invalid action of {} when calling _simple_set_elem_value'
INVALID_ACTION_WHEN_CALLING_SIMPLE_DELETE_ELEM = 'invalid action of {} when calling _simple_set_elem_value'
INDEXES_NOT_FOUND_WHEN_IGNORE_ORDER = 'Delta added to an incompatible object. Unable to add the following items at the specific indexes. {}'
NOT_VALID_NUMPY_TYPE = "{} is not a valid numpy type."

# in diff.py
PROGRESS_MSG = "DeepDiff {} seconds in progress. Pass #{}, Diff #{}"
INVALID_VIEW_MSG = "view parameter must be one of 'text', 'tree', 'delta', 'colored' or 'colored_compact'. But {} was passed."
DISTANCE_CALCS_NEEDS_CACHE = "Distance calculation can not happen once the cache is purged. Try with _cache='keep'"

# in helper.py
DELTA_VIEW = '_delta'
ENUM_INCLUDE_KEYS: List[str] = ['__objclass__', 'name', 'value']

# in serialization.py
MODULE_NOT_FOUND_MSG = 'DeepDiff Delta did not find {} in your modules. Please make sure it is already imported.'
FORBIDDEN_MODULE_MSG = "Module '{}' is forbidden. You need to explicitly pass it by passing a safe_to_import parameter"
DELTA_IGNORE_ORDER_NEEDS_REPETITION_REPORT = 'report_repetition must be set to True when ignore_order is True to create the delta object.'
DELTA_ERROR_WHEN_GROUP_BY = 'Delta can not be made when group_by is used since the structure of data is modified from the original form.'

# in __init__.py
__version__ = '8.6.1'
```
## Detailed Explanation of Configuration Classes

### 1. Comparison Configuration Options

**ignore_order**: Controls whether to ignore the order
- `True`: Ignore the order of containers such as lists and sets
- `False`: Strictly compare the order (default)

**ignore_private_variables**: Controls whether to ignore private variables
- `True`: Ignore attributes starting with `_` (default)
- `False`: Include private variables

**ignore_string_case**: Controls case comparison for strings
- `True`: Ignore case
- `False`: Distinguish case (default)

**ignore_numeric_type_changes**: Controls numeric type changes
- `True`: Ignore differences between int and float types
- `False`: Strictly compare types (default)

### 2. Path Filtering Configuration

**exclude_paths**: Exclude specific paths
```python
exclude_paths=["root['metadata']", "root['timestamp']"]
```

**include_paths**: Only include specific paths
```python
include_paths=["root['data']", "root['result']"]
```

**exclude_regex_paths**: Use regular expressions to exclude paths
```python
exclude_regex_paths=[r"root\[\d+\]", r"root\['temp_.*'\]"]
```

## 3. Performance Configuration Options

**cache_size**: Cache size
