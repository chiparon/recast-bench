### 33._get_date_distance() Function - Get Date Distance

**Function**: Get the distance between two date objects.

**Function Signature**:
```python
def _get_date_distance(date1, date2, max_, use_log_scale, log_scale_similarity_threshold):
```

**Parameter Description**:
- `date1` (datetime.date): The first date object
- `date2` (datetime.date): The second date object
- `max_` (int): The maximum value
- `use_log_scale` (bool): Whether to use log scale
- `log_scale_similarity_threshold` (float): The threshold for the similarity

**Return Value**: The distance between the two date objects

### 34._get_timedelta_distance() Function - Get Timedelta Distance

**Function**: Get the distance between two timedelta objects.

**Function Signature**:
```python
def _get_timedelta_distance(timedelta1, timedelta2, max_, use_log_scale, log_scale_similarity_threshold):
```

**Parameter Description**:
- `timedelta1` (datetime.timedelta): The first timedelta object
- `timedelta2` (datetime.timedelta): The second timedelta object
- `max_` (int): The maximum value
- `use_log_scale` (bool): Whether to use log scale
- `log_scale_similarity_threshold` (float): The threshold for the similarity

**Return Value**: The distance between the two timedelta objects

### 35._get_time_distance() Function - Get Time Distance

**Function**: Get the distance between two time objects.

**Function Signature**:
```python
def _get_time_distance(time1, time2, max_, use_log_scale, log_scale_similarity_threshold):
```

**Parameter Description**:
- `time1` (datetime.time): The first time object
- `time2` (datetime.time): The second time object
- `max_` (int): The maximum value
- `use_log_scale` (bool): Whether to use log scale
- `log_scale_similarity_threshold` (float): The threshold for the similarity

**Return Value**: The distance between the two time objects

### 36._int_or_zero() Function - Int or Zero

**Function**: Extract a number from a string.

**Function Signature**:
```python
def _int_or_zero(value: str) -> int:
```

**Parameter Description**:
- `value` (str): The string to extract the number from

**Return Value**: The extracted number

### 37.add_to_frozen_set() Function - Add to Frozen Set

**Function**: Add an item to a frozen set.

**Function Signature**:
```python
def add_to_frozen_set(parents_ids: FrozenSet[int], item_id: int) -> FrozenSet[int]:
```

**Parameter Description**:
- `parents_ids` (FrozenSet[int]): The frozen set to add the item to
- `item_id` (int): The item to add to the frozen set

**Return Value**: The frozen set with the item added

### 38.convert_item_or_items_into_set_else_none() Function - Convert Item or Items into Set Else None

**Function**: Convert an item or items into a set.

**Function Signature**:
```python
def convert_item_or_items_into_set_else_none(items: Union[str, Iterable[str], None]) -> Optional[Set[str]]:
```

**Parameter Description**:
- `items` (Union[str, Iterable[str], None]): The items to convert into a set

**Return Value**: The set of items

### 39.convert_item_or_items_into_compiled_regexes_else_none() Function - Add Root to Paths

**Function**: Convert an item or items into a list of compiled regexes.

**Function Signature**:
```python
def convert_item_or_items_into_compiled_regexes_else_none(items: Union[str, Pattern[str], Iterable[Union[str, Pattern[str]]], None]) -> Optional[List[Pattern[str]]]:
```

**Parameter Description**:
- `items` (Union[str, Pattern[str], Iterable[Union[str, Pattern[str]]], None]): The items to convert into a list of compiled regexes

**Return Value**: The list of compiled regexes

### 40.get_type() Function - Get Type

**Function**: Get the type of an object.

**Function Signature**:
```python
def get_type(obj: Any) -> Type[Any]:
```

**Parameter Description**:
- `obj` (Any): The object to get the type of

**Return Value**: The type of the object

### 41.numpy_dtype_string_to_type() Function - Numpy Dtype String to Type

**Function**: Convert a numpy dtype string to a type.

**Function Signature**:
```python
def numpy_dtype_string_to_type(dtype_str: str) -> Type[Any]:
```

**Parameter Description**:
- `dtype_str` (str): The numpy dtype string to convert to a type

**Return Value**: The type of the numpy dtype string

### 42.type_in_type_group() Function - Type in Type Group

**Function**: Check if a type is in a type group.

**Function Signature**:
```python
def type_in_type_group(item: Any, type_group: Tuple[Type[Any], ...]) -> bool:
```

**Parameter Description**:
- `item` (Any): The item to check if it is in the type group
- `type_group` (Tuple[Type[Any], ...]): The type group to check if the item is in

**Return Value**: True if the item is in the type group, False otherwise

### 43.type_is_subclass_of_type_group() Function - Type is Subclass of Type Group

**Function**: Check if a type is a subclass of a type group.

**Function Signature**:
```python
def type_is_subclass_of_type_group(item: Any, type_group: Tuple[Type[Any], ...]) -> bool:
```

**Parameter Description**:
- `item` (Any): The item to check if it is a subclass of the type group
- `type_group` (Tuple[Type[Any], ...]): The type group to check if the item is a subclass of

**Return Value**: True if the item is a subclass of the type group, False otherwise

### 44.get_doc() Function - Get Doc

**Function**: Get the documentation for a module.

**Function Signature**:
```python
def get_doc(doc_filename: str) -> str:
```

**Parameter Description**:
- `doc_filename` (str): The filename of the documentation to get

**Return Value**: The documentation

### 45._eval_decimal() Function - Eval Decimal

**Function**: Evaluate a decimal.

**Function Signature**:
```python
def _eval_decimal(params: str) -> Decimal:
```

**Parameter Description**:
- `params` (str): The parameters to evaluate

**Return Value**: The evaluated decimal

### 46._eval_datetime() Function - Eval Datetime

**Function**: Evaluate a datetime.

**Function Signature**:
```python
def _eval_datetime(params: str) -> datetime.datetime:
```

**Parameter Description**:
- `params` (str): The parameters to evaluate

**Return Value**: The evaluated datetime

### 47._eval_date() Function - Eval Date

**Function**: Evaluate a date.

**Function Signature**:
```python
def _eval_date(params: str) -> datetime.date:
```

**Parameter Description**:
- `params` (str): The parameters to evaluate

**Return Value**: The evaluated date

### 48.time_to_seconds() Function - Time to Seconds

**Function**: Convert a time object to seconds.

**Function Signature**:
```python
def time_to_seconds(t: datetime.time) -> int:
```

**Parameter Description**:
- `t` (datetime.time): The time object to convert to seconds

**Return Value**: The time object converted to seconds

### 49.has_timezone() Function - Has Timezone

**Function**: Check if a datetime object has a timezone.

**Function Signature**:
```python
def has_timezone(dt: datetime.datetime) -> bool:
```

**Parameter Description**:
- `dt` (datetime.datetime): The datetime object to check if it has a timezone

**Return Value**: True if the datetime object has a timezone, False otherwise

### 50.get_homogeneous_numpy_compatible_type_of_seq() Function - Get Homogeneous Numpy Compatible Type of Sequence

**Function**: Get the homogeneous numpy compatible type of a sequence.

**Function Signature**:
```python
def get_homogeneous_numpy_compatible_type_of_seq(seq: Sequence[Any]) -> Union[Type[Any], Literal[False]]:
```

**Parameter Description**:
- `seq` (Sequence[Any]): The sequence to get the homogeneous numpy compatible type of

**Return Value**: The homogeneous numpy compatible type of the sequence

### 51.named_tuple_repr() Function - Named Tuple Repr

**Function**: Represent a named tuple.

**Function Signature**:
```python
def named_tuple_repr(self: NamedTuple) -> str:
```

**Parameter Description**:
- `self` (NamedTuple): The named tuple to represent

**Return Value**: The represented named tuple

### 52._report_progress() Function - Report Progress

**Function**: Report the progress of a comparison.

**Function Signature**:
```python
def _report_progress(_stats: Dict[str, Any], progress_logger: Callable[[str], None], duration: float) -> None:
```

**Parameter Description**:
- `_stats` (Dict[str, Any]): The statistics of the comparison
- `progress_logger` (Callable[[str], None]): The progress logger
- `duration` (float): The duration of the comparison

**Return Value**: None

### 53.sha1hex() Function - SHA1 Hex

**Function**: Convert a string to a SHA1 hash.

**Function Signature**:
```python
def sha1hex(obj: Union[str, bytes]) -> str:
```

**Parameter Description**:
- `text` (str): The string to convert to a SHA1 hash

**Return Value**: The SHA1 hash

### 54._get_nested_obj() Function - Get Nested Obj

**Function**: Get a nested object.

**Function Signature**:
```python
def _get_nested_obj(obj, elements, next_element=None):
```

**Parameter Description**:
- `obj` (Any): The object to get the nested object from
- `elements` (List[Tuple[Any, str]]): The elements of the path
- `next_element` (Any): The next element of the path

**Return Value**: The nested object

### 55._guess_type() Function - Guess Type

**Function**: Guess the type of an object.

**Function Signature**:
```python
def _guess_type(elements, elem, index, next_element):
```

**Parameter Description**:
- `elements` (List[Tuple[Any, str]]): The elements of the path
- `elem` (str): The element to guess the type of
- `index` (int): The index of the element
- `next_element` (Any): The next element of the path

**Return Value**: The guessed type of the object

### 56.check_elem() Function - Check Elem

**Function**: Check if an element is valid.

**Function Signature**:
```python
def check_elem(elem) -> None:
```

**Parameter Description**:
- `elem` (Any): The element to check if it is valid

**Return Value**: None

### 57._get_nested_obj_and_force() Function - Get Nested Obj and Force

**Function**: Get a nested object and force it to be a dictionary.

**Function Signature**:
```python
def _get_nested_obj_and_force(obj, elements, next_element=None):
```

**Parameter Description**:
- `obj` (Any): The object to get the nested object from
- `elements` (List[Tuple[Any, str]]): The elements of the path
- `next_element` (Optional[Any]): The next element of the path

**Return Value**: The nested object

### 58.stringify_element() Function - Stringify Element

**Function**: Stringify an element.

**Function Signature**:
```python
def stringify_element(param, quote_str=None) -> str:
```

**Parameter Description**:
- `param` (Any): The element to stringify
- `quote_str` (Optional[str]): The quote string

**Return Value**: The stringified element

### 59._get_pretty_form_text() Function - Get Pretty Form Text

**Function**: Get the pretty form text.

**Function Signature**:
```python
def _get_pretty_form_text(verbose_level) -> str:
```

**Parameter Description**:
- `verbose_level` (int): The verbose level

**Return Value**: The pretty form text

### 60.save_content_to_path() Function - Save Content to Path

**Function**: Save content to a path.

**Function Signature**:
```python
def save_content_to_path(content, path, file_type=None, keep_backup=True) -> None:
```

**Parameter Description**:
- `content` (Any): The content to save
- `path` (str): The path to save the content to
- `file_type` (Optional[str]): The file type to save the content as
- `keep_backup` (bool): Whether to keep the backup

**Return Value**: None

### 61._save_content() Function - Save Content

**Function**: Save content to a path.

**Function Signature**:
```python
def _save_content(content, path, file_type, keep_backup=True) -> None:
```

**Parameter Description**:
- `content` (Any): The content to save
- `path` (str): The path to save the content to
- `file_type` (Optional[str]): The file type to save the content as
- `keep_backup` (bool): Whether to keep the backup

**Return Value**: None

### 62._serialize_decimal() Function - Serialize Decimal

**Function**: Serialize a decimal.

**Function Signature**:
```python
def _serialize_decimal(value) -> str:
```

**Parameter Description**:
- `value` (Decimal): The decimal to serialize

**Return Value**: The serialized decimal

### 63._serialize_tuple() Function - Serialize Tuple

**Function**: Serialize a tuple.

**Function Signature**:
```python
def _serialize_tuple(value) -> str:
```

**Parameter Description**:
- `value` (Tuple): The tuple to serialize

**Return Value**: The serialized tuple

### 64._serialize_bytes() Function - Serialize Bytes

**Function**: Serialize a bytes object.

**Function Signature**:
```python
def _serialize_bytes(value) -> str:
```

**Parameter Description**:
- `value` (bytes): The bytes object to serialize

**Return Value**: The serialized bytes object

### 65.json_convertor_default() Function - JSON Convertor Default

**Function**: Convert a default object to a JSON object.

**Function Signature**:
```python
def json_convertor_default(default_mapping=None) -> Callable:
```

**Parameter Description**:
- `default_mapping` (Optional[dict]): The default mapping to convert the object to

**Return Value**: The JSON convertor default

### 66.ensure_dir() Function - Ensure Dir

**Function**: Ensure a directory exists.

**Function Signature**:
```python
def ensure_dir(file_path) -> None:
```

**Parameter Description**:
- `file_path` (str): The path to ensure exists

**Return Value**: None

### 67.delete_dir_contents() Function - Delete Dir Contents

**Function**: Delete the contents of a directory.

**Function Signature**:
```python
def delete_dir_contents(directory) -> None:
```

**Parameter Description**:
- `directory` (str): The directory to delete the contents of

**Return Value**: None

#### 68. `ColoredView` class - JSON Difference Color-coded View

**Function**: Display JSON data with color-coded differences

**Class Definition**:
```python
class ColoredView:
    def __init__(self, t2: Any, tree_result: TreeResult, compact: bool = False) -> None
```

**Key Parameters**:
- `t2` (Any): JSON data object to display
- `tree_result` (TreeResult): Tree difference comparison result
- `compact` (bool): Whether to display in compact mode, defaults to False

**Attributes**:
- `diff_paths` (Dict[str, str]): Dictionary storing all difference paths and their types

**Methods**:

1. `_collect_diff_paths() -> Dict[str, str]`
   - **Function**: Collect all paths with differences and their types
   - **Returns**: Dictionary containing difference paths and types
   - **Details**: Extracts different types of differences from TextResult (value changes, type changes, added items, removed items)

2. `_format_value(value: Any) -> str`
   - **Function**: Format value for display
   - **Parameters**: 
     - `value`: Any value to format
   - **Returns**: Formatted string
   - **Details**: Handles different types like boolean, string, dictionary, list, etc.

3. `_get_path_removed(path: str) -> dict`
   - **Function**: Get all removed items for a given path
   - **Parameters**:
     - `path`: Path to check
   - **Returns**: Dictionary containing removed items

4. `_has_differences(path_prefix: str) -> bool`
   - **Function**: Check if a path prefix has any differences under it
   - **Parameters**:
     - `path_prefix`: Path prefix to check
   - **Returns**: Boolean value indicating whether differences exist

5. `_colorize_json(obj: Any, path: str = 'root', indent: int = 0) -> str`
   - **Function**: Recursively colorize JSON based on differences, with pretty-printing
   - **Parameters**:
     - `obj`: Object to colorize
     - `path`: Current path, defaults to 'root'
     - `indent`: Indentation level, defaults to 0
   - **Returns**: Color-coded JSON string
   - **Details**: Uses red to mark removed/old values, green to mark added/new values

6. `__str__() -> str`
   - **Function**: Return color-coded, pretty-printed JSON string
   - **Returns**: Formatted string

7. `__iter__()`
   - **Function**: Make the view iterable by yielding tree result items


#### 69. `DistanceMixin` class - Distance Calculation Mixin

**Function**: Provides methods to calculate the difference distance between two objects

**Class Definition**:
```python
class DistanceMixin:
```

**Methods**:

1. `_get_rough_distance(self: "DistanceProtocol") -> float`
   - **Function**: Calculate numerical distance between t1 and t2 based on number of conversion operations needed
   - **Returns**: Float distance value between 0 and 1
   - **Details**: 
     - Distance 0 means objects are equal, distance 1 means very different
     - Similar to Levenshtein Edit Distance but for structured data
     - Current algorithm based on number of operations needed to convert t1 to t2 divided by number of items in t1 and t2

2. `__get_item_rough_length(self: "DistanceProtocol", item, parent='root') -> int`
   - **Function**: Get rough length of an item, used for calculating rough distance between objects
   - **Parameters**:
     - `item`: Item to calculate length for
     - `parent`: Only used for DeepHash reporting purposes
   - **Returns**: Rough length of the item
   - **Exceptions**: Throws `RuntimeError` if no hash cache exists

3. `__calculate_item_deephash(self: "DistanceProtocol", item: Any) -> None`
   - **Function**: Calculate DeepHash value for an item
   - **Parameters**:
     - `item`: Item to calculate hash for
   - **Details**: Uses DeepHash to calculate and store item's hash value

4. `_precalculate_distance_by_custom_compare_func(self: "DistanceProtocol", hashes_added, hashes_removed, t1_hashtable, t2_hashtable, _original_type) -> dict`
   - **Function**: Pre-calculate distances using custom comparison function
   - **Parameters**:
     - `hashes_added`: List of hashes for added items
     - `hashes_removed`: List of hashes for removed items
     - `t1_hashtable`: Hash table for t1
     - `t2_hashtable`: Hash table for t2
     - `_original_type`: Original type
   - **Returns**: Dictionary of pre-calculated distances
   - **Details**: Pairwise comparison of added and removed items using custom comparison function

5. `_precalculate_numpy_arrays_distance(self: "DistanceProtocol", hashes_added, hashes_removed, t1_hashtable, t2_hashtable, _original_type) -> dict`
   - **Function**: Pre-calculate distances between numpy arrays
   - **Parameters**: Same as above
   - **Returns**: Dictionary of distances between numpy arrays
   - **Details**: 
     - Only handles 1D arrays
     - Uses numpy array operations and Cartesian product to calculate distances
     - Supports log scale distance calculation
        

### 70.DoesNotExist Class

**Function**: Not implemented.

**Class Definition**:
```python
class DoesNotExist(Exception):
    """
    Exception raised when a required item does not exist
    
    Used in various contexts where an expected item or value is not found.
    """
    pass
```

### 71.ResultDict Class

**Function**: A dictionary that represents a result.

**Class Definition**:
```python
class ResultDict(RemapDict):
    """
    Base class for result dictionaries
    
    Used to store and manipulate comparison results from DeepDiff.
    """

    def remove_empty_keys(self) -> None:
        """
        Remove empty keys from this object. Should always be called after the result is final.
        :return:
        """
```

### 72.DeltaResult Class

**Function**: A result that represents a delta.

**Class Definition**:
```python
class DeltaResult(TextResult):
    """
    Result format for Delta operations
    
    Specifically designed for storing and displaying results of Delta operations.
    """
    ADD_QUOTES_TO_STRINGS: bool = False

    def __init__(self, tree_results: Optional['TreeResult'] = None, ignore_order: Optional[bool] = None, always_include_values: bool = False, _iterable_opcodes: Optional[Dict[str, Any]] = None) -> None:
        self.ignore_order = ignore_order
        self.always_include_values = always_include_values

        self.update({
            "type_changes": dict_(),
            "dictionary_item_added": dict_(),
            "dictionary_item_removed": dict_(),
            "values_changed": dict_(),
            "iterable_item_added": dict_(),
            "iterable_item_removed": dict_(),
            "iterable_item_moved": dict_(),
            "attribute_added": dict_(),
            "attribute_removed": dict_(),
            "set_item_removed": dict_(),
            "set_item_added": dict_(),
            "iterable_items_added_at_indexes": dict_(),
            "iterable_items_removed_at_indexes": dict_(),
            "_iterable_opcodes": _iterable_opcodes or {},
        })

        if tree_results:
            self._from_tree_results(tree_results)

    def _from_tree_results(self, tree):
        """
        Populate this object by parsing an existing reference-style result dictionary.
        :param tree: A TreeResult
        :return:
        """
        

    def _from_tree_iterable_item_added_or_removed(self, tree, report_type, delta_report_key):
        """
        Process iterable items added or removed from tree
        
        Args:
            tree: Tree structure to process
            report_type: Type of report
            delta_report_key: Key for delta report
        """
        

    def _from_tree_type_changes(self, tree):
        """
        Process type changes from tree
        
        Args:
            tree: Tree structure to process
        """
        

    def _from_tree_value_changed(self, tree):
        """
        Process value changes from tree
        
        Args:
            tree: Tree structure to process
        """
        
                # If we ever want to store the difflib results instead of the new_value
                # these lines need to be uncommented and the Delta object needs to be able
                # to use them.
                # if 'diff' in change.additional:
                #     the_changed.update({'diff': change.additional['diff']})

    def _from_tree_repetition_change(self, tree):
        """
        Process repetition changes from tree
        
        Args:
            tree: Tree structure to process
        """
        
    def _from_tree_iterable_item_moved(self, tree):
        """
        Process iterable item moves from tree
        
        Args:
            tree: Tree structure to process
        """
        
```

### 73.NumpyArrayRelationship Class

**Function**: A relationship that describes the relationship between a container object (the "parent") and the contained "child" object.

**Class Definition**:
```python
class NumpyArrayRelationship(ChildRelationship):
    """
    Specific implementation of NumPy array relationships
    
    Describes relationships between elements in NumPy arrays.
    """

```

### 74.InaccessibleRelationship Class

**Function**: Not implemented.

**Class Definition**:
```python
class InaccessibleRelationship(ChildRelationship):
    """
    Base class for inaccessible relationships
    
    Used for relationships that cannot be directly accessed or represented as strings.
    """
    pass
```

### 75.SetRelationship Class

**Function**: Not implemented.

**Class Definition**:
```python
class SetRelationship(InaccessibleRelationship):
    """
    Specific implementation of set relationships
    
    Describes relationships between elements in sets (set elements cannot 
    be directly accessed).
    """
    pass
```

### 76.np_type Class

**Function**: Not implemented.

**Class Definition**:
```python
class np_type:
    pass
```

### 77.pydantic_base_model_type Class

**Function**: Not implemented.

**Class Definition**:
```python
class pydantic_base_model_type:
    pass
```

### 78.EnumBase Class

**Function**: A base class for enums.

**Class Definition**:
```python
class EnumBase(str, enum.Enum):
    def __repr__(self) -> str:
        """
        We need to add a single quotes so we can easily copy the value when we do ipdb.
        """
        

    def __str__(self) -> str:
```
