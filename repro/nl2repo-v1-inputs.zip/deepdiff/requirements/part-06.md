
### 79.IndexedHash Class

**Function**: A class that represents an indexed hash.

**Class Definition**:
```python
class IndexedHash(NamedTuple):
    """
    Indexed hash item
    
    Stores hash values with corresponding index information.
    """
    indexes: List[Any]
    item: Any
```

### 80.ListItemRemovedOrAdded Class

**Function**: Not implemented.

**Class Definition**:
```python
class ListItemRemovedOrAdded:
    pass
```

### 81.OtherTypes Class

**Function**: A class that represents other types.

**Class Definition**:
```python
class OtherTypes:
    def __repr__(self) -> str:
        
```

### 82.Skipped Class

**Function**: Not implemented.

**Class Definition**:
```python
class Skipped(OtherTypes):
    pass
```

### 83.Unprocessed Class

**Function**: Not implemented.

**Class Definition**:
```python
class Unprocessed(OtherTypes):
    pass
```

### 84.NotHashed Class

**Function**: Not implemented.

**Class Definition**:
```python
class NotHashed(OtherTypes):
    pass
```

### 85.NotPresent Class

**Function**: A class that represents a not present object.

**Class Definition**:
```python
class NotPresent:  # pragma: no cover
    """
    In a change tree, this indicated that a previously existing object has been removed -- or will only be added
    in the future.
    We previously used None for this but this caused problem when users actually added and removed None. Srsly guys? :D
    """

    def __repr__(self) -> str:
        
```

### 86.indexed_set Class

**Function**: A set class that lets you get an item by index.

**Class Definition**:
```python
class indexed_set(set):
    """
    A set class that lets you get an item by index

    >>> a = indexed_set()
    >>> a.add(10)
    >>> a.add(20)
    >>> a[0]
    10
    """
```

### 87.DeepDiffDeprecationWarning Class

**Function**: A warning that is raised when a deprecated feature is used.

**Class Definition**:
```python
class DeepDiffDeprecationWarning(DeprecationWarning):
    pass
```

### 88._NotFound Class

**Function**: A class that represents a not found object.

**Class Definition**:
```python
class _NotFound:

    def __eq__(self, other: Any) -> bool:
        return False

    __req__ = __eq__

    def __repr__(self) -> str:
        return 'not found'

    __str__ = __repr__


not_found = _NotFound()

warnings.simplefilter('once', DeepDiffDeprecationWarning)

```

### 89.RepeatedTimer Class

**Function**: A threaded repeated timer.

**Class Definition**:
```python
class RepeatedTimer:
    """
    Threaded Repeated Timer by MestreLion
    https://stackoverflow.com/a/38317060/1497443
    """

    def __init__(self, interval: float, function: Callable[..., Any], *args: Any, **kwargs: Any) -> None:
        self._timer = None
        self.interval = interval
        self.function = function
        self.args = args
        self.start_time = time.time()
        self.kwargs = kwargs
        self.is_running = False
        self.start()

    def _get_duration_sec(self) -> int:
        """
        Get duration in seconds
        
        Returns:
            int: Duration in seconds
        """


    def _run(self) -> None:
        """
        Run the timer function
        """

    def start(self) -> None:
        """
        Start the timer
        """


    def stop(self) -> int:
        """
        Stop the timer
        
        Returns:
            int: Duration in seconds
        """

```

### 90.OpcodeTag Class

**Function**: A tag that represents an opcode.

**Class Definition**:
```python
class OpcodeTag(EnumBase):
    insert = 'insert'
    delete = 'delete'
    equal = 'equal'
    replace = 'replace'  # type: ignore
    # swapped = 'swapped'  # in the future we should support reporting of items swapped with each other


```

### 91.CacheNode Class

**Function**: A node that represents a cache.

**Class Definition**:
```python
class CacheNode:
    """
    Node in the LFU cache structure
    
    Represents a single cache entry with frequency tracking and linked list pointers.
    """
    def __init__(self, key, report_type, value, freq_node, pre, nxt):
        self.key = key
        if report_type:
            self.content = defaultdict(SetOrdered)
            self.content[report_type].add(value)
        else:
            self.content = value
        self.freq_node = freq_node
        self.pre = pre  # previous CacheNode
        self.nxt = nxt  # next CacheNode

    def free_myself(self):
        """
        Free the cache node from the linked list
        """
        
```    

### 92.FreqNode Class

**Function**: A node that represents a frequency.

**Class Definition**:
```python
class FreqNode:
    """
    Frequency node in the LFU cache structure
    
    Represents a frequency level with associated cache nodes and linked list pointers.
    """
    def __init__(self, freq, pre, nxt):
        self.freq = freq
        self.pre = pre  # previous FreqNode
        self.nxt = nxt  # next FreqNode
        self.cache_head = None  # CacheNode head under this FreqNode
        self.cache_tail = None  # CacheNode tail under this FreqNode

    def count_caches(self):
        """
        Count the number of cache nodes under this frequency node
        
        Returns:
            int: Number of cache nodes
        """


    def remove(self):
        """
        Remove this frequency node from the linked list
        """



    def pop_head_cache(self):
        """
        Pop the head cache node from this frequency node
        
        Returns:
            CacheNode: The head cache node
        """


    def append_cache_to_tail(self, cache_node):
        """
        Append a cache node to the tail of this frequency node
        
        Args:
            cache_node: Cache node to append
        """


    def insert_after_me(self, freq_node):
        """
        Insert a frequency node after this one
        
        Args:
            freq_node: Frequency node to insert
        """


    def insert_before_me(self, freq_node):
        """
        Insert a frequency node before this one
        
        Args:
            freq_node: Frequency node to insert
        """
```

### 93.DummyLFU Class

**Function**: A dummy LFU.

**Class Definition**:
```python
class DummyLFU:
    """
    Dummy LFU cache implementation
    
    A no-op cache implementation used when caching is disabled.
    """

```

### 94.DeepDiffProtocol Class

**Function**: A protocol that represents a deep diff.

**Class Definition**:
```python
class DeepDiffProtocol(Protocol):
    t1: Any
    t2: Any
    cutoff_distance_for_pairs: float
    use_log_scale: bool
    log_scale_similarity_threshold: float
    view: str
    math_epsilon: Optional[float]
```

### 95.SerializationMixin Class

**Function**: A mixin that provides serialization functionality.

**Class Definition**:
```python
class SerializationMixin:
    """
    Mixin class providing serialization functionality
    
    Adds methods for converting DeepDiff objects to various serialized formats 
    including JSON, pickle, and other formats.
    """

    def to_json_pickle(self):
        """
        :ref:`to_json_pickle_label`
        Get the json pickle of the diff object. Unless you need all the attributes and functionality of DeepDiff, running to_json() is the safer option that json pickle.
        """
        try:

        except ImportError:  # pragma: no cover. Json pickle is getting deprecated.


    @classmethod
    def from_json_pickle(cls, value):
        """
        :ref:`from_json_pickle_label`
        Load DeepDiff object with all the bells and whistles from the json pickle dump.
        Note that json pickle dump comes from to_json_pickle
        """
        try:

        except ImportError:  # pragma: no cover. Json pickle is getting deprecated.


    def to_json(self, default_mapping: Optional[dict]=None, force_use_builtin_json=False, **kwargs):
        """
        Dump json of the text view.
        **Parameters**

        default_mapping : dictionary(optional), a dictionary of mapping of different types to json types.

        by default DeepDiff converts certain data types. For example Decimals into floats so they can be exported into json.
        If you have a certain object type that the json serializer can not serialize it, please pass the appropriate type
        conversion through this dictionary.

        force_use_builtin_json: Boolean, default = False
            When True, we use Python's builtin Json library for serialization,
            even if Orjson is installed.


        kwargs: Any other kwargs you pass will be passed on to Python's json.dumps()

        **Example**

        Serialize custom objects
            >>> class A:
            ...     pass
            ...
            >>> class B:
            ...     pass
            ...
            >>> t1 = A()
            >>> t2 = B()
            >>> ddiff = DeepDiff(t1, t2)
            >>> ddiff.to_json()
            TypeError: We do not know how to convert <__main__.A object at 0x10648> of type <class '__main__.A'> for json serialization. Please pass the default_mapping parameter with proper mapping of the object to a basic python type.

            >>> default_mapping = {A: lambda x: 'obj A', B: lambda x: 'obj B'}
            >>> ddiff.to_json(default_mapping=default_mapping)
            '{"type_changes": {"root": {"old_type": "A", "new_type": "B", "old_value": "obj A", "new_value": "obj B"}}}'
        """


    def to_dict(self, view_override: Optional[str]=None) -> dict:
        """
        convert the result to a python dictionary. You can override the view type by passing view_override.

        **Parameters**

        view_override: view type, default=None,
            override the view that was used to generate the diff when converting to the dictionary.
            The options are the text or tree.
        """

    def _to_delta_dict(
        self,
        directed: bool = True,
        report_repetition_required: bool = True,
        always_include_values: bool = False,
    ) -> dict:
        """
        Dump to a dictionary suitable for delta usage.
        Unlike to_dict, this is not dependent on the original view that the user chose to create the diff.

        **Parameters**

        directed : Boolean, default=True, whether to create a directional delta dictionary or a symmetrical

        Note that in the current implementation the symmetrical delta (non-directional) is ONLY used for verifying that
        the delta is being applied to the exact same values as what was used to generate the delta and has
        no other usages.

        If this option is set as True, then the dictionary will not have the "old_value" in the output.
        Otherwise it will have the "old_value". "old_value" is the value of the item in t1.

        If delta = Delta(DeepDiff(t1, t2)) then
        t1 + delta == t2

        Note that it the items in t1 + delta might have slightly different order of items than t2 if ignore_order
        was set to be True in the diff object.

        """
       

    def pretty(self, prefix: Optional[Union[str, Callable]]=None):
        """
        The pretty human readable string output for the diff object
        regardless of what view was used to generate the diff.

        prefix can be a callable or a string or None.

        Example:
            >>> t1={1,2,4}
            >>> t2={2,3}
            >>> print(DeepDiff(t1, t2).pretty())
            Item root[3] added to set.
            Item root[4] removed from set.
            Item root[1] removed from set.
        """

```

### 96._RestrictedUnpickler Class

**Function**: A unpickler that restricts the classes that can be loaded.

**Class Definition**:
```python
class _RestrictedUnpickler(pickle.Unpickler):

    def __init__(self, *args, **kwargs):
        self.safe_to_import = kwargs.pop('safe_to_import', None)
        if self.safe_to_import:
            if isinstance(self.safe_to_import, strings):
                self.safe_to_import = set([self.safe_to_import])
            elif isinstance(self.safe_to_import, (set, frozenset)):
                pass
            else:
                self.safe_to_import = set(self.safe_to_import)
            self.safe_to_import = self.safe_to_import | SAFE_TO_IMPORT
        else:
            self.safe_to_import = SAFE_TO_IMPORT
        super().__init__(*args, **kwargs)

    def find_class(self, module, name):
        """
        Find and load a class from a module
        
        Args:
            module: Module name
            name: Class name
            
        Returns:
            class: The loaded class
            
        Raises:
            pickle.UnpicklingError: If class is not safe to import
        """
        # Only allow safe classes from self.safe_to_import.
        
    def persistent_load(self, pid):
        """
        Load a persistent object by ID
        
        Args:
            pid: Persistent object ID
            
        Returns:
            object: The loaded persistent object
        """
```

### 97._RestrictedPickler Class

**Function**: A pickler that restricts the classes that can be serialized.

**Class Definition**:
```python

class _RestrictedPickler(pickle.Pickler):
    def persistent_id(self, obj):
        if obj is NONE_TYPE:  # NOQA
            return "<<NoneType>>"
        return None

```

### 98.JSONDecoder Class

**Function**: A decoder that decodes JSON.

**Class Definition**:
```python
class JSONDecoder(json.JSONDecoder):

    def __init__(self, *args, **kwargs):
        json.JSONDecoder.__init__(self, object_hook=self.object_hook, *args, **kwargs)

    def object_hook(self, obj):  # type: ignore
        """
        Object hook for JSON decoding
        
        Args:
            obj: Object to process
            
        Returns:
            object: Processed object
        """
```
#### 99 FIXTURES_DIR constant

**Function**: The path to the fixtures directory.
**Value**: os.path.join(os.path.dirname(__file__), 'tests/fixtures/')
**Type**: String

### 100.GREEN constant

**Function**: The green color.
**Value**: '\033[92m'
**Type**: String

### 101.RESET constant

**Function**: The reset color.
**Value**: '\033[0m'
**Type**: String

### 102.TYPES_TO_DIST_FUNC constant

**Function**: The types to distance function.
**Value**: [(only_numbers, _get_numbers_distance), (datetime.datetime, _get_datetime_distance), (datetime.date, _get_date_distance), (datetime.timedelta, _get_timedelta_distance), (datetime.time, _get_time_distance)]
**Type**: List of tuples

### 103.FORCE_DEFAULT constant

**Function**: The force default.
**Value**: 'fake'
**Type**: Literal

### 104.UP_DOWN constant

**Function**: The up down.
**Value**: ('UP', 'DOWN')
**Type**: Tuple

### 105.REPORT_KEYS constant

**Function**: The report keys.
**Value**: ('type_changes', 'values_changed', 'iterable_item_added', 'iterable_item_removed', 'iterable_item_moved', 'iterable_items_inserted', 'iterable_items_deleted', 'iterable_items_replaced', 'iterable_items_equal', 'dictionary_item_added', 'dictionary_item_removed', 'attribute_removed', 'attribute_added', 'initiated')
**Type**: Tuple

### 106.CUSTOM_FIELD constant

**Function**: The custom field.
**Value**: 'custom_field'
**Type**: String

### 107.NUMERICS constant

**Function**: The numerics.
**Value**: ('int', 'float', 'complex', 'Decimal')
**Type**: Tuple

### 108.ID_PREFIX constant

**Function**: The id prefix.
**Value**: 'id_'
**Type**: String

### 109.KEY_TO_VAL_STR constant

**Function**: The key to value string.
**Value**: 'key_to_val_str'
**Type**: String

### 110.TREE_VIEW constant

**Function**: The tree view.
**Value**: 'tree'
**Type**: String

### 111.COLORED_VIEW constant

**Function**: The colored view.
**Value**: 'colored'
**Type**: String

### 112.COLORED_COMPACT_VIEW constant

**Function**: The colored compact view.
**Value**: 'colored_compact'
**Type**: String

### 113.RE_COMPILED_TYPE constant

**Function**: The re compiled type.
**Value**: type(re.compile(''))
**Type**: Type

### 114.LITERAL_EVAL_PRE_PROCESS constant

**Function**: The literal eval pre process.
**Value**: [('Decimal(', ')', _eval_decimal), ('datetime.datetime(', ')', _eval_datetime), ('datetime.date(', ')', _eval_date)]
**Type**: List of tuples

### 115.PYTHON_TYPE_TO_NUMPY_TYPE constant

**Function**: The python type to numpy type.
**Value**: {
    'int': np.int32,
    'float': np.float32,
    'complex': np.complex64,
    'Decimal': np.float64,
}
**Type**: Dictionary

### 116.OPCODE_TAG_TO_FLAT_DATA_ACTION constant

**Function**: The opcode tag to flat data action.
**Value**: {
    'ADD': 'add',
    'REMOVE': 'remove',
    'REPLACE': 'replace',
    'EQUAL': 'equal',
    'MOVE': 'move',
    'INSERT': 'insert',
    'DELETE': 'delete',
}
**Type**: Dictionary

### 117.FLAT_DATA_ACTION_TO_OPCODE_TAG constant

**Function**: The flat data action to opcode tag.
**Value**: {
    'add': 'ADD',
    'remove': 'REMOVE',
    'replace': 'REPLACE',
    'equal': 'EQUAL',
    'move': 'MOVE',
    'insert': 'INSERT',
    'delete': 'DELETE',
}
**Type**: Dictionary

### 118.TYPE_CHANGE_FAIL_MSG constant

**Function**: The type change fail message.
**Value**: 'Unable to do the type change for {} from to type {} due to {}'
**Type**: String

### 119.DELTA_NUMPY_OPERATOR_OVERRIDE_MSG constant

**Function**: The delta numpy operator override message.
**Value**: 'A numpy ndarray is most likely being added to a delta. Due to Numpy override the + operator, you can only do: delta + ndarray and NOT ndarray + delta'
**Type**: String

### 120.UNABLE_TO_GET_ITEM_MSG constant

**Function**: The unable to get item message.
**Value**: 'Unable to get the item at {}: {}'
**Type**: String

### 121.UNABLE_TO_GET_PATH_MSG constant

**Function**: The unable to get path message.
**Value**: 'Unable to get the item at {}'
**Type**: String

### 122.NUMPY_TO_LIST constant

**Function**: The numpy to list.
**Value**: 'NUMPY_TO_LIST'
**Type**: String

### 123.MAX_PASSES_REACHED_MSG constant

**Function**: The max passes reached message.
**Value**: 'Max passes reached. The maximum number of passes has been reached.'
**Type**: String

### 124.MAX_DIFFS_REACHED_MSG constant

**Function**: The max diffs reached message.
**Value**: 'Max diffs reached. The maximum number of diffs has been reached.'
**Type**: String

### 125.DISTANCE_CACHE_HIT_COUNT constant

**Function**: The distance cache hit count.
**Value**: 'DISTANCE CACHE HIT COUNT'
**Type**: String

### 126.DIFF_COUNT constant

**Function**: The diff count.
**Value**: 'DIFF COUNT'
**Type**: String

### 127.PASSES_COUNT constant

**Function**: The passes count.
## Detailed Explanation of Configuration Classes
**Value**: 'PASSES COUNT'
**Type**: String

### 128.MAX_PASS_LIMIT_REACHED constant

**Function**: The max pass limit reached.
**Value**: 'MAX PASS LIMIT REACHED'
**Type**: String

### 129.MAX_DIFF_LIMIT_REACHED constant

**Function**: The max diff limit reached.
**Value**: 'MAX DIFF LIMIT REACHED'
**Type**: String

### 130.DISTANCE_CACHE_ENABLED constant

**Function**: The distance cache enabled.
**Value**: 'DISTANCE CACHE ENABLED'
**Type**: String

### 131.PREVIOUS_DIFF_COUNT constant

**Function**: The previous diff count.
**Value**: 'PREVIOUS DIFF COUNT'
**Type**: String

### 132.PREVIOUS_DISTANCE_CACHE_HIT_COUNT constant

**Function**: The previous distance cache hit count.
**Value**: 'PREVIOUS DISTANCE CACHE HIT COUNT'
**Type**: String

### 133.CANT_FIND_NUMPY_MSG constant

**Function**: The cant find numpy message.
**Value**: 'Unable to import numpy. This must be a bug in DeepDiff since a numpy array is detected.'
**Type**: String

### 134._ENABLE_CACHE_EVERY_X_DIFF constant

**Function**: The enable cache every x diff.
**Value**: '_ENABLE_CACHE_EVERY_X_DIFF'
**Type**: String

### 135.CUTOFF_DISTANCE_FOR_PAIRS_DEFAULT constant

**Function**: The cutoff distance for pairs default.
**Value**: 0.3
**Type**: Float

### 136.CUTOFF_INTERSECTION_FOR_PAIRS_DEFAULT constant

**Function**: The cutoff intersection for pairs default.
**Value**: 0.7
**Type**: Float

### 137.DEEPHASH_PARAM_KEYS constant

**Function**: The deephash param keys.
**Value**: ('exclude_types', 'exclude_paths', 'include_paths', 'exclude_regex_paths', 'hasher', 'significant_digits', 'number_format_notation', 'ignore_string_type_changes', 'ignore_numeric_type_changes', 'ignore_uuid_types', 'use_enum_value', 'ignore_type_in_groups', 'ignore_type_subclasses', 'ignore_string_case', 'exclude_obj_callback', 'ignore_private_variables', 'encodings', 'ignore_encoding_errors', 'default_timezone', 'custom_operators')
**Type**: Tuple

### 138.EMPTY_FROZENSET constant

**Function**: The empty frozen set.
**Value**: frozenset()
**Type**: FrozenSet

### 139.INDEX_VS_ATTRIBUTE constant

**Function**: The index vs attribute.
**Value**: 'INDEX_VS_ATTRIBUTE'
**Type**: String

### 140.DEFAULT_FIRST_ELEMENT constant

**Function**: The default first element.
**Value**: 0
**Type**: Int

### 141.DEFAULT_SIGNIFICANT_DIGITS_WHEN_IGNORE_NUMERIC_TYPES constant

**Function**: The default significant digits when ignore numeric types.
**Value**: 6
**Type**: Int

### 142.TYPE_STABILIZATION_MSG constant

**Function**: The type stabilization message.
**Value**: 'Type stabilization: {} -> {}'
**Type**: String

### 143.NONE_TYPE constant

**Function**: The none type.
**Value**: 'None'
**Type**: String

### 144.CSV_HEADER_MAX_CHUNK_SIZE constant

**Function**: The csv header max chunk size.
**Value**: 10000
**Type**: Int

### 145.TYPE_STR_TO_TYPE constant

**Function**: The type str to type.
**Value**: {
    'range': range,
    'complex': complex,
    'set': set,
    'frozenset': frozenset,
    'slice': slice,
    'str': str,
    'bytes': bytes,
    'list': list,
    'tuple': tuple,
    'int': int,
    'float': float,
    'dict': dict,
    'bool': bool,
    'bin': bin,
    'None': None,
    'NoneType': None,
    'datetime': datetime.datetime,
    'time': datetime.time,
    'timedelta': datetime.timedelta,
    'Decimal': decimal.Decimal,
    'SetOrdered': SetOrdered,
    'namedtuple': collections.namedtuple,
    'OrderedDict': collections.OrderedDict,
    'Pattern': re.Pattern,
    'iprange': str,
    'IPv4Address': ipaddress.IPv4Address,
    'IPv6Address': ipaddress.IPv6Address,
    'KeysView': list,
}
**Type**: Dictionary

### 146.JSON_CONVERTOR constant

**Function**: The json convertor.
**Value**: json_convertor_default(default_mapping=None)
**Type**: Function

### 147.CACHE_PATH constant

**Function**: The cache path.
**Value**: os.path.join(os.path.dirname(__file__), 'cache')
**Type**: String


### 148.DOC_VERSION constant

**Function**: The doc version.
**Value**: '0.1.0'
**Type**: String

### 149.NumberType Type Aliases
**Value**: Union[int, float, complex, Decimal, datetime.datetime, datetime.date, datetime.timedelta, datetime.time, Any]
**Type**: Union

### 150.UnkownValueCode Type Alias
**Value**: 'unknown___'
**Type**: String

### 151.HashableType Type Alias
**Value**: Union[str, int, float, bytes, bool, tuple, frozenset, type(None)]
**Type**: Union

### 152.HashResult Type Alias
**Value**: Union[str, Any]
**Type**: Union

### 153.HashTuple Type Alias
**Value**: Tuple[HashResult, int]
**Type**: Tuple

### 154.HashesDict Type Alias
**Value**: Dict[Any, Union[HashTuple, List[Any]]]
**Type**: Dict

### 155.PathType Type Alias
**Value**: Union[str, List[str], Set[str]]
**Type**: Union

### 156.RegexType Type Alias
**Value**: Union[str, re.Pattern[str], List[Union[str, re.Pattern[str]]]]
**Type**: Union

### 157.NumberToStringFunc Type Alias
**Value**: Callable[..., str]
**Type**: Callable

### 158.mypy() Function

**Function**: Run mypy.

**Function Signature**:
```python
@nox.session
def mypy(session) -> None:
    """Run mypy."""
```

**Parameter Description**:
- `session` (nox.Session): The nox session

**Return Value**: None

### 159.cli() Function

**Function**: Run the command line interface.

**Function Signature**:
```python
@click.group()
def cli():
