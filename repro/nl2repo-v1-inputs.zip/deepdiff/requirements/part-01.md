# Introduction and Goals of the DeepDiff Project

DeepDiff is a Python library **designed for in-depth object comparison and difference analysis**. It can perform a thorough comparison of any Python objects/data structures and detect differences. This tool excels in comparing complex data structures, achieving "the most comprehensive difference detection and the most flexible configuration options." Its core functions include: in-depth object comparison (automatically recursively comparing nested structures), **creation and application of difference objects** (supporting Delta objects to implement Git-like commit functionality), and intelligent comparison of complex data structures such as sets, dictionaries, lists, and custom objects. In short, DeepDiff aims to provide a powerful in-depth comparison system for detecting and analyzing differences between Python objects (for example, creating a difference object through DeepDiff() and applying the difference to the target object through the Delta() function).

## Natural Language Instruction (Prompt)

Please create a Python project named DeepDiff to implement an in-depth object comparison library. The project should include the following functions:

1. **In-depth Comparison Engine**: Implement the DeepDiff class, which can recursively compare all levels of two Python objects, supporting complex data structures such as dictionaries, lists, sets, tuples, and custom objects. The comparison results should contain detailed difference information, including type changes, value changes, item additions/deletions, etc. Support advanced configuration options such as ignoring order, ignoring type changes, and path filtering.

2. **Difference Object System**: Implement the Delta class, which can capture and apply differences, similar to Git's commit system. It should support applying differences to the original object to generate a new object state, as well as bidirectional difference application. Support serialization, verification mechanisms, error handling, etc.

3. **In-depth Search Function**: Implement the DeepSearch class, which can search for specific values in complex data structures, supporting path matching, type filtering, regular expressions, etc.

4. **In-depth Hashing Function**: Implement the DeepHash class to generate hash values for complex objects, supporting hash caching, custom hashers, etc.

5. **Command Line Interface**: Design independent command line interfaces for each functional module, supporting commands such as diff, patch, grep, and extract, and supporting multiple file formats.

6. **Serialization Support**: Implement a serialization module, supporting serialization and deserialization in formats such as JSON and Pickle, and supporting a secure deserialization mechanism.

7. **Special Structure Handling**: Provide specialized handling for NumPy arrays, Pandas DataFrames, Polars DataFrames, custom objects, etc.

8. **Utility Function Collection**: Implement utility functions for path handling, type detection, numerical processing, time handling, cache management, etc.

9. **Test Verification Script**: Create a comprehensive_test.py file, which should include the following test functions:
   - Test the basic comparison functions of DeepDiff (for dictionaries, lists, sets, etc.)
   - Test the difference application function of Delta (forward and reverse application)
   - Test the search function of DeepSearch (various search modes)
   - Test the hashing function of DeepHash (for various data types)
   - Test the command line interface (diff, patch, grep, extract commands)
   - Test the serialization function (JSON, Pickle, etc.)
   - Test special data structures (NumPy, Pandas, etc.)
   - Test error handling and boundary cases
   - Test performance optimization functions (caching, limits, etc.)
   - Test configuration options (various ignore options, path filtering, etc.)

10. **Core File Requirements**: The project must include a complete pyproject.toml file, which needs to configure the project as an installable package (supporting pip install and editable mode installation) and declare a complete list of dependencies, including numpy==1.26.4 (support for array comparison), pandas==2.2.3 (data structure comparison), pytest==8.4.0 (testing framework), click (command line tool), orjson (efficient JSON processing), tomli-w (TOML writing), pyyaml (YAML serialization), jsonpickle (object serialization), polars (data frame comparison), and other core libraries. At the same time, it is necessary to provide deepdiff/__init__.py as a unified API entry. This file needs to integrate key components from each core module: import DeepDiff (core difference calculation class) from the diff module; import Delta (difference increment class) from the delta module; import DeepHash (object hash generation class) and sha256hex (hashing algorithm) from the deephash module; import DeepSearch (in-depth search class) and grep (pattern matching function) from the search module; import tool functions such as diff, patch (difference application), and extract (data extraction) from the commands module; import parse_path, stringify_path (path parsing and conversion), GET/GETATTR (path operation constants) from the path module; import structural classes such as DiffLevel (difference level model) and DictRelationship (dictionary relationship handling) from the model module; import auxiliary types such as AnySet (unordered set comparison) and SetOrdered (ordered set handling) from the helper module; import json_dumps, pickle_load (cross-format serialization) from the serialization module; in addition, it is also necessary to export extended functions such as summarize (difference summary), LFUCache (caching mechanism), and BaseOperator (base class for custom operators), and provide version information through __version__. Ensure that users can access all major functions through concise statements such as from deepdiff import DeepDiff, Delta, DeepHash, grep, parse_path. In grader.py, the deepdiff_expr_eq() function needs to use multiple strategies to verify the in-depth difference equivalence of two objects: handle set order differences through the ignore_order parameter of DeepDiff, use the cutoff_distance to control the tolerance range for numerical types (such as numpy arrays and floating-point numbers), and ignore irrelevant fields through exclude_paths; combine Delta to verify the reversibility of differences (whether the original object is restored after applying the patch); use the datetime_normalize function in the helper module to handle time format differences, and use diff_numpy_array to specifically verify array elements; support custom BaseOperator to handle special types (such as Pydantic models and enums), and finally return a boolean value and difference details to ensure the accuracy and flexibility of complex object comparison.
## Environment Configuration

### Python Version

The Python version used in the current project is: Python 3.10.11

### Core Dependency Library Versions

```Plain
annotated-types   0.7.0
argcomplete       3.6.2
asttokens         3.0.0
attrs             25.3.0
bump2version      1.0.1
click             8.1.8
colorlog          6.9.0
coverage          7.10.3
decorator         5.2.1
dependency-groups 1.3.1
distlib           0.4.0
exceptiongroup    1.3.0
executing         2.2.0
filelock          3.18.0
iniconfig         2.1.0
ipdb              0.13.13
ipython           8.37.0
jedi              0.19.2
jsonpickle        4.0.5
matplotlib-inline 0.1.7
nox               2025.5.1
numpy             2.2.6
orderly-set       5.5.0
orjson            3.10.18
packaging         25.0
pandas            2.2.3
parso             0.8.4
pexpect           4.9.0
pip               23.0.1
platformdirs      4.3.8
pluggy            1.6.0
polars            1.21.0
prompt_toolkit    3.0.51
ptyprocess        0.7.0
pure_eval         0.2.3
py-cpuinfo        9.0.0
pydantic          2.11.7
pydantic_core     2.33.2
Pygments          2.19.2
python-dateutil   2.9.0.post0
python-dotenv     1.0.1
pytz              2025.2
PyYAML            6.0.2
setuptools        65.5.1
six               1.17.0
stack-data        0.6.3
tomli             2.2.1
tomli_w           1.2.0
traitlets         5.14.3
typing_extensions 4.14.1
typing-inspection 0.4.1
tzdata            2025.2
virtualenv        20.33.1
wcwidth           0.2.13
wheel             0.40.0
```

## DeepDiff Project Architecture

### Project Directory Structure

```Plain
workspace/
├── .bumpversion.cfg
├── .coveragerc
├── .direnvrc.example
├── .envrc.example
├── .gitignore
├── AUTHORS.md
├── CHANGELOG.md
├── CITATION.cff
├── CLAUDE.md
├── LICENSE
├── MANIFEST.in
├── README.md
├── conftest.py
├── deepdiff
│   ├── __init__.py
│   ├── anyset.py
│   ├── base.py
│   ├── colored_view.py
│   ├── commands.py
│   ├── deephash.py
│   ├── delta.py
│   ├── diff.py
│   ├── distance.py
│   ├── helper.py
│   ├── lfucache.py
│   ├── model.py
│   ├── operator.py
│   ├── path.py
│   ├── py.typed
│   ├── search.py
│   ├── serialization.py
│   └── summarize.py
├── docs
│   ├── Makefile
│   ├── _static
│   │   ├── benchmark_array_no_numpy__3.8__ignore_order=True__cache_size=0__cache_tuning_sample_size=0__cutoff_intersection_for_pairs=1.png
│   │   ├── benchmark_array_no_numpy__3.8__ignore_order=True__cache_size=10000__cache_tuning_sample_size=0__cutoff_intersection_for_pairs=1.png
│   │   ├── benchmark_big_jsons__3.8__ignore_order=True__cache_size=0__cache_tuning_sample_size=0__max_diffs=300000__max_passes=40000__cutoff_intersection_for_pairs=1.png
│   │   ├── benchmark_big_jsons__pypy3.6__ignore_order=True__cache_size=0__cache_tuning_sample_size=0__max_diffs=300000__max_passes=40000__cutoff_intersection_for_pairs=1.png
│   │   ├── benchmark_deeply_nested_a__3.8__ignore_order=True__cache_size=0__cache_tuning_sample_size=0__cutoff_intersection_for_pairs=1.png
│   │   ├── benchmark_deeply_nested_a__3.8__ignore_order=True__cache_size=5000__cache_tuning_sample_size=0__cutoff_intersection_for_pairs=1.png
│   │   ├── benchmark_deeply_nested_a__3.8__ignore_order=True__cache_size=500__cache_tuning_sample_size=0__cutoff_intersection_for_pairs=1.png
│   │   ├── benchmark_deeply_nested_a__3.8__ignore_order=True__cache_size=500__cache_tuning_sample_size=500__cutoff_intersection_for_pairs=1.png
│   │   ├── benchmark_numpy_array__3.8__ignore_order=True__cache_size=0__cache_tuning_sample_size=0__cutoff_intersection_for_pairs=1.png
│   │   ├── custom.css
│   │   ├── favicon.ico
│   │   ├── logo.svg
│   │   └── logo_long_B1_black.svg
│   ├── _templates
│   │   ├── about.html
│   │   ├── basic
│   │   │   └── layout.html
│   │   └── navigation.html
│   ├── authors.rst
│   ├── basics.rst
│   ├── buildme.py
│   ├── changelog.rst
│   ├── colored_view.rst
│   ├── commandline.rst
│   ├── conf.py
│   ├── custom.rst
│   ├── deep_distance.rst
│   ├── deephash.rst
│   ├── deephash_doc.rst
│   ├── delta.rst
│   ├── diff.rst
│   ├── diff_doc.rst
│   ├── dsearch.rst
│   ├── exclude_paths.rst
│   ├── extract.rst
│   ├── faq.rst
│   ├── ignore_order.rst
│   ├── ignore_types_or_values.rst
│   ├── index.rst
│   ├── make.bat
│   ├── numbers.rst
│   ├── optimizations.rst
│   ├── other.rst
│   ├── search_doc.rst
│   ├── serialization.rst
│   ├── stats.rst
│   ├── support.rst
│   ├── troubleshoot.rst
│   └── view.rst
├── mypy.ini
├── noxfile.py
├── pyproject.toml
├── pyrightconfig.json.example
└── uv.lock
```


# API Usage Guide

## Core APIs

### 1. Module Import

```python
from deepdiff import (
    AnySet, Delta, DeepDiff, DeepHash, DeepSearch, grep, extract, patch, summarize,
)
from deepdiff.anyset import AnySet
from deepdiff.commands import diff, patch, grep, extract
from deepdiff.deephash import (
    sha256hex, prepare_string_for_hashing, unprocessed, UNPROCESSED_KEY,
    BoolObj, HASH_LOOKUP_ERR_MSG, combine_hashes_lists,
)
from deepdiff.delta import (
    ELEM_NOT_FOUND_TO_ADD_MSG, VERIFICATION_MSG, VERIFY_BIDIRECTIONAL_MSG, not_found,
    DeltaNumpyOperatorOverrideError, BINIARY_MODE_NEEDED_MSG, DELTA_AT_LEAST_ONE_ARG_NEEDED,
    DeltaError, INVALID_ACTION_WHEN_CALLING_GET_ELEM, INVALID_ACTION_WHEN_CALLING_SIMPLE_SET_ELEM,
    INVALID_ACTION_WHEN_CALLING_SIMPLE_DELETE_ELEM, INDEXES_NOT_FOUND_WHEN_IGNORE_ORDER,
    FAIL_TO_REMOVE_ITEM_IGNORE_ORDER_MSG, NABLE_TO_GET_PATH_MSG, NOT_VALID_NUMPY_TYPE,
)
from deepdiff.diff import (
    PROGRESS_MSG, INVALID_VIEW_MSG, VERBOSE_LEVEL_RANGE_MSG, PURGE_LEVEL_RANGE_MSG,
    DELTA_VIEW, CUTOFF_RANGE_ERROR_MSG,
)
from deepdiff.distance import (
    _get_item_length, _get_numbers_distance, get_numeric_types_distance,
    _get_numpy_array_distance, DISTANCE_CALCS_NEEDS_CACHE,
)
from deepdiff.helper import (
    py_current_version, pypy3, np, number_to_string, TEXT_VIEW, DELTA_VIEW, CannotCompare,
    FlatDeltaRow, FlatDataAction, SetOrdered, PydanticBaseModel, np_float64, notpresent,
    get_id, py_major_version, py_minor_version, short_repr, get_numpy_ndarray_rows,
    cartesian_product_of_shape, literal_eval_extended, diff_numpy_array, cartesian_product_numpy,
    get_truncate_datetime, datetime_normalize, detailed__dict__, ENUM_INCLUDE_KEYS,
    add_root_to_paths, get_semvar_as_integer, np_ndarray, Opcode,
)
from deepdiff.lfucache import LFUCache
from deepdiff.model import (
    DiffLevel, ChildRelationship, DictRelationship, NonSubscriptableIterableRelationship,
    SubscriptableIterableRelationship, AttributeRelationship,
)
from deepdiff.operator import BaseOperator, PrefixOrSuffixOperator, BaseOperatorPlus
from deepdiff.path import (
    GETATTR, GET,  _path_to_elements, extract, parse_path, stringify_path,  _add_to_elements,
)
from deepdiff.serialization import (
    DELTA_IGNORE_ORDER_NEEDS_REPETITION_REPORT, DELTA_ERROR_WHEN_GROUP_BY, json_dumps,
    json_loads, pickle_load, pickle_dump, ForbiddenModule, ModuleNotFoundError,
    MODULE_NOT_FOUND_MSG, FORBIDDEN_MODULE_MSG, pretty_print_diff,
    load_path_content, UnsupportedFormatErr,
)
from deepdiff.summarize import summarize, _truncate
```

### 2. DeepDiff Class

**Function**: Perform an in-depth comparison of two Python objects and detect differences at all levels.

**Class Definition**:
```python
class DeepDiff(ResultDict, SerializationMixin, DistanceMixin, DeepDiffProtocol, Base):
    """
    Deep comparison of two objects and return difference results
    
    This is the core class of DeepDiff, used to compare two Python objects 
    and generate detailed difference reports. Supports multiple data types 
    including dictionaries, lists, sets, custom objects, etc.
    """
    __doc__ = doc

    CACHE_AUTO_ADJUST_THRESHOLD = 0.25

    def __init__(self,
                 t1: Any,
                 t2: Any,
                 _original_type: Optional[Any]=None,
                 cache_purge_level: int=1,
                 cache_size: int=0,
                 cache_tuning_sample_size: int=0,
                 custom_operators: Optional[List[Any]] =None,
                 cutoff_distance_for_pairs: float=CUTOFF_DISTANCE_FOR_PAIRS_DEFAULT,
                 cutoff_intersection_for_pairs: float=CUTOFF_INTERSECTION_FOR_PAIRS_DEFAULT,
                 default_timezone:Union[datetime.timezone, "BaseTzInfo"]=datetime.timezone.utc,
                 encodings: Optional[List[str]]=None,
                 exclude_obj_callback: Optional[Callable]=None,
                 exclude_obj_callback_strict: Optional[Callable]=None,
                 exclude_paths: Union[str, List[str], Set[str], FrozenSet[str], None]=None,
                 exclude_regex_paths: Union[str, List[str], Pattern[str], List[Pattern[str]], None]=None,
                 exclude_types: Optional[List[type]]=None,
                 get_deep_distance: bool=False,
                 group_by: Union[str, Tuple[str, str], None]=None,
                 group_by_sort_key: Union[str, Callable, None]=None,
                 hasher: Optional[Callable]=None,
                 hashes: Optional[Dict[Any, Any]]=None,
                 ignore_encoding_errors: bool=False,
                 ignore_nan_inequality: bool=False,
                 ignore_numeric_type_changes: bool=False,
                 ignore_order: bool=False,
                 ignore_order_func: Optional[Callable]=None,
                 ignore_private_variables: bool=True,
                 ignore_string_case: bool=False,
                 ignore_string_type_changes: bool=False,
                 ignore_type_in_groups: Optional[List[Tuple[Any, ...]]]=None,
                 ignore_type_subclasses: bool=False,
                 ignore_uuid_types: bool=False,
                 include_obj_callback: Optional[Callable]=None,
                 include_obj_callback_strict: Optional[Callable]=None,
                 include_paths: Union[str, List[str], None]=None,
                 iterable_compare_func: Optional[Callable]=None,
                 log_frequency_in_sec: int=0,
                 log_scale_similarity_threshold: float=0.1,
                 log_stacktrace: bool=False,
                 math_epsilon: Optional[float]=None,
                 max_diffs: Optional[int]=None,
                 max_passes: int=10000000,
                 number_format_notation: Literal["f", "e"]="f",
                 number_to_string_func: Optional[Callable]=None,
                 progress_logger: Callable[[str], None]=logger.info,
                 report_repetition: bool=False,
                 significant_digits: Optional[int]=None,
                 threshold_to_diff_deeper: float = 0.33,
                 truncate_datetime: Optional[str]=None,
                 use_enum_value: bool=False,
                 use_log_scale: bool=False,
                 verbose_level: int=1,
                 view: str=TEXT_VIEW,
                 zip_ordered_iterables: bool=False,
                 _parameters: Optional[Dict[str, Any]]=None,
                 _shared_parameters: Optional[Dict[str, Any]]=None,
                 **kwargs):
        super().__init__()
        if kwargs:
            raise ValueError((
                "The following parameter(s) are not valid: %s\n"
                "The valid parameters are ignore_order, report_repetition, significant_digits, "
                "number_format_notation, exclude_paths, include_paths, exclude_types, exclude_regex_paths, ignore_type_in_groups, "
                "ignore_string_type_changes, ignore_numeric_type_changes, ignore_type_subclasses, ignore_uuid_types, truncate_datetime, "
                "ignore_private_variables, ignore_nan_inequality, number_to_string_func, verbose_level, "
                "view, hasher, hashes, max_passes, max_diffs, zip_ordered_iterables, "
                "cutoff_distance_for_pairs, cutoff_intersection_for_pairs, log_frequency_in_sec, cache_size, "
                "cache_tuning_sample_size, get_deep_distance, group_by, group_by_sort_key, cache_purge_level, log_stacktrace,"
                "math_epsilon, iterable_compare_func, use_enum_value, _original_type, threshold_to_diff_deeper, default_timezone "
                "ignore_order_func, custom_operators, encodings, ignore_encoding_errors, use_log_scale, log_scale_similarity_threshold "
                "_parameters and _shared_parameters.") % ', '.join(kwargs.keys()))

        if _parameters:
            self.__dict__.update(_parameters)
        else:
            self.custom_operators = custom_operators or []
            self.ignore_order = ignore_order

            self.ignore_order_func = ignore_order_func

            ignore_type_in_groups = ignore_type_in_groups or []
            if numbers == ignore_type_in_groups or numbers in ignore_type_in_groups:
                ignore_numeric_type_changes = True
            self.ignore_numeric_type_changes = ignore_numeric_type_changes
            if strings == ignore_type_in_groups or strings in ignore_type_in_groups:
                ignore_string_type_changes = True
            # Handle ignore_uuid_types - check if uuid+str group is already in ignore_type_in_groups
            uuid_str_group = (uuids[0], str)
            if uuid_str_group == ignore_type_in_groups or uuid_str_group in ignore_type_in_groups:
                ignore_uuid_types = True
            self.ignore_uuid_types = ignore_uuid_types
            self.use_enum_value = use_enum_value
            self.log_scale_similarity_threshold = log_scale_similarity_threshold
            self.use_log_scale = use_log_scale
            self.default_timezone = default_timezone
            self.log_stacktrace = log_stacktrace
            self.threshold_to_diff_deeper = threshold_to_diff_deeper
            self.ignore_string_type_changes = ignore_string_type_changes
            self.ignore_type_in_groups = self.get_ignore_types_in_groups(
                ignore_type_in_groups=ignore_type_in_groups,
                ignore_string_type_changes=ignore_string_type_changes,
                ignore_numeric_type_changes=ignore_numeric_type_changes,
                ignore_type_subclasses=ignore_type_subclasses,
                ignore_uuid_types=ignore_uuid_types)
            self.report_repetition = report_repetition
            self.exclude_paths = add_root_to_paths(convert_item_or_items_into_set_else_none(exclude_paths))
            self.include_paths = add_root_to_paths(convert_item_or_items_into_set_else_none(include_paths))
            self.exclude_regex_paths = convert_item_or_items_into_compiled_regexes_else_none(exclude_regex_paths)
            self.exclude_types = set(exclude_types) if exclude_types else None
            self.exclude_types_tuple = tuple(exclude_types) if exclude_types else None  # we need tuple for checking isinstance
            self.ignore_type_subclasses = ignore_type_subclasses
            self.type_check_func = type_in_type_group if ignore_type_subclasses else type_is_subclass_of_type_group
            self.ignore_string_case = ignore_string_case
            self.exclude_obj_callback = exclude_obj_callback
            self.exclude_obj_callback_strict = exclude_obj_callback_strict
            self.include_obj_callback = include_obj_callback
            self.include_obj_callback_strict = include_obj_callback_strict
            self.number_to_string = number_to_string_func or number_to_string
            self.iterable_compare_func = iterable_compare_func
            self.zip_ordered_iterables = zip_ordered_iterables
            self.ignore_private_variables = ignore_private_variables
            self.ignore_nan_inequality = ignore_nan_inequality
            self.hasher = hasher
            self.cache_tuning_sample_size = cache_tuning_sample_size
            self.group_by = group_by
            if callable(group_by_sort_key):
                self.group_by_sort_key = group_by_sort_key
            elif group_by_sort_key:
                def _group_by_sort_key(x):
                    return x[group_by_sort_key]
                self.group_by_sort_key = _group_by_sort_key
            else:
                self.group_by_sort_key = None
            self.encodings = encodings
            self.ignore_encoding_errors = ignore_encoding_errors

            self.significant_digits = self.get_significant_digits(significant_digits, ignore_numeric_type_changes)
            self.math_epsilon = math_epsilon
            if self.math_epsilon is not None and self.ignore_order:
                logger.warning("math_epsilon in conjunction with ignore_order=True is only used for flat object comparisons. Custom math_epsilon will not have an effect when comparing nested objects.")
            self.truncate_datetime = get_truncate_datetime(truncate_datetime)
            self.number_format_notation = number_format_notation
            if verbose_level in {0, 1, 2}:
                self.verbose_level = verbose_level
            else:
                raise ValueError(VERBOSE_LEVEL_RANGE_MSG)
            if cache_purge_level not in {0, 1, 2}:
                raise ValueError(PURGE_LEVEL_RANGE_MSG)
            self.view = view
