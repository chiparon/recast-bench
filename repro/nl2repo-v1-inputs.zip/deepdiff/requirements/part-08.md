- `0`: Disable cache (default)
- `>0`: Enable cache of the specified size

**max_passes**: Maximum number of passes
- Default: 10000000
- Prevent infinite loops

**max_diffs**: Maximum number of differences
- `None`: No limit (default)
- `>0`: Limit the number of differences

## Actual Usage Modes

### Basic Usage

```python
from deepdiff import DeepDiff, Delta

# Simple comparison
t1 = {"a": 1, "b": 2}
t2 = {"a": 1, "b": 3}
diff = DeepDiff(t1, t2)
print(diff)  # {'values_changed': {"root['b']": {'old_value': 2, 'new_value': 3}}}

# Apply differences
delta = Delta(diff=diff)
result = t1 + delta
print(result)  # {"a": 1, "b": 3}
```

### Configuration-based Usage

```python
from deepdiff import DeepDiff, DeepSearch

# Custom configuration comparison
diff = DeepDiff(
    t1, t2,
    ignore_order=True,
    ignore_private_variables=True,
    exclude_paths=["root['metadata']"],
    verbose_level=2
)

# Configuration-based search
search = DeepSearch(
    obj,
    item="target_value",
    case_sensitive=False,
    use_regexp=True,
    verbose_level=2
)
```



# Detailed Function Implementation Nodes

### Node 1: Basic Object Comparison
**Function Description**: Implement the core comparison function of DeepDiff, supporting deep comparison of basic data structures such as dictionaries, lists, sets, and tuples. This is the foundation of the entire DeepDiff system, responsible for handling comparison operations of all Python standard data types. It includes core functions such as recursively traversing nested structures, detecting various types of changes, handling circular references, and supporting custom comparison logic. This node is the basis for all other advanced functions, ensuring the accuracy and completeness of basic comparisons.
**Comparison Strategy**:
- Recursively traverse all nested levels using a depth-first search algorithm
- Detect value changes, type changes, item additions/deletions, and dictionary key changes
- Support custom comparison functions and callback mechanisms
- Handle circular references and infinite recursion to prevent stack overflow
- Support path tracking and detailed difference reports
- Handle special cases such as None values, empty objects, and singleton objects
- Support the `verbose_level` parameter to control the output detail level
- Implement an efficient comparison algorithm to optimize the performance of large object processing
**Input and Output Examples**:
```python
from deepdiff import DeepDiff

# Basic dictionary comparison
t1 = {"a": 1, "b": 2}
t2 = {"a": 1, "b": 3}
result = DeepDiff(t1, t2)
# Output: {'values_changed': {"root['b']": {'new_value': 3, 'old_value': 2}}}

# List comparison
t1 = [1, 2, 3]
t2 = [1, 2, 4]
result = DeepDiff(t1, t2)
# Output: {'values_changed': {"root[2]": {'new_value': 4, 'old_value': 3}}}

# Set comparison
t1 = {1, 2, 3}
t2 = {1, 2, 4}
result = DeepDiff(t1, t2)
# Output: {'set_item_added': ["root[4]"], 'set_item_removed': ["root[3]"]}
```

### Node 2: Numeric Type Handling
**Function Description**: Specifically handle the comparison of numeric types, including integers, floating-point numbers, Decimals, and complex numbers, supporting precision control and type ignoring. This node is responsible for all numeric-related comparison operations, ensuring the accuracy and flexibility of numeric comparisons. It supports high-precision numeric calculations, scientific notation, complex number operations, and special numeric handling. This function is very important for scenarios such as scientific computing, financial applications, and data analysis, capable of handling various numeric precision requirements and type conversion needs.
**Handling Strategy**:
- Support the `significant_digits` parameter to control precision, supporting scientific notation formats
- Support `ignore_numeric_type_changes` to ignore type changes (e.g., int and float)
- Support the `math_epsilon` parameter to set the numeric tolerance for handling floating-point precision issues
- Handle the comparison of special numeric values such as NaN, infinity, and negative zero
- Support precise decimal operations for the Decimal type
- Handle the separate comparison of the real and imaginary parts of complex numbers
- Support the `number_format_notation` parameter to control numeric formatting
- Handle boundary cases of numeric overflow and precision loss
- Support custom numeric comparison functions and tolerance settings
**Input and Output Examples**:
```python
from decimal import Decimal
from deepdiff import DeepDiff

# Precision control
t1 = 3.14159
t2 = 3.14160
result = DeepDiff(t1, t2, significant_digits=4)
# Output: {} (no differences)

# Decimal type comparison
t1 = Decimal('3.14159')
t2 = 3.14159
result = DeepDiff(t1, t2, ignore_numeric_type_changes=True)
# Output: {} (no differences)

# Numeric tolerance
t1 = 1.0001
t2 = 1.0002
result = DeepDiff(t1, t2, math_epsilon=0.001)
# Output: {} (no differences)
```

### Node 3: String Processing
**Function Description**: Handle string comparison, supporting case-insensitive comparison, encoding processing, and Unicode support. This node specifically handles all string-related comparison operations, including ordinary strings, Unicode strings, byte strings, and raw strings. It supports functions such as multi-language text comparison, encoding conversion, and string normalization. It is very important for scenarios such as internationalized applications, text processing, and data cleaning, capable of handling various string formats and encoding requirements.
**Handling Strategy**:
- Support `ignore_string_case` to ignore case, supporting multi-language case rules
- Support `ignore_string_type_changes` to ignore type changes (e.g., str and bytes)
- Handle the encoding conversion of Unicode strings and byte strings
- Support string normalization (NFD, NFC, NFKD, NFKC)
- Handle special characters, control characters, and escape characters
- Support special handling of regular expression strings
- Handle string length limits and truncation
- Support custom string comparison functions
- Handle string pooling and memory optimization
- Support encoding error handling
**Input and Output Examples**:
```python
from deepdiff import DeepDiff

# Case-insensitive comparison
t1 = "Hello World"
t2 = "hello world"
result = DeepDiff(t1, t2, ignore_string_case=True)
# Output: {} (no differences)

# String type change
t1 = "hello"
t2 = b"hello"
result = DeepDiff(t1, t2, ignore_string_type_changes=True)
# Output: {} (no differences)

# Unicode handling
t1 = "café"
t2 = "cafe"
result = DeepDiff(t1, t2)
# Output: {'values_changed': {'root': {'new_value': 'cafe', 'old_value': 'café'}}}
```

### Node 4: Collection and Sequence Processing
**Function Description**: Handle the comparison of collection types such as lists, tuples, and sets, supporting order ignoring and repetition reporting. This node specifically handles all comparison operations of iterable data structures, including lists, tuples, sets, generators, and iterators. It supports functions such as complex collection operations, handling of duplicate elements, order-independent comparison, and nested structure processing. It is very important for scenarios such as data analysis, collection operations, sequence comparison, and data cleaning, capable of handling comparison requirements of various iterable objects.
**Handling Strategy**:
- Support `ignore_order` to ignore order, implementing set-style comparison and hash optimization
- Support `report_repetition` to report duplicate elements and frequency statistics
- Handle the recursive comparison of nested collection structures
- Support custom comparison functions and iterator processing
- Handle boundary cases such as empty collections, single-element collections, and large collections
- Support intersection, union, and difference operations and optimization of collections
- Handle type conversion and normalization of collection elements
- Support the `iterable_compare_func` custom comparison function
- Handle performance optimization and memory management of large collections
- Support sorting and deduplication operations of collection elements
**Input and Output Examples**:
```python
from deepdiff import DeepDiff

# Ignore order
t1 = [1, 2, 3]
t2 = [3, 1, 2]
result = DeepDiff(t1, t2, ignore_order=True)
# Output: {} (no differences)

# Report repetition
t1 = [1, 2, 2, 3]
t2 = [1, 2, 3]
result = DeepDiff(t1, t2, report_repetition=True)
# Output: {'repetition_change': {"root[1]": {'old_repeat': 2, 'new_repeat': 1}}}

# Nested collections
t1 = [[1, 2], [3, 4]]
t2 = [[3, 4], [1, 2]]
result = DeepDiff(t1, t2, ignore_order=True)
# Output: {} (no differences)
```

### Node 5: Custom Object Processing
**Function Description**: Handle the comparison of complex objects such as custom classes, dataclasses, namedtuples, and enumerations.
**Handling Strategy**:
- Support processing of the `__slots__` attribute
- Support detection of attribute changes
- Support detection of method changes
- Handle inheritance relationships
**Input and Output Examples**:
```python
from dataclasses import dataclass
from enum import Enum
from deepdiff import DeepDiff

@dataclass
class Person:
    name: str
    age: int

class Color(Enum):
    RED = 1
    BLUE = 2

# Dataclass comparison
t1 = Person("Alice", 30)
t2 = Person("Alice", 31)
result = DeepDiff(t1, t2)
# Output: {'values_changed': {"root.age": {'new_value': 31, 'old_value': 30}}}

# Enumeration comparison
t1 = Color.RED
t2 = Color.BLUE
result = DeepDiff(t1, t2)
# Output: {'values_changed': {'root': {'new_value': Color.BLUE, 'old_value': Color.RED}}}
```

### Node 6: DateTime Processing
**Function Description**: Handle the comparison of time types such as datetime, date, and time.
**Handling Strategy**:
- Support time zone processing
- Support time precision control
- Handle time formatting
- Support time tolerance
**Input and Output Examples**:
```python
from datetime import datetime, date
from deepdiff import DeepDiff

# Datetime comparison
t1 = datetime(2023, 1, 1, 12, 0, 0)
t2 = datetime(2023, 1, 1, 12, 0, 1)
result = DeepDiff(t1, t2)
# Output: {'values_changed': {'root': {'new_value': datetime(2023, 1, 1, 12, 0, 1), 'old_value': datetime(2023, 1, 1, 12, 0, 0)}}}

# Date comparison
t1 = date(2023, 1, 1)
t2 = date(2023, 1, 2)
result = DeepDiff(t1, t2)
# Output: {'values_changed': {'root': {'new_value': date(2023, 1, 2), 'old_value': date(2023, 1, 1)}}}
```

### Node 7: Special Data Type Processing
**Function Description**: Handle the comparison of special data types such as UUIDs, regular expressions, and IP addresses.
**Handling Strategy**:
- Support UUID comparison
- Support regular expression objects
- Support IP address objects
- Handle serialization of special objects
**Input and Output Examples**:
```python
import uuid
import re
import ipaddress
from deepdiff import DeepDiff

# UUID comparison
t1 = uuid.uuid4()
t2 = uuid.uuid4()
result = DeepDiff(t1, t2)
# Output: {'values_changed': {'root': {'new_value': t2, 'old_value': t1}}}

# Regular expression comparison
t1 = re.compile(r'\d+')
t2 = re.compile(r'\d+')
result = DeepDiff(t1, t2)
# Output: {} (no differences)

# IP address comparison
t1 = ipaddress.IPv4Address('192.168.1.1')
t2 = ipaddress.IPv4Address('192.168.1.2')
result = DeepDiff(t1, t2)
# Output: {'values_changed': {'root': {'new_value': IPv4Address('192.168.1.2'), 'old_value': IPv4Address('192.168.1.1')}}}
```

### Node 8: Path Filtering and Inclusion
**Function Description**: Support advanced filtering functions such as path filtering, included paths, and regular expression paths.
**Handling Strategy**:
- Support `exclude_paths` to exclude paths
- Support `include_paths` to include paths
- Support `exclude_regex_paths` for regular expression exclusion
- Support `include_regex_paths` for regular expression inclusion
**Input and Output Examples**:
```python
from deepdiff import DeepDiff

t1 = {"a": {"b": 1, "c": 2}, "d": 3}
t2 = {"a": {"b": 1, "c": 3}, "d": 4}

# Exclude paths
result = DeepDiff(t1, t2, exclude_paths=["root['d']"])
# Output: {'values_changed': {"root['a']['c']": {'new_value': 3, 'old_value': 2}}}

# Include paths
result = DeepDiff(t1, t2, include_paths=["root['a']"])
# Output: {'values_changed': {"root['a']['c']": {'new_value': 3, 'old_value': 2}}}

# Regular expression exclusion
result = DeepDiff(t1, t2, exclude_regex_paths=[r"root\['d'\]"])
# Output: {'values_changed': {"root['a']['c']": {'new_value': 3, 'old_value': 2}}}
```

### Node 9: Type Filtering and Grouping
**Function Description**: Support advanced type functions such as type filtering, type grouping, and subclass handling.
**Handling Strategy**:
- Support `exclude_types` to exclude types
- Support `ignore_type_subclasses` to ignore subclasses
- Support type grouping comparison
- Handle type change detection
**Input and Output Examples**:
```python
from deepdiff import DeepDiff

t1 = {"a": 1, "b": "2", "c": 3.0}
t2 = {"a": 1.0, "b": 2, "c": 3}

# Ignore numeric type changes
result = DeepDiff(t1, t2, ignore_numeric_type_changes=True)
# Output: {} (no differences)

# Exclude string types
result = DeepDiff(t1, t2, exclude_types=[str])
# Output: {'values_changed': {"root['a']": {'new_value': 1.0, 'old_value': 1}}}

# Type grouping
result = DeepDiff(t1, t2, ignore_type_in_groups=[(int, float)])
# Output: {} (no differences)
```

### Node 10: Performance Optimization and Caching
**Function Description**: Implement performance optimization functions, including caching, limits, and progress reporting.
**Handling Strategy**:
- Support LFU cache
- Support `max_passes` limit
- Support `max_diffs` limit
- Support progress reporting
**Input and Output Examples**:
```python
from deepdiff import DeepDiff

# Set the maximum number of differences
t1 = {"a": 1, "b": 2, "c": 3, "d": 4}
t2 = {"a": 1, "b": 3, "c": 4, "d": 5}
result = DeepDiff(t1, t2, max_diffs=2)
# Output: Only show the first 2 differences

# Set the maximum number of passes
result = DeepDiff(t1, t2, max_passes=1)
# Output: Limit the traversal depth

# Cache size setting
result = DeepDiff(t1, t2, cache_size=1000)
# Output: Use the cache to optimize performance
```

### Node 11: Serialization and Deserialization
**Function Description**: Support serialization and deserialization in multiple formats, including JSON, Pickle, YAML, etc.
**Handling Strategy**:
- Support JSON serialization
- Support Pickle serialization
- Support YAML serialization
- Support TOML serialization
**Input and Output Examples**:
```python
from deepdiff import DeepDiff, Delta

t1 = {"a": 1, "b": 2}
t2 = {"a": 1, "b": 3}
diff = DeepDiff(t1, t2)

# JSON serialization
json_str = diff.to_json()
# Output: JSON string

# Pickle serialization
pickle_str = diff.to_pickle()
# Output: Pickle byte string

# Delta serialization
delta = Delta(diff)
delta_str = delta.dumps()
# Output: Serialized Delta object
```

### Node 12: Command Line Interface
**Function Description**: Provide a complete command line interface, supporting commands such as diff, patch, grep, and extract.
**Handling Strategy**:
- Support multiple file formats
- Support difference creation and application
- Support search function
- Support extraction function
**Input and Output Examples**:
```bash
# File comparison
deepdiff t1.json t2.json

# Create a patch
deepdiff t1.json t2.json --create-patch > delta.pickle

# Apply a patch
deepdiff patch t1.json delta.pickle

# Search function
deepdiff grep "value" data.json

# Extraction function
deepdiff extract "root['a']['b']" data.json
```

### Node 13: Error Handling and Validation
**Function Description**: Provide a comprehensive error handling mechanism, including exception catching, error messages, and validation functions.
**Handling Strategy**:
- Support exception catching
- Support error message formatting
- Support validation functions
- Support error recovery
**Input and Output Examples**:
```python
from deepdiff import DeepDiff, DeltaError

# Exception handling
try:
    result = DeepDiff(t1, t2)
except Exception as e:
    print(f"Comparison failed: {e}")

# Delta error handling
try:
    delta = Delta(diff)
    result = t1 + delta
except DeltaError as e:
    print(f"Delta application failed: {e}")

# Validation function
delta = Delta(diff)
assert delta.verify(t1, t2)  # Verify the correctness of the Delta
```

### Node 14: Advanced Search Functionality
**Function Description**: Implement the complete function of DeepSearch, including path matching, type filtering, and regular expressions.
**Handling Strategy**:
- Support path matching
- Support type filtering
- Support regular expressions
- Support case control
**Input and Output Examples**:
```python
from deepdiff import DeepSearch

obj = {"a": {"b": "hello", "c": "world"}, "d": "hello"}
search = DeepSearch(obj, "hello")

# Basic search
print(search.matched_paths)
# Output: ["root['a']['b']", "root['d']"]

# Regular expression search
search = DeepSearch(obj, r"h.*o", use_regexp=True)
print(search.matched_paths)
# Output: ["root['a']['b']", "root['d']"]

# Type filtering
search = DeepSearch(obj, "hello", exclude_types=[dict])
print(search.matched_paths)
# Output: ["root['d']"]
```

### Node 15: Hash Generation and Caching
**Function Description**: Implement the complete function of DeepHash, generating hash values for complex objects. This node specifically handles the hash generation and caching functions of complex objects, supporting multiple hash algorithms, custom hashers, and hash verification. Through the hash function, functions such as object deduplication, quick comparison, and data integrity verification can be achieved. It is very important for scenarios such as data deduplication, cache systems, and data integrity checks.
**Handling Strategy**:
- Support multiple hash algorithms (MD5, SHA1, SHA256, etc.)
- Support hash caching and hash result caching
- Support custom hashers and hash functions
- Support hash verification and hash collision detection
- Handle incremental hash calculation of large objects
- Support hash performance optimization and parallel computing
- Handle hash security checks and hash attack prevention
- Support hash version management and hash compatibility
- Handle hash errors and hash exceptions
- Support hash statistics and hash analysis
- Handle hash storage and hash transmission
**Input and Output Examples**:
```python
from deepdiff import DeepHash

obj = {"a": 1, "b": [2, 3], "c": {"d": 4}}

# Basic hash
hash_obj = DeepHash(obj)
print(hash_obj.hash)
# Output: Hash value string

# Custom hasher
def custom_hasher(obj):
    return hash(str(obj))

hash_obj = DeepHash(obj, hasher=custom_hasher)
print(hash_obj.hash)
# Output: Custom hash value

# Hash caching
hash_obj = DeepHash(obj, hashes={})
print(hash_obj.hash)
# Output: Use the cached hash value
```

### Node 16: Custom Operators
**Function Description**: Support custom comparison operators to implement special comparison logic. This node specifically handles the custom comparison operator function of DeepDiff, supporting user-defined special comparison rules and logic. Through custom operators, comparison requirements for specific business scenarios can be achieved, expanding the functionality of DeepDiff. It is very important for scenarios such as special data types, business rule comparison, and third-party library integration.
**Handling Strategy**:
- Support the `BaseOperator` base class and operator inheritance
- Support `BaseOperatorPlus` extension and advanced functions
- Support custom comparison functions and comparison logic
- Support operator registration and operator management
- Handle operator priority and operator chaining
- Support operator parameter passing and context management
- Handle operator errors and exception handling
- Support operator caching and performance optimization
- Handle operator version management and compatibility
- Support operator debugging and logging
- Handle operator security and permission control
**Input and Output Examples**:
```python
from deepdiff import DeepDiff
from deepdiff.operators import BaseOperator

class CustomOperator(BaseOperator):
    """
    Custom operator for specialized comparison logic
    
    Example implementation of a custom operator for handling specific comparison cases.
    """
    def give_up_diffing(self, level, diff_instance):
        return True

# Use custom operators
t1 = {"a": CustomClass(1)}
t2 = {"a": CustomClass(2)}
result = DeepDiff(t1, t2, custom_operators=[CustomOperator()])
# Output: Use custom comparison logic
```

### Node 17: Summarization and Formatting
**Function Description**: Provide result summarization and formatting functions, including tree views and text views. This node specifically handles the summarization generation and formatted output functions of DeepDiff results, supporting multiple output formats and view modes. Through the summarization and formatting functions, user-friendly difference displays can be provided, facilitating the understanding and analysis of comparison results. It is very important for scenarios such as report generation, user interfaces, and data analysis.
**Handling Strategy**:
- Support tree views and hierarchical structure displays
- Support text views and formatted output
- Support summarization generation and key information extraction
- Support formatted output and style control
- Handle summarization and truncation of large results
- Support multiple output formats (JSON, XML, HTML, etc.)
- Handle output encoding and character set support
- Support custom formatters and outputters
- Handle output performance optimization and streaming output
- Support output caching and output reuse
- Handle output errors and output validation
**Input and Output Examples**:
```python
from deepdiff import DeepDiff

t1 = {"a": {"b": 1, "c": 2}}
t2 = {"a": {"b": 1, "c": 3}}
diff = DeepDiff(t1, t2)

# Tree view
tree = diff.tree
print(tree)
# Output: Tree-structured differences

# Text view
text = diff.pretty()
print(text)
# Output: Formatted text differences

# Summary
summary = diff.summary()
print(summary)
# Output: Difference summary
```

### Node 18: Distance Calculation and Similarity
**Function Description**: Calculate the distance and similarity between objects, supporting multiple distance algorithms. This node specifically handles the distance calculation and similarity evaluation functions between objects, supporting multiple distance algorithms and similarity measurement methods. Through distance calculation, the degree of difference between objects can be quantified, providing a numerical basis for similarity analysis. It is very important for scenarios such as data clustering, similarity search, and quality evaluation.
**Handling Strategy**:
- Support rough distance calculation and quick approximation
- Support deep distance calculation and precise measurement
- Support numeric type distance and type-aware distance
- Support similarity thresholds and similarity grading
- Handle distance calculation for different data types
- Support custom distance functions and similarity algorithms
- Handle performance optimization and caching of distance calculation
- Support distance standardization and normalization
- Handle precision control and error handling of distance calculation
- Support distance statistics and distance analysis
- Handle parallel and distributed computing of distance calculation
**Input and Output Examples**:
```python
from deepdiff import DeepDiff

t1 = {"a": 1, "b": 2, "c": 3}
t2 = {"a": 1, "b": 3, "c": 4}
diff = DeepDiff(t1, t2)

# Rough distance
rough_dist = diff._get_rough_distance()
print(rough_dist)
# Output: Rough distance value

# Deep distance
deep_dist = diff.get_deep_distance()
print(deep_dist)
# Output: Deep distance value

# Numeric distance
numeric_dist = diff.get_numeric_types_distance()
print(numeric_dist)
# Output: Numeric type distance
```

### Node 19: Configuration Management and Validation
