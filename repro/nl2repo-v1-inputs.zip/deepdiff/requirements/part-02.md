            # Setting up the cache for dynamic programming. One dictionary per instance of root of DeepDiff running.
            self.max_passes = max_passes
            self.max_diffs = max_diffs
            self.cutoff_distance_for_pairs = float(cutoff_distance_for_pairs)
            self.cutoff_intersection_for_pairs = float(cutoff_intersection_for_pairs)
            if self.cutoff_distance_for_pairs < 0 or self.cutoff_distance_for_pairs > 1:
                raise ValueError(CUTOFF_RANGE_ERROR_MSG)
            # _Parameters are the clean _parameters to initialize DeepDiff with so we avoid all the above
            # cleaning functionalities when running DeepDiff recursively.
            # However DeepHash has its own set of _parameters that are slightly different than DeepDIff.
            # DeepDiff _parameters are transformed to DeepHash _parameters via _get_deephash_params method.
            self.progress_logger = progress_logger
            self.cache_size = cache_size
            _parameters = self.__dict__.copy()
            _parameters['group_by'] = None  # overwriting since these parameters will be passed on to other passes.
            if log_stacktrace:
                self.log_err = logger.exception
            else:
                self.log_err = logger.error

        # Non-Root
        if _shared_parameters:
            self.is_root = False
            self._shared_parameters = _shared_parameters
            self.__dict__.update(_shared_parameters)
            # We are in some pass other than root
            progress_timer = None
        # Root
        else:
            self.is_root = True
            # Caching the DeepDiff results for dynamic programming
            self._distance_cache = LFUCache(cache_size) if cache_size else DummyLFU()
            self._stats = {
                PASSES_COUNT: 0,
                DIFF_COUNT: 0,
                DISTANCE_CACHE_HIT_COUNT: 0,
                PREVIOUS_DIFF_COUNT: 0,
                PREVIOUS_DISTANCE_CACHE_HIT_COUNT: 0,
                MAX_PASS_LIMIT_REACHED: False,
                MAX_DIFF_LIMIT_REACHED: False,
                DISTANCE_CACHE_ENABLED: bool(cache_size),
            }
            self.hashes = dict_() if hashes is None else hashes
            self._numpy_paths = dict_()  # if _numpy_paths is None else _numpy_paths
            self.group_by_keys = set()  # Track keys that originated from group_by operations
            self._shared_parameters = {
                'hashes': self.hashes,
                '_stats': self._stats,
                '_distance_cache': self._distance_cache,
                'group_by_keys': self.group_by_keys,
                '_numpy_paths': self._numpy_paths,
                _ENABLE_CACHE_EVERY_X_DIFF: self.cache_tuning_sample_size * 10,
            }
            if log_frequency_in_sec:
                # Creating a progress log reporter that runs in a separate thread every log_frequency_in_sec seconds.
                progress_timer = RepeatedTimer(log_frequency_in_sec, _report_progress, self._stats, progress_logger)
            else:
                progress_timer = None

        self._parameters = _parameters
        self.deephash_parameters = self._get_deephash_params()
        self.tree = TreeResult()
        self._iterable_opcodes = {}
        if group_by and self.is_root:
            try:
                original_t1 = t1
                t1 = self._group_iterable_to_dict(t1, group_by, item_name='t1')
            except (KeyError, ValueError):
                pass
            else:
                try:
                    t2 = self._group_iterable_to_dict(t2, group_by, item_name='t2')
                except (KeyError, ValueError):
                    t1 = original_t1

        self.t1 = t1
        self.t2 = t2

        try:
            root = DiffLevel(t1, t2, verbose_level=self.verbose_level)
            # _original_type is only used to pass the original type of the data. Currently only used for numpy arrays.
            # The reason is that we convert the numpy array to python list and then later for distance calculations
            # we convert only the the last dimension of it into numpy arrays.
            self._diff(root, parents_ids=frozenset({id(t1)}), _original_type=_original_type)

            if get_deep_distance and view in {TEXT_VIEW, TREE_VIEW}:
                self.tree['deep_distance'] = self._get_rough_distance()

            self.tree.remove_empty_keys()
            view_results = self._get_view_results(self.view)
            if isinstance(view_results, ColoredView):
                self.update(view_results.tree)
                self._colored_view = view_results
            else:
                self.update(view_results)
        finally:
            if self.is_root:
                if cache_purge_level:
                    del self._distance_cache
                    del self.hashes
                del self._shared_parameters
                del self._parameters
                for key in (PREVIOUS_DIFF_COUNT, PREVIOUS_DISTANCE_CACHE_HIT_COUNT,
                            DISTANCE_CACHE_ENABLED):
                    del self._stats[key]
                if progress_timer:
                    duration = progress_timer.stop()
                    self._stats['DURATION SEC'] = duration
                    logger.info('stats {}'.format(self.get_stats()))
                if cache_purge_level == 2:
                    self.__dict__.clear()

    def _get_deephash_params(self):
        """
        Get parameters for DeepHash initialization
        
        Returns:
            dict: Parameters dictionary for DeepHash
        """

    def _report_result(self, report_type, change_level, local_tree=None):
        """
        Add a detected change to the reference-style result dictionary.
        report_type will be added to level.
        (We'll create the text-style report from there later.)
        :param report_type: A well defined string key describing the type of change.
                            Examples: "set_item_added", "values_changed"
        :param change_level: A DiffLevel object describing the objects in question in their
                       before-change and after-change object structure.

        :local_tree: None
        """



    def custom_report_result(self, report_type, level, extra_info=None):
        """
        Add a detected change to the reference-style result dictionary.
        report_type will be added to level.
        (We'll create the text-style report from there later.)
        :param report_type: A well defined string key describing the type of change.
                            Examples: "set_item_added", "values_changed"
        :param parent: A DiffLevel object describing the objects in question in their
                       before-change and after-change object structure.
        :param extra_info: A dict that describe this result
        :rtype: None
        """



    @staticmethod
    def _dict_from_slots(object: Any) -> Dict[str, Any]:
        """
        Create dictionary from object slots
        
        Args:
            object: The object to extract slots from
            
        Returns:
            Dict[str, Any]: Dictionary containing slot attributes
        """
        def unmangle(attribute: str) -> str:
            """
            Unmangle attribute name
            
            Args:
                attribute: The mangled attribute name
                
            Returns:
                str: Unmangled attribute name
            """




    def _diff_enum(self, level: Any, parents_ids: FrozenSet[int]=frozenset(), local_tree: Optional[Any]=None) -> None:
        """
        Compare enum objects
        
        Args:
            level: The comparison level
            parents_ids: Set of parent object IDs
            local_tree: Local tree structure
        """
       

    def _diff_obj(self, level: Any, parents_ids: FrozenSet[int]=frozenset(), is_namedtuple: bool=False, local_tree: Optional[Any]=None, is_pydantic_object: bool=False) -> None:
        """Difference of 2 objects"""
        

    def _skip_this(self, level: Any) -> bool:
        """
        Check whether this comparison should be skipped because one of the objects to compare meets exclusion criteria.
        :rtype: bool
        """
        

    def _skip_this_key(self, level: Any, key: Any) -> bool:
        """
        Check if a key should be skipped during comparison
        
        Args:
            level: The comparison level
            key: The key to check
            
        Returns:
            bool: True if key should be skipped, False otherwise
        """
        # if include_paths is not set, than treet every path as included
        

    def _get_clean_to_keys_mapping(self, keys: Any, level: Any) -> Dict[Any, Any]:
        """
        Get a dictionary of cleaned value of keys to the keys themselves.
        This is mainly used to transform the keys when the type changes of keys should be ignored.

        TODO: needs also some key conversion for groups of types other than the built-in strings and numbers.
        """
        

    def _diff_dict(
        self,
        level: Any,
        parents_ids: FrozenSet[int]=frozenset([]),
        print_as_attribute: bool=False,
        override: bool=False,
        override_t1: Optional[Any]=None,
        override_t2: Optional[Any]=None,
        local_tree: Optional[Any]=None,
    ) -> None:
        """Difference of 2 dictionaries"""
       

    def _diff_set(self, level: Any, local_tree: Optional[Any]=None) -> None:
        """Difference of sets"""
        

    @staticmethod
    def _iterables_subscriptable(t1: Any, t2: Any) -> bool:
        """
        Check if two iterables are subscriptable
        
        Args:
            t1: First iterable to check
            t2: Second iterable to check
            
        Returns:
            bool: True if both iterables are subscriptable, False otherwise
        """


    def _diff_iterable(self, level: Any, parents_ids: FrozenSet[int]=frozenset(), _original_type: Optional[type]=None, local_tree: Optional[Any]=None) -> None:
        """Difference of iterables"""


    def _compare_in_order(
        self, level,
        t1_from_index=None, t1_to_index=None,
        t2_from_index=None, t2_to_index=None
    ) -> List[Tuple[Tuple[int, int], Tuple[Any, Any]]]:
        """
        Default compare if `iterable_compare_func` is not provided.
        This will compare in sequence order.
        """
        
    def _get_matching_pairs(
        self, level,
        t1_from_index=None, t1_to_index=None,
        t2_from_index=None, t2_to_index=None
    ) -> List[Tuple[Tuple[int, int], Tuple[Any, Any]]]:
        """
        Given a level get matching pairs. This returns list of two tuples in the form:
        [
          (t1 index, t2 index), (t1 item, t2 item)
        ]

        This will compare using the passed in `iterable_compare_func` if available.
        Default it to compare in order
        """

        

    def _diff_iterable_in_order(self, level, parents_ids=frozenset(), _original_type=None, local_tree=None):
        # We're handling both subscriptable and non-subscriptable iterables. Which one is it?
        

    def _all_values_basic_hashable(self, iterable: Iterable[Any]) -> bool:
        """
        Are all items basic hashable types?
        Or there are custom types too?
        """

    # We don't want to exhaust a generator
        

    def _diff_by_forming_pairs_and_comparing_one_by_one(
        self, level, local_tree, parents_ids=frozenset(),
        _original_type=None, child_relationship_class=None,
        t1_from_index=None, t1_to_index=None,
        t2_from_index=None, t2_to_index=None,
    ):
        """
        Compare iterables by forming pairs and comparing one by one
        
        Args:
            level: The comparison level
            local_tree: Local tree structure
            parents_ids: Set of parent object IDs
            _original_type: Original type of objects
            child_relationship_class: Class for child relationships
            t1_from_index: Start index for t1
            t1_to_index: End index for t1
            t2_from_index: Start index for t2
            t2_to_index: End index for t2
        """
        

    def _diff_ordered_iterable_by_difflib(
        self, level, local_tree, parents_ids=frozenset(), _original_type=None, child_relationship_class=None,
    ):
        """
        Compare ordered iterables using difflib
        
        Args:
            level: The comparison level
            local_tree: Local tree structure
            parents_ids: Set of parent object IDs
            _original_type: Original type of objects
            child_relationship_class: Class for child relationships
        """
        


    def _diff_str(self, level, local_tree=None):
        """Compare strings"""
        

    def _diff_tuple(self, level, parents_ids, local_tree=None):
        # Checking to see if it has _fields. Which probably means it is a named
        # tuple.
       
    def _add_hash(self, hashes, item_hash, item, i):
        """
        Add hash to the hashes dictionary
        
        Args:
            hashes: Dictionary to store hashes
            item_hash: Hash value of the item
            item: The item being hashed
            i: Index or identifier for the item
        """
        

    def _create_hashtable(self, level, t):
        """Create hashtable of {item_hash: (indexes, item)}"""
       
    @staticmethod
    @lru_cache(maxsize=2028)
    def _get_distance_cache_key(added_hash, removed_hash):
        """
        Get cache key for distance calculation
        
        Args:
            added_hash: Hash of the added item
            removed_hash: Hash of the removed item
            
        Returns:
            tuple: Cache key for distance calculation
        """
        

    def _get_rough_distance_of_hashed_objs(
            self, added_hash, removed_hash, added_hash_obj, removed_hash_obj, _original_type=None):
        """
        Get rough distance between two hashed objects to determine if they qualify as pairs
        
        Args:
            added_hash: Hash of the added object
            removed_hash: Hash of the removed object
            added_hash_obj: The added object
            removed_hash_obj: The removed object
            _original_type: Original type of objects
            
        Returns:
            float: Distance between the objects
        """
        # We need the rough distance between the 2 objects to see if they qualify to be pairs or not
        

    def _get_most_in_common_pairs_in_iterables(
            self, hashes_added, hashes_removed, t1_hashtable, t2_hashtable, parents_ids, _original_type):
        """
        Get the closest pairs between items that are removed and items that are added.

        returns a dictionary of hashes that are closest to each other.
        The dictionary is going to be symmetrical so any key will be a value too and otherwise.

        Note that due to the current reporting structure in DeepDiff, we don't compare an item that
        was added to an item that is in both t1 and t2.

        For example

        [{1, 2}, {4, 5, 6}]
        [{1, 2}, {1, 2, 3}]

        is only compared between {4, 5, 6} and {1, 2, 3} even though technically {1, 2, 3} is
        just one item different than {1, 2}

        Perhaps in future we can have a report key that is item duplicated and modified instead of just added.
        """
      

        # A dictionary of hashes to distances and each distance to an ordered set of hashes.
        # It tells us about the distance of each object from other objects.
        # And the objects with the same distances are grouped together in an ordered set.
        # It also includes a "max" key that is just the value of the biggest current distance in the
        # most_in_common_pairs dictionary.
        def defaultdict_orderedset():
            """
            Create a defaultdict with SetOrdered as default factory
            
            Returns:
                defaultdict: Dictionary with SetOrdered default factory
            """
            

    def _diff_iterable_with_deephash(self, level, parents_ids, _original_type=None, local_tree=None):
        """
        Diff of hashable or unhashable iterables. Only used when ignoring the order.
        
        Args:
            level: The comparison level
            parents_ids: Set of parent object IDs
            _original_type: Original type of objects
            local_tree: Local tree structure
        """

       

        def get_other_pair(hash_value, in_t1=True):
            """
            Gets the other paired indexed hash item to the hash_value in the pairs dictionary
            in_t1: are we looking for the other pair in t1 or t2?
            """
            

    def _diff_booleans(self, level, local_tree=None):
        """
        Compare boolean values
        
        Args:
            level: The comparison level
            local_tree: Local tree structure
        """


    def _diff_numbers(self, level, local_tree=None, report_type_change=True):
        """Diff Numbers"""
        
    def _diff_ipranges(self, level, local_tree=None):
        """Diff IP ranges"""


    def _diff_datetime(self, level, local_tree=None):
        """Diff DateTimes"""

    def _diff_time(self, level, local_tree=None):
        """Diff DateTimes"""

    def _diff_uuids(self, level, local_tree=None):
        """Diff UUIDs"""


    def _diff_numpy_array(self, level, parents_ids=frozenset(), local_tree=None):
        """Diff numpy arrays"""
        
    def _diff_types(self, level, local_tree=None):
        """Diff types"""


    def _count_diff(self):
        """
        Count the number of differences found
        
        Returns:
            int: Number of differences or StopIteration if limit reached
        """


    def _auto_tune_cache(self):
        """
        Automatically tune cache settings based on performance
        
        Adjusts cache parameters to optimize performance based on usage patterns.
        """
       

    def _auto_off_cache(self):
        """
        Auto adjust the cache based on the usage
        """
        

    def _use_custom_operator(self, level):
        """
        For each level we check all custom operators.
        If any one of them was a match for the level, we run the diff of the operator.
        If the operator returned True, the operator must have decided these objects should not
        be compared anymore. It might have already reported their results.
        In that case the report will appear in the final results of this diff.
        Otherwise basically the 2 objects in the level are being omitted from the results.
        """

        

    def _diff(self, level, parents_ids=frozenset(), _original_type=None, local_tree=None):
        """
        The main diff method

        **parameters**

        level: the tree level or tree node
        parents_ids: the ids of all the parent objects in the tree from the current node.
        _original_type: If the objects had an original type that was different than what currently exists in the level.t1 and t2
        """
       

    def _get_view_results(self, view):
        """
        Get the results based on the view
        """
        

    @staticmethod
    def _get_key_for_group_by(row, group_by, item_name):
        """
        Get the key for group_by functionality
        
        Args:
            row: The row data to extract key from
            group_by: The field name to group by
            item_name: The item name for the group
            
        Returns:
            The key value for grouping
        """


    def _group_iterable_to_dict(self, item, group_by, item_name):
        """
        Convert a list of dictionaries into a dictionary of dictionaries
        where the key is the value of the group_by key in each dictionary.
        """
        

    def get_stats(self):
        """
        Get some stats on internals of the DeepDiff run.
        """


    @property
    def affected_paths(self):
        """
        Get the list of paths that were affected.
        Whether a value was changed or they were added or removed.

        Example
            >>> t1 = {1: 1, 2: 2, 3: [3], 4: 4}
            >>> t2 = {1: 1, 2: 4, 3: [3, 4], 5: 5, 6: 6}
            >>> ddiff = DeepDiff(t1, t2)
            >>> ddiff
            >>> pprint(ddiff, indent=4)
            {   'dictionary_item_added': [root[5], root[6]],
                'dictionary_item_removed': [root[4]],
                'iterable_item_added': {'root[3][1]': 4},
                'values_changed': {'root[2]': {'new_value': 4, 'old_value': 2}}}
            >>> ddiff.affected_paths
            SetOrdered(['root[3][1]', 'root[4]', 'root[5]', 'root[6]', 'root[2]'])
            >>> ddiff.affected_root_keys
            SetOrdered([3, 4, 5, 6, 2])

        """
        

    @property
    def affected_root_keys(self):
        """
        Get the list of root keys that were affected.
        Whether a value was changed or they were added or removed.

        Example
            >>> t1 = {1: 1, 2: 2, 3: [3], 4: 4}
            >>> t2 = {1: 1, 2: 4, 3: [3, 4], 5: 5, 6: 6}
            >>> ddiff = DeepDiff(t1, t2)
            >>> ddiff
            >>> pprint(ddiff, indent=4)
            {   'dictionary_item_added': [root[5], root[6]],
                'dictionary_item_removed': [root[4]],
                'iterable_item_added': {'root[3][1]': 4},
                'values_changed': {'root[2]': {'new_value': 4, 'old_value': 2}}}
            >>> ddiff.affected_paths
            SetOrdered(['root[3][1]', 'root[4]', 'root[5]', 'root[6]', 'root[2]'])
            >>> ddiff.affected_root_keys
            SetOrdered([3, 4, 5, 6, 2])
        """
        

    def __str__(self):
        """
        Return string representation of the Delta object
        
        Returns:
            str: String representation of the delta
        """

```


### 3. Delta Class

**Function**: Create a delta object from a diff object.

**Class Definition**:
```python
class Delta:
    """
    Apply difference results to objects
    
    Used to apply difference results generated by DeepDiff back to objects,
    implementing incremental updates and synchronization functionality.
    """

    __doc__ = doc

    def __init__(
        self,
        diff: Union[DeepDiff, Mapping, str, bytes, None]=None,
        delta_path: Optional[str]=None,
        delta_file: Optional[IO]=None,
        delta_diff: Optional[dict]=None,
        flat_dict_list: Optional[List[Dict]]=None,
        flat_rows_list: Optional[List[FlatDeltaRow]]=None,
        deserializer: Callable=pickle_load,
        log_errors: bool=True,
        mutate: bool=False,
        raise_errors: bool=False,
        safe_to_import: Optional[Set[str]]=None,
        serializer: Callable=pickle_dump,
        verify_symmetry: Optional[bool]=None,
        bidirectional: bool=False,
        always_include_values: bool=False,
        iterable_compare_func_was_used: Optional[bool]=None,
        force: bool=False,
        fill: Any=not_found,
    ):
        # for pickle deserializer:
        if hasattr(deserializer, '__code__') and 'safe_to_import' in set(deserializer.__code__.co_varnames):
            _deserializer = deserializer
        else:
            def _deserializer(obj, safe_to_import=None):
                result = deserializer(obj)
                if result.get('_iterable_opcodes'):
                    _iterable_opcodes = {}
                    for path, op_codes in result['_iterable_opcodes'].items():
                        _iterable_opcodes[path] = []
                        for op_code in op_codes:
                            _iterable_opcodes[path].append(
                                Opcode(
