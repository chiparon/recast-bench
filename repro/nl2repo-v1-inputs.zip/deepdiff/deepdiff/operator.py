# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class BaseOperatorPlus:

    def match(self, level) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def give_up_diffing(self, level, diff_instance: 'DeepDiff') -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def normalize_value_for_hashing(self, parent: Any, obj: Any) -> Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class BaseOperator:

    def __init__(self, regex_paths: Optional[List[str]]=..., types: Optional[List[type]]=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def match(self, level) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def give_up_diffing(self, level, diff_instance) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class PrefixOrSuffixOperator:

    def match(self, level) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def give_up_diffing(self, level, diff_instance) -> bool:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
