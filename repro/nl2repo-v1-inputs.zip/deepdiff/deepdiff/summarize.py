# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

def _truncate(s: str, max_len: int) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def calculate_weights(node):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def shrink_tree_balanced(node_structure, max_weight: int, balance_threshold: float) -> Tuple[JSON, float]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def greedy_tree_summarization_balanced(json_data: JSON, max_weight: int, balance_threshold=...) -> JSON:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def summarize(data: JSON, max_length: int=..., balance_threshold: float=...) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
