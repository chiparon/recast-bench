# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
orjson = ...
logger = ...

class UnsupportedFormatErr:
    pass
NONE_TYPE = ...
CSV_HEADER_MAX_CHUNK_SIZE = ...
MODULE_NOT_FOUND_MSG = ...
FORBIDDEN_MODULE_MSG = ...
DELTA_IGNORE_ORDER_NEEDS_REPETITION_REPORT = ...
DELTA_ERROR_WHEN_GROUP_BY = ...
SAFE_TO_IMPORT = ...
TYPE_STR_TO_TYPE = ...

class ModuleNotFoundError:
    pass

class ForbiddenModule:
    pass

class SerializationMixin:

    def to_json_pickle(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_json_pickle(cls, value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_json(self, default_mapping: Optional[dict]=..., force_use_builtin_json=..., **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_dict(self, view_override: Optional[str]=...) -> dict:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _to_delta_dict(self, directed: bool=..., report_repetition_required: bool=..., always_include_values: bool=...) -> dict:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pretty(self, prefix: Optional[Union[str, Callable]]=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class _RestrictedUnpickler:

    def __init__(self, *args, **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def find_class(self, module, name):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def persistent_load(self, pid):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class _RestrictedPickler:

    def persistent_id(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def pickle_dump(obj, file_obj=..., protocol=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def pickle_load(content=..., file_obj=..., safe_to_import=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_pretty_form_text(verbose_level):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def pretty_print_diff(diff):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def load_path_content(path, file_type=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def save_content_to_path(content, path, file_type=..., keep_backup=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _save_content(content, path, file_type, keep_backup=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _serialize_decimal(value):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _serialize_tuple(value):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
JSON_CONVERTOR = ...
JSON_CONVERTOR = ...
PydanticBaseModel = ...

def json_convertor_default(default_mapping=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class JSONDecoder:

    def __init__(self, *args, **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def object_hook(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def json_dumps(item: Any, **kwargs) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def json_dumps(item: Any, default_mapping: Optional[dict], force_use_builtin_json: bool, return_bytes: Literal[True], **kwargs) -> bytes:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def json_dumps(item: Any, default_mapping: Optional[dict], force_use_builtin_json: bool, return_bytes: Literal[False], **kwargs) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def json_dumps(item: Any, default_mapping: Optional[dict]=..., force_use_builtin_json: bool=..., return_bytes: bool=..., **kwargs) -> Union[str, bytes]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
json_loads = ...
