# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class CacheNode:

    def __init__(self, key, report_type, value, freq_node, pre, nxt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def free_myself(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class FreqNode:

    def __init__(self, freq, pre, nxt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def count_caches(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def remove(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pop_head_cache(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def append_cache_to_tail(self, cache_node):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def insert_after_me(self, freq_node):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def insert_before_me(self, freq_node):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class LFUCache:

    def __init__(self, capacity):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get(self, key):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def set(self, key, report_type=..., value=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __contains__(self, key):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def move_forward(self, cache_node, freq_node):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dump_cache(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def create_cache_node(self, key, report_type, value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_sorted_cache_keys(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_average_frequency(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class DummyLFU:

    def __init__(self, *args, **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    set = ...
    get = ...

    def __contains__(self, key):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
