# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
logger = ...
MAX_PASSES_REACHED_MSG = ...
MAX_DIFFS_REACHED_MSG = ...
notpresent_indexed = ...
doc = ...
PROGRESS_MSG = ...

def _report_progress(_stats, progress_logger, duration):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
DISTANCE_CACHE_HIT_COUNT = ...
DIFF_COUNT = ...
PASSES_COUNT = ...
MAX_PASS_LIMIT_REACHED = ...
MAX_DIFF_LIMIT_REACHED = ...
DISTANCE_CACHE_ENABLED = ...
PREVIOUS_DIFF_COUNT = ...
PREVIOUS_DISTANCE_CACHE_HIT_COUNT = ...
CANT_FIND_NUMPY_MSG = ...
INVALID_VIEW_MSG = ...
CUTOFF_RANGE_ERROR_MSG = ...
VERBOSE_LEVEL_RANGE_MSG = ...
PURGE_LEVEL_RANGE_MSG = ...
_ENABLE_CACHE_EVERY_X_DIFF = ...
model_fields_set = ...
CUTOFF_DISTANCE_FOR_PAIRS_DEFAULT = ...
CUTOFF_INTERSECTION_FOR_PAIRS_DEFAULT = ...
DEEPHASH_PARAM_KEYS = ...

class DeepDiffProtocol:
    t1 = ...
    t2 = ...
    cutoff_distance_for_pairs = ...
    use_log_scale = ...
    log_scale_similarity_threshold = ...
    view = ...

class DeepDiff:
    __doc__ = ...
    CACHE_AUTO_ADJUST_THRESHOLD = ...

    def __init__(self, t1: Any, t2: Any, _original_type=..., cache_purge_level: int=..., cache_size: int=..., cache_tuning_sample_size: int=..., custom_operators: Optional[List[Any]]=..., cutoff_distance_for_pairs: float=..., cutoff_intersection_for_pairs: float=..., default_timezone: Union[datetime.timezone, 'BaseTzInfo']=..., encodings: Optional[List[str]]=..., exclude_obj_callback: Optional[Callable]=..., exclude_obj_callback_strict: Optional[Callable]=..., exclude_paths: Union[str, List[str], Set[str], FrozenSet[str], None]=..., exclude_regex_paths: Union[str, List[str], Pattern[str], List[Pattern[str]], None]=..., exclude_types: Optional[List[Any]]=..., get_deep_distance: bool=..., group_by: Union[str, Tuple[str, str], None]=..., group_by_sort_key: Union[str, Callable, None]=..., hasher: Optional[Callable]=..., hashes: Optional[Dict]=..., ignore_encoding_errors: bool=..., ignore_nan_inequality: bool=..., ignore_numeric_type_changes: bool=..., ignore_order: bool=..., ignore_order_func: Optional[Callable]=..., ignore_private_variables: bool=..., ignore_string_case: bool=..., ignore_string_type_changes: bool=..., ignore_type_in_groups: Optional[List[Tuple]]=..., ignore_type_subclasses: bool=..., include_obj_callback: Optional[Callable]=..., include_obj_callback_strict: Optional[Callable]=..., include_paths: Union[str, List[str], None]=..., iterable_compare_func: Optional[Callable]=..., log_frequency_in_sec: int=..., log_scale_similarity_threshold: float=..., log_stacktrace: bool=..., math_epsilon: Optional[float]=..., max_diffs: Optional[int]=..., max_passes: int=..., number_format_notation: str=..., number_to_string_func: Optional[Callable]=..., progress_logger: Callable=..., report_repetition: bool=..., significant_digits: Optional[int]=..., threshold_to_diff_deeper: float=..., truncate_datetime: Optional[str]=..., use_enum_value: bool=..., use_log_scale: bool=..., verbose_level: int=..., view: str=..., zip_ordered_iterables: bool=..., _parameters=..., _shared_parameters=..., **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_deephash_params(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _report_result(self, report_type, change_level, local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def custom_report_result(self, report_type, level, extra_info=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _dict_from_slots(object):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_enum(self, level, parents_ids=..., local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_obj(self, level, parents_ids=..., is_namedtuple=..., local_tree=..., is_pydantic_object=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _skip_this(self, level):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _skip_this_key(self, level, key):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_clean_to_keys_mapping(self, keys, level):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_dict(self, level, parents_ids=..., print_as_attribute=..., override=..., override_t1=..., override_t2=..., local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_set(self, level, local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _iterables_subscriptable(t1, t2):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_iterable(self, level, parents_ids=..., _original_type=..., local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _compare_in_order(self, level, t1_from_index=..., t1_to_index=..., t2_from_index=..., t2_to_index=...) -> List[Tuple[Tuple[int, int], Tuple[Any, Any]]]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_matching_pairs(self, level, t1_from_index=..., t1_to_index=..., t2_from_index=..., t2_to_index=...) -> List[Tuple[Tuple[int, int], Tuple[Any, Any]]]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_iterable_in_order(self, level, parents_ids=..., _original_type=..., local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _all_values_basic_hashable(self, iterable):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_by_forming_pairs_and_comparing_one_by_one(self, level, local_tree, parents_ids=..., _original_type=..., child_relationship_class=..., t1_from_index=..., t1_to_index=..., t2_from_index=..., t2_to_index=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_ordered_iterable_by_difflib(self, level, local_tree, parents_ids=..., _original_type=..., child_relationship_class=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_str(self, level, local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_tuple(self, level, parents_ids, local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _add_hash(self, hashes, item_hash, item, i):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _create_hashtable(self, level, t):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_distance_cache_key(added_hash, removed_hash):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_rough_distance_of_hashed_objs(self, added_hash, removed_hash, added_hash_obj, removed_hash_obj, _original_type=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_most_in_common_pairs_in_iterables(self, hashes_added, hashes_removed, t1_hashtable, t2_hashtable, parents_ids, _original_type):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_iterable_with_deephash(self, level, parents_ids, _original_type=..., local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_booleans(self, level, local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_numbers(self, level, local_tree=..., report_type_change=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_ipranges(self, level, local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_datetime(self, level, local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_time(self, level, local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_uuids(self, level, local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_numpy_array(self, level, parents_ids=..., local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff_types(self, level, local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _count_diff(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _auto_tune_cache(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _auto_off_cache(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _use_custom_operator(self, level):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _diff(self, level, parents_ids=..., _original_type=..., local_tree=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_view_results(self, view):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_key_for_group_by(row, group_by, item_name):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _group_iterable_to_dict(self, item, group_by, item_name):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_stats(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def affected_paths(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def affected_root_keys(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
