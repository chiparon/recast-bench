# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
logger = ...
doc = ...

class DeepSearch:
    warning_num = ...

    def __init__(self, obj, item, exclude_paths=..., exclude_regex_paths=..., exclude_types=..., verbose_level=..., case_sensitive=..., match_string=..., use_regexp=..., strict_checking=..., **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __set_or_dict(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __report(self, report_key, key, value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __search_obj(self, obj, item, parent, parents_ids=..., is_namedtuple=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __skip_this(self, item, parent):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __search_dict(self, obj, item, parent, parents_ids=..., print_as_attribute=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __search_iterable(self, obj, item, parent=..., parents_ids=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __search_str(self, obj, item, parent):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __search_numbers(self, obj, item, parent):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __search_tuple(self, obj, item, parent, parents_ids):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __search(self, obj, item, parent=..., parents_ids=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class grep:
    __doc__ = ...

    def __init__(self, item, **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ror__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
