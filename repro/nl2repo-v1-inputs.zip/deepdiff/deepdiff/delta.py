# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
logger = ...
VERIFICATION_MSG = ...
ELEM_NOT_FOUND_TO_ADD_MSG = ...
TYPE_CHANGE_FAIL_MSG = ...
VERIFY_BIDIRECTIONAL_MSG = ...
FAIL_TO_REMOVE_ITEM_IGNORE_ORDER_MSG = ...
DELTA_NUMPY_OPERATOR_OVERRIDE_MSG = ...
BINIARY_MODE_NEEDED_MSG = ...
DELTA_AT_LEAST_ONE_ARG_NEEDED = ...
INVALID_ACTION_WHEN_CALLING_GET_ELEM = ...
INVALID_ACTION_WHEN_CALLING_SIMPLE_SET_ELEM = ...
INVALID_ACTION_WHEN_CALLING_SIMPLE_DELETE_ELEM = ...
UNABLE_TO_GET_ITEM_MSG = ...
UNABLE_TO_GET_PATH_MSG = ...
INDEXES_NOT_FOUND_WHEN_IGNORE_ORDER = ...
NUMPY_TO_LIST = ...
NOT_VALID_NUMPY_TYPE = ...
doc = ...

class DeltaError:
    pass

class DeltaNumpyOperatorOverrideError:
    pass

class Delta:
    __doc__ = ...

    def __init__(self, diff: Union[DeepDiff, Mapping, str, bytes, None]=..., delta_path: Optional[str]=..., delta_file: Optional[IO]=..., delta_diff: Optional[dict]=..., flat_dict_list: Optional[List[Dict]]=..., flat_rows_list: Optional[List[FlatDeltaRow]]=..., deserializer: Callable=..., log_errors: bool=..., mutate: bool=..., raise_errors: bool=..., safe_to_import: Optional[Set[str]]=..., serializer: Callable=..., verify_symmetry: Optional[bool]=..., bidirectional: bool=..., always_include_values: bool=..., iterable_compare_func_was_used: Optional[bool]=..., force: bool=..., fill: Any=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def reset(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __add__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __radd__ = ...

    def __rsub__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _raise_or_log(self, msg, level=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_verify_changes(self, path, expected_old_value, current_old_value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_elem_and_compare_to_old_value(self, obj, path_for_err_reporting, expected_old_value, elem=..., action=..., forced_old_value=..., next_element=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _simple_set_elem_value(self, obj, path_for_err_reporting, elem=..., value=..., action=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _coerce_obj(self, parent, obj, path, parent_to_obj_elem, parent_to_obj_action, elements, to_type, from_type):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _set_new_value(self, parent, parent_to_obj_elem, parent_to_obj_action, obj, elements, path, elem, action, new_value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _simple_delete_elem(self, obj, path_for_err_reporting, elem=..., action=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _del_elem(self, parent, parent_to_obj_elem, parent_to_obj_action, obj, elements, path, elem, action):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_iterable_item_added(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_dictionary_item_added(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_attribute_added(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _sort_key_for_item_added(path_and_value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _sort_comparison(left, right):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_item_added(self, items, sort=..., insert=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_values_changed(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_type_changes(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_post_process(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_pre_process(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_elements_and_details(self, path):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_values_or_type_changed(self, changes, is_type_change=..., verify_changes=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_item_removed(self, items):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _find_closest_iterable_element_for_index(self, obj, elem, expected_old_value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_iterable_opcodes(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_iterable_item_removed(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_dictionary_item_removed(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_attribute_removed(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_set_item_added(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_set_item_removed(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_set_or_frozenset_item(self, items, func):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_ignore_order_get_old(self, obj, remove_indexes_per_path, fixed_indexes_values, path_for_err_reporting):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _do_ignore_order(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_reverse_diff(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dump(self, file):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dumps(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_dict(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _flatten_iterable_opcodes(self, _parse_path):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_flat_row(action, info, _parse_path, keys_and_funcs, report_type_changes=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_flat_rows(flat_rows_list: List[FlatDeltaRow]):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_flat_dicts(flat_dict_list):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_flat_dicts(self, include_action_in_path=..., report_type_changes=...) -> List[FlatDeltaRow]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_flat_rows(self, include_action_in_path=..., report_type_changes=...) -> List[FlatDeltaRow]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
