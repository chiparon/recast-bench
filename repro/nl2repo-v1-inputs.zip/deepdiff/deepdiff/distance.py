# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class DistanceProtocol:
    hashes = ...
    deephash_parameters = ...
    iterable_compare_func = ...
    math_epsilon = ...
    cutoff_distance_for_pairs = ...

    def __get_item_rough_length(self, item, parent: str=...) -> float:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _to_delta_dict(self, directed: bool=..., report_repetition_required: bool=..., always_include_values: bool=...) -> dict:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __calculate_item_deephash(self, item: Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
DISTANCE_CALCS_NEEDS_CACHE = ...

class DistanceMixin:

    def _get_rough_distance(self: 'DistanceProtocol'):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __get_item_rough_length(self: 'DistanceProtocol', item, parent=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __calculate_item_deephash(self: 'DistanceProtocol', item: Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _precalculate_distance_by_custom_compare_func(self: 'DistanceProtocol', hashes_added, hashes_removed, t1_hashtable, t2_hashtable, _original_type):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _precalculate_numpy_arrays_distance(self: 'DistanceProtocol', hashes_added, hashes_removed, t1_hashtable, t2_hashtable, _original_type):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_item_length(item, parents_ids=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_numbers_distance(num1, num2, max_=..., use_log_scale=..., log_scale_similarity_threshold=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _numpy_div(a, b, replace_inf_with=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
MATH_LOG_OFFSET = ...

def numpy_apply_log_keep_sign(array, offset=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def logarithmic_similarity(a: numbers, b: numbers, threshold: float=...) -> float:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def logarithmic_distance(a: numbers, b: numbers) -> float:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_numpy_array_distance(num1, num2, max_=..., use_log_scale=..., log_scale_similarity_threshold=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_datetime_distance(date1, date2, max_, use_log_scale, log_scale_similarity_threshold):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_date_distance(date1, date2, max_, use_log_scale, log_scale_similarity_threshold):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_timedelta_distance(timedelta1, timedelta2, max_, use_log_scale, log_scale_similarity_threshold):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_time_distance(time1, time2, max_, use_log_scale, log_scale_similarity_threshold):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
TYPES_TO_DIST_FUNC = ...

def get_numeric_types_distance(num1, num2, max_, use_log_scale=..., log_scale_similarity_threshold=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
