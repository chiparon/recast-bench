# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
logger = ...
FORCE_DEFAULT = ...
UP_DOWN = ...
REPORT_KEYS = ...
CUSTOM_FIELD = ...

class DoesNotExist:
    pass

class ResultDict:

    def remove_empty_keys(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TreeResult:

    def __init__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def mutual_add_removes_to_become_value_changes(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TextResult:
    ADD_QUOTES_TO_STRINGS = ...

    def __init__(self, tree_results=..., verbose_level=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __set_or_dict(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_results(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_default(self, tree, report_type, ignore_if_in_iterable_opcodes=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_type_changes(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_value_changed(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_iterable_item_moved(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_unprocessed(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_set_item_added_or_removed(self, tree, key):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_set_item_added(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_set_item_removed(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_repetition_change(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_deep_distance(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_custom_results(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class DeltaResult:
    ADD_QUOTES_TO_STRINGS = ...

    def __init__(self, tree_results=..., ignore_order=..., always_include_values=..., _iterable_opcodes=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_results(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_iterable_item_added_or_removed(self, tree, report_type, delta_report_key):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_type_changes(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_value_changed(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_repetition_change(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _from_tree_iterable_item_moved(self, tree):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class DiffLevel:

    def __init__(self, t1, t2, down=..., up=..., report_type=..., child_rel1=..., child_rel2=..., additional=..., verbose_level=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __setattr__(self, key, value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def repetition(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def auto_generate_child_rel(self, klass, param, param2=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def all_up(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def all_down(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _format_result(root, result):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_root_key(self, use_t2=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def path(self, root=..., force=..., get_parent_too=..., use_t2=..., output_format=..., reporting_move=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def create_deeper(self, new_t1, new_t2, child_relationship_class, child_relationship_param=..., child_relationship_param2=..., report_type=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def branch_deeper(self, new_t1, new_t2, child_relationship_class, child_relationship_param=..., child_relationship_param2=..., report_type=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def copy(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class ChildRelationship:
    param_repr_format = ...
    quote_str = ...

    def create(klass, parent, child, param=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __init__(self, parent, child, param=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_param_repr(self, force=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def stringify_param(self, force=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class DictRelationship:
    param_repr_format = ...
    quote_str = ...

class NumpyArrayRelationship:
    param_repr_format = ...
    quote_str = ...

class SubscriptableIterableRelationship:
    pass

class InaccessibleRelationship:
    pass

class SetRelationship:
    pass

class NonSubscriptableIterableRelationship:
    param_repr_format = ...

    def get_param_repr(self, force=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class AttributeRelationship:
    param_repr_format = ...
