# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
orjson = ...

def cli():
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def diff(*args, **kwargs):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def patch(path, delta_path, backup, raise_errors, debug):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def grep(item, path, debug, **kwargs):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def extract(path_inside, path, debug):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
