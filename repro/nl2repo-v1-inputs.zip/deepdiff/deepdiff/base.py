# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
DEFAULT_SIGNIFICANT_DIGITS_WHEN_IGNORE_NUMERIC_TYPES = ...
TYPE_STABILIZATION_MSG = ...

class Base:
    numbers = ...
    strings = ...

    def get_significant_digits(self, significant_digits, ignore_numeric_type_changes):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_ignore_types_in_groups(self, ignore_type_in_groups, ignore_string_type_changes, ignore_numeric_type_changes, ignore_type_subclasses):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
