# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
pandas = ...
polars = ...
booleanTypes = ...
booleanTypes = ...
logger = ...
UNPROCESSED_KEY = ...
EMPTY_FROZENSET = ...
INDEX_VS_ATTRIBUTE = ...
HASH_LOOKUP_ERR_MSG = ...

def sha256hex(obj):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def sha1hex(obj):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
default_hasher = ...

def combine_hashes_lists(items, prefix):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class BoolObj:
    TRUE = ...
    FALSE = ...

def prepare_string_for_hashing(obj, ignore_string_type_changes=..., ignore_string_case=..., encodings=..., ignore_encoding_errors=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
doc = ...

class DeepHash:
    __doc__ = ...

    def __init__(self, obj: Any, *, apply_hash=..., custom_operators: Optional[List[Any]]=..., default_timezone: Union[datetime.timezone, 'BaseTzInfo']=..., encodings=..., exclude_obj_callback=..., exclude_paths=..., exclude_regex_paths=..., exclude_types=..., hasher=..., hashes=..., ignore_encoding_errors=..., ignore_iterable_order=..., ignore_numeric_type_changes=..., ignore_private_variables=..., ignore_repetition=..., ignore_string_case=..., ignore_string_type_changes=..., ignore_type_in_groups=..., ignore_type_subclasses=..., include_paths=..., number_format_notation=..., number_to_string_func=..., parent=..., significant_digits=..., truncate_datetime=..., use_enum_value=..., **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    sha256hex = ...
    sha1hex = ...

    def __getitem__(self, obj, extract_index=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _getitem(hashes, obj, extract_index=..., use_enum_value=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __contains__(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get(self, key, default=..., extract_index=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_key(hashes, key, default=..., extract_index=..., use_enum_value=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_objects_to_hashes_dict(self, extract_index=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __eq__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __req__ = ...

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __bool__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def keys(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def values(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def items(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _prep_obj(self, obj, parent, parents_ids=..., is_namedtuple=..., is_pydantic_object=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _skip_this(self, obj, parent):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _prep_dict(self, obj, parent, parents_ids=..., print_as_attribute=..., original_type=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _prep_iterable(self, obj, parent, parents_ids=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _prep_bool(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _prep_path(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _prep_number(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _prep_ipranges(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _prep_datetime(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _prep_date(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _prep_tuple(self, obj, parent, parents_ids):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _hash(self, obj, parent, parents_ids=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
