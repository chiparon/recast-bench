# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
logger = ...
GETATTR = ...
GET = ...

class PathExtractionError:
    pass

class RootCanNotBeModified:
    pass

def _add_to_elements(elements, elem, inside):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
DEFAULT_FIRST_ELEMENT = ...

def _path_to_elements(path, root_element=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_nested_obj(obj, elements, next_element=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _guess_type(elements, elem, index, next_element):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_nested_obj_and_force(obj, elements, next_element=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def extract(obj, path):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def parse_path(path, root_element=..., include_actions=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def stringify_element(param, quote_str=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def stringify_path(path, root_element=..., quote_str=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
