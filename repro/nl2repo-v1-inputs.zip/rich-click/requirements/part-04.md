#### 10. CmdType - Command Type Variable

**Function**: Type variable bound to Command types.

**Definition**:

```python
CmdType = TypeVar('CmdType', bound=Command)
```

#### 11. RichMultiCommand - Multi-Command Type Alias

**Function**: Type alias for RichGroup to maintain MultiCommand compatibility.

**Definition**:

```python
RichMultiCommand = RichGroup
```

#### 12. __version__ - Version String

**Function**: Module version string.

**Definition**:

```python
__version__ = '1.9.3'
```

#### 13. ShellCompleteArg - Shell Completion Type

**Function**: Type alias for shell completion callback functions.

**Definition**:

```python
'''filepath: src/rich_click/decorators.pyi'''

ShellCompleteArg = Callable[[click.Context, P, str], Union[List[CompletionItem], List[str]]]
```

#### 14. ParamDefault - Parameter Default Type

**Function**: Type alias for parameter default values.

**Definition**:

```python
'''filepath: src/rich_click/decorators.pyi'''

ParamDefault = Union[Any, Callable[[], Any]]
```

#### 15. ParamCallback - Parameter Callback Type

**Function**: Type alias for parameter callback functions.

**Definition**:

```python
'''filepath: src/rich_click/decorators.pyi'''

ParamCallback = Callable[[click.Context, P, Any], Any]
```

#### 16. PSpec - Parameter Specification

**Function**: ParamSpec for parameter specification.

**Definition**:

```python
PSpec = ParamSpec('PSpec')
```

#### 17. ColT - Column Type Variable

**Function**: Type variable for column types in panels.

**Definition**:

```python
from rich_click.rich_panel import ColumnType

ColT = TypeVar('ColT', bound=ColumnType)
```

#### 18. GroupType - Group Dictionary Type Variable

**Function**: Type variable for group dictionary types.

**Definition**:

```python
from rich_click.rich_panel import ColumnType
GroupType = TypeVar('GroupType', OptionGroupDict, CommandGroupDict)
```

#### 19. P - Parameter Type Variable

**Function**: Type variable for parameters in decorator functions.

**Definition**:

```python
P = TypeVar('P', bound=Parameter)
```

#### 20. F - Function Type Variable

**Function**: Type variable for function types.

**Definition**:

```python
F = TypeVar('F', bound=Callable[..., Any])
```

#### 21. FC - Function/Command Type Variable

**Function**: Type variable for function or command types.

**Definition**:

```python
FC = TypeVar('FC', bound=Union[Command, _AnyCallable])
```

#### 22. G - Group Type Variable

**Function**: Type variable for group types.

**Definition**:

```python
G = TypeVar('G', bound=Group)
```

#### 23. C - Command Type Variable

**Function**: Type variable for command types.

**Definition**:

```python
C = TypeVar('C', bound=Command)
```

#### 24. R - Rich Type Variable  

**Function**: Type variable for Rich-related types.

**Definition**:

```python
R = TypeVar('R')
```

#### 25. T - Generic Type Variable

**Function**: Generic type variable for configuration.

**Definition**:

```python
T = TypeVar('T')
```

#### 26. CT - Container Type Variable

**Function**: Type variable for container types in panels.

**Definition**:

```python
CT = TypeVar('CT', Command, Parameter)
```

#### 27. RP - Rich Panel Type Variable

**Function**: Type variable for Rich panel types.

**Definition**:

```python
RP = TypeVar('RP', bound=RichPanel[Any, Any])
```

#### 28. __TyperGroup - Typer Group Type Alias

**Function**: Internal type alias for Typer group classes.

**Definition**:

```python
__TyperGroup = None  # Set dynamically during Typer patching
```

#### 29. __TyperCommand - Typer Command Type Alias

**Function**: Internal type alias for Typer command classes.

**Definition**:

```python
__TyperCommand = None  # Set dynamically during Typer patching
```

#### 30. __TyperArgument - Typer Argument Type Alias

**Function**: Internal type alias for Typer argument classes.

**Definition**:

```python
__TyperArgument = None  # Set dynamically during Typer patching
```

#### 31. __TyperOption - Typer Option Type Alias

**Function**: Internal type alias for Typer option classes.

**Definition**:

```python
__TyperOption = None  # Set dynamically during Typer patching
```

#### 32. __all__ - Module Exports List

**Function**: List of public module exports for each module.

**Definitions**:

```python
from rich_click.decorators import __all__
# In decorators module
__all__ = [
    'command', 'group', 'argument', 'option', 'password_option',
    'confirmation_option', 'version_option', 'help_option', 
    'rich_config', 'option_panel', 'command_panel', 'pass_context'
]

from rich_click.patch import __all__    
# In patch module  
__all__ = ['patch', 'patch_typer']

from rich_click.rich_group import __all__
# In rich_group module
__all__ = ['RichGroup']
```

### Advanced Configuration Options

#### 1. Option Grouping Configuration

```python
import rich_click as click

click.rich_click.OPTION_GROUPS = {
    "mycommand": [
        {
            "name": "Basic Options",
            "options": ["--verbose", "--output"]
        },
        {
            "name": "Advanced Options", 
            "options": ["--config", "--debug"]
        }
    ]
}
```

#### 2. Command Grouping Configuration

```python
click.rich_click.COMMAND_GROUPS = {
    "mygroup": [
        {
            "name": "Core Commands",
            "commands": ["start", "stop"]
        },
        {
            "name": "Utility Commands",
            "commands": ["config", "version"]
        }
    ]
}
```

#### 3. Global Style Configuration

```python
import rich_click.rich_click as rc

# Basic style configuration
rc.STYLE_OPTION = "bold cyan"
rc.STYLE_OPTION_NEGATIVE = "red"
rc.STYLE_ARGUMENT = "bold yellow"
rc.STYLE_COMMAND = "bold green"
rc.STYLE_COMMAND_ALIASES = "dim"
rc.STYLE_SWITCH = "green"
rc.STYLE_SWITCH_NEGATVE = "red"
rc.STYLE_METAVAR = "dim"
rc.STYLE_METAVAR_APPEND = "dim"
rc.STYLE_METAVAR_SEPARATOR = "dim"
rc.STYLE_RANGE_APPEND = "dim"

# Usage and help text styles
rc.STYLE_USAGE = "bold"
rc.STYLE_USAGE_COMMAND = "bold"
rc.STYLE_USAGE_SEPARATOR = "dim"
rc.STYLE_DEPRECATED = "strike"
rc.STYLE_HELPTEXT_FIRST_LINE = "bold"
rc.STYLE_HELPTEXT = ""
rc.STYLE_HELPTEXT_ALIASES = None
rc.STYLE_OPTION_HELP = ""
rc.STYLE_COMMAND_HELP = ""
rc.STYLE_OPTION_DEFAULT = "dim"
rc.STYLE_OPTION_ENVVAR = "dim"
rc.STYLE_REQUIRED_SHORT = "red"
rc.STYLE_REQUIRED_LONG = "red"

# Panel styles
rc.STYLE_OPTIONS_PANEL_BORDER = "blue"
rc.STYLE_OPTIONS_PANEL_BOX = "ROUNDED"
rc.STYLE_OPTIONS_PANEL_HELP_STYLE = ""
rc.STYLE_OPTIONS_PANEL_TITLE_STYLE = "bold"
rc.STYLE_OPTIONS_PANEL_PADDING = (1, 2)
rc.STYLE_OPTIONS_PANEL_STYLE = ""
rc.ALIGN_OPTIONS_PANEL = "left"

rc.STYLE_COMMANDS_PANEL_BORDER = "blue"
rc.STYLE_COMMANDS_PANEL_BOX = "ROUNDED"
rc.STYLE_COMMANDS_PANEL_HELP_STYLE = ""
rc.STYLE_COMMANDS_PANEL_TITLE_STYLE = "bold"
rc.STYLE_COMMANDS_PANEL_PADDING = (1, 2)
rc.STYLE_COMMANDS_PANEL_STYLE = ""
rc.ALIGN_COMMANDS_PANEL = "left"

# Table styles
rc.STYLE_OPTIONS_TABLE_SHOW_LINES = True
rc.STYLE_OPTIONS_TABLE_LEADING = 1
rc.STYLE_OPTIONS_TABLE_PAD_EDGE = False
rc.STYLE_OPTIONS_TABLE_PADDING = (0, 1)
rc.STYLE_OPTIONS_TABLE_EXPAND = True
rc.STYLE_OPTIONS_TABLE_BOX = "SIMPLE"
rc.STYLE_OPTIONS_TABLE_ROW_STYLES = ["", "dim"]
rc.STYLE_OPTIONS_TABLE_BORDER_STYLE = "blue"

rc.STYLE_COMMANDS_TABLE_SHOW_LINES = True
rc.STYLE_COMMANDS_TABLE_LEADING = 1
rc.STYLE_COMMANDS_TABLE_PAD_EDGE = False
rc.STYLE_COMMANDS_TABLE_PADDING = (0, 1)
rc.STYLE_COMMANDS_TABLE_EXPAND = True
rc.STYLE_COMMANDS_TABLE_BOX = "SIMPLE"
rc.STYLE_COMMANDS_TABLE_ROW_STYLES = ["", "dim"]
rc.STYLE_COMMANDS_TABLE_BORDER_STYLE = "blue"
rc.STYLE_COMMANDS_TABLE_COLUMN_WIDTH_RATIO = (1, 2)

# Error styles
rc.STYLE_ERRORS_PANEL_BORDER = "red"
rc.STYLE_ERRORS_PANEL_BOX = "ROUNDED"
rc.ALIGN_ERRORS_PANEL = "left"
rc.STYLE_ERRORS_SUGGESTION = "dim"
rc.STYLE_ERRORS_SUGGESTION_COMMAND = "bold"
rc.STYLE_PADDING_ERRORS = ""
rc.STYLE_ABORTED = "red"

# Padding styles
rc.STYLE_PADDING_USAGE = ""
rc.STYLE_PADDING_HELPTEXT = ""
rc.STYLE_PADDING_EPILOG = ""
rc.STYLE_HEADER_TEXT = ""
rc.STYLE_EPILOG_TEXT = ""
rc.STYLE_FOOTER_TEXT = ""

# Terminal configuration
rc.WIDTH = 120
rc.MAX_WIDTH = 120
rc.COLOR_SYSTEM = "auto"
rc.FORCE_TERMINAL = None

# String templates
rc.PANEL_TITLE_STRING = "{title}"
rc.DEPRECATED_STRING = "(Deprecated)"
rc.DEPRECATED_WITH_REASON_STRING = "(Deprecated: {reason})"
rc.DEFAULT_STRING = "[default: {default}]"
rc.ENVVAR_STRING = "[env var: {var}]"
rc.REQUIRED_SHORT_STRING = "*"
rc.REQUIRED_LONG_STRING = "[required]"
rc.RANGE_STRING = "[{range}]"
rc.HELPTEXT_ALIASES_STRING = "Aliases: {}"
rc.APPEND_METAVARS_HELP_STRING = " {metavar}"
rc.APPEND_RANGE_HELP_STRING = " {range}"

# Panel titles
rc.ARGUMENTS_PANEL_TITLE = "Arguments"
rc.OPTIONS_PANEL_TITLE = "Options"
rc.COMMANDS_PANEL_TITLE = "Commands"
rc.ERRORS_PANEL_TITLE = "Error"

# Delimiters
rc.DELIMITER_COMMA = ", "
rc.DELIMITER_SLASH = "/"

# Error messages
rc.ERRORS_SUGGESTION = "Try 'command --help' for help."
rc.ERRORS_EPILOGUE = ""
rc.ABORTED_TEXT = "Aborted."

# Padding dimensions
rc.PADDING_HEADER_TEXT = (0, 0, 1, 0)
rc.PADDING_USAGE = (0, 0, 1, 0)
rc.PADDING_HELPTEXT = (0, 0, 1, 0)
rc.PADDING_HELPTEXT_DEPRECATED = 0
rc.PADDING_HELPTEXT_FIRST_LINE = 0
rc.PADDING_EPILOG = (1, 0, 0, 0)
rc.PADDING_FOOTER_TEXT = (1, 0, 0, 0)
rc.PADDING_ERRORS_PANEL = (0, 0, 1, 0)
rc.PADDING_ERRORS_SUGGESTION = (0, 1, 0, 1)
rc.PADDING_ERRORS_EPILOGUE = (0, 1, 1, 1)

# Behavior configuration
rc.SHOW_ARGUMENTS = True
rc.SHOW_METAVARS_COLUMN = True
rc.COMMANDS_BEFORE_OPTIONS = False
rc.APPEND_METAVARS_HELP = True
rc.GROUP_ARGUMENTS_OPTIONS = True
rc.OPTION_ENVVAR_FIRST = False
rc.TEXT_MARKUP = "rich"
rc.TEXT_EMOJIS = True
rc.TEXT_PARAGRAPH_LINEBREAKS = "\n\n"
rc.USE_MARKDOWN = False
rc.USE_MARKDOWN_EMOJI = False
rc.HELPTEXT_SHOW_ALIASES = True
rc.USE_RICH_MARKUP = True
rc.USE_CLICK_SHORT_HELP = False

# Panel configuration
rc.PANEL_INLINE_HELP_IN_TITLE = False
rc.PANEL_INLINE_HELP_DELIMITER = " - "
rc.PANEL_TITLE_PADDING = 1

# Column and section types
rc.OPTIONS_TABLE_COLUMN_TYPES = ["opt_all", "help"]
rc.COMMANDS_TABLE_COLUMN_TYPES = ["name", "help"]
rc.OPTIONS_TABLE_HELP_SECTIONS = ["help", "required", "default", "envvar"]
rc.COMMANDS_TABLE_HELP_SECTIONS = ["help"]

# Theme configuration
rc.THEME = None
rc.ENABLE_THEME_ENV_VAR = True

# Additional text configuration
rc.TEXT_KWARGS = None  # Additional kwargs for Rich text rendering

# Internal configuration
rc.OVERRIDES_GUARD = False  # Controls method override behavior
rc._THEME_FROM_CLI = None  # Theme set from CLI

# Box constants for custom styling
rc.HORIZONTALS_TOP = Box("Top horizontal lines box style")
rc.HORIZONTALS_DOUBLE_TOP = Box("Double top horizontal lines box style")  
rc.BLANK = Box("Blank box style with no borders")

# Theme dictionaries
rc.COLORS = {}  # Dictionary of color themes
rc.FORMATS = {}  # Dictionary of format themes
rc._THEME_CACHE = {}  # Internal theme cache

# CLI and warning constants
rc.DISABLE_WARNINGS_NOTE = "Warning disable message for CLI"
rc.RP = None  # Rich parameter type variable
```

#### 4. Output Format Configuration

```python
# Export as HTML
with RichContext(export_console_as="html") as ctx:
    help_text = ctx.get_help()

# Export as SVG
with RichContext(export_console_as="svg") as ctx:
    help_text = ctx.get_help()
```

### Rendering Engine Interface

#### 1. rich_format_help() - Help Formatting

```python
def rich_format_help(
    obj: Union[Command, Group],
    ctx: click.Context,
    formatter: RichHelpFormatter
) -> None
```

#### 2. rich_format_error() - Error Formatting

```python
def rich_format_error(
    self: click.ClickException,
    formatter: RichHelpFormatter
) -> None
```

#### 3. patch() Function - Click Patching

**Function**: Monkey-patch Click to use Rich-Click by default.

**Function Signature**:

```python
@wraps(_patch)
def patch(*args: Any, **kwargs: Any) -> None:  # noqa: D103
    import warnings
```
**Description**:
- `@wraps(_patch)`: Preserves the original function metadata.
- `def patch`: Accepts any arguments and keyword arguments.
    - `#args`: Positional arguments passed to the original `_patch` function.
    - `**kwargs`: Keyword arguments passed to the original `_patch` function.
**Return Value**: _patch

#### 4. patch_typer() Function - Typer Integration

**Function**: Enable Rich-Click support for Typer applications.

**Function Signature**:

```python
def patch_typer(rich_config: Optional[RichHelpConfiguration] = None) -> None:
    class _PatchedTyperCommand(_PatchedRichCommand, typer.core.TyperCommand):
        pass
    class _PatchedTyperGroup(_PatchedRichGroup, typer.core.TyperGroup):  # type: ignore[misc]
            pass
    class _PatchedTyperOption(_PatchedOption, typer.core.TyperOption):
            pass
    class _PatchedTyperArgument(_PatchedArgument, typer.core.TyperArgument):
            pass       
```
**Description**:
- `rich_config` (Optional[RichHelpConfiguration]): Configuration for Rich-Click help formatting. Defaults to None.


#### 5. option_panel() Decorator - Option Panel Definition

**Function**: Define custom panels for grouping options.

**Function Signature**:

```python
def option_panel(
    name: str,
    cls: Type[RichPanel[Parameter, Any]] = RichOptionPanel,
    **attrs: Any,
) -> Callable[[FC], FC]:
    """
    Use decorator to create a RichOptionPanel.

    Args:
    ----
        name: Name of the RichOptionPanel instance being created.
        cls: The class of the RichPanel; defaults to RichOptionPanel.
        attrs: Additional attributes to pass to the RichOptionPanel.

    """
```

**Parameter Description**:

- `name` (str): Name of the RichOptionPanel instance being created.
- `cls` (Type[RichPanel[Parameter, Any]]): The class of the RichPanel; defaults to RichOptionPanel.
- `**attrs` (Any): Additional attributes to pass to the RichOptionPanel.

**Return Value**: A decorator function that creates a custom panel for grouping options. The decorator returns the original function with the panel configuration applied.


#### 6. command_panel() Decorator - Command Panel Definition

**Function**: Define custom panels for grouping commands.

**Function Signature**:

```python
def command_panel(
    name: str,
    cls: Type[RichPanel[Command, Any]] = RichCommandPanel,
    **attrs: Any
) -> Callable[[FC], FC]
```

**Parameter Description**:

- `name` (str): Name of the RichCommandPanel instance being created.
- `cls` (Type[RichPanel[Command, Any]]): The class of the RichPanel; defaults to RichCommandPanel.
- `**attrs` (Any): Additional attributes to pass to the RichCommandPanel.

**Return Value**: A decorator function that creates a custom panel for grouping commands. The decorator returns the original function with the panel configuration applied.

#### 7. argument() Function - Rich Argument Decorator

**Function**: Create Rich-styled Click arguments.

**Function Signature**:

```python
from rich_click.decorators import argument
def argument(
    *param_decls: str,
    cls: Optional[Type[Argument]] = None,
    **attrs: Any
) -> Callable[[FC], FC]:
    """
    Attaches an argument to the command.  All positional arguments are
    passed as parameter declarations to :class:`Argument`; all keyword
    arguments are forwarded unchanged (except ``cls``).
    This is equivalent to creating an :class:`Argument` instance manually
    and attaching it to the :attr:`Command.params` list.

    For the default argument class, refer to :class:`Argument` and
    :class:`Parameter` for descriptions of parameters.

    :param cls: the argument class to instantiate.  This defaults to
                :class:`Argument`.
    :param param_decls: Passed as positional arguments to the constructor of
        ``cls``.
    :param attrs: Passed as keyword arguments to the constructor of ``cls``.
    """

```

**Parameter Description**:

- `*param_decls` (str): Variable number of parameter declaration strings that define the argument names and types. These are passed as positional arguments to the Argument constructor.
- `cls` (Optional[Type[Argument]]): The argument class to instantiate. This defaults to `RichArgument`. If None, uses `RichArgument` as the default class.
- `**attrs` (Any): Additional keyword arguments passed to the Argument constructor, including help text, type constraints, and other Click parameter attributes.

**Return Value**: A decorator function that attaches a Rich-styled argument to the command. The decorator returns the original function with the argument parameter added to its parameter list.


#### 8. option() Function - Rich Option Decorator

**Function**: Create Rich-styled Click options.

**Function Signature**:

```python
from rich_click.decorators import option
def option(
    *param_decls: str,
    cls: Optional[Type[Option]] = None,
    **attrs: Any
) -> Callable[[FC], FC]:
    """
    Attaches an option to the command.  All positional arguments are
    passed as parameter declarations to :class:`Option`; all keyword
    arguments are forwarded unchanged (except ``cls``).
    This is equivalent to creating an :class:`Option` instance manually
    and attaching it to the :attr:`Command.params` list.

    For the default option class, refer to :class:`Option` and
    :class:`Parameter` for descriptions of parameters.

    :param cls: the option class to instantiate.  This defaults to
                :class:`Option`.
    :param param_decls: Passed as positional arguments to the constructor of
        ``cls``.
    :param attrs: Passed as keyword arguments to the constructor of ``cls``.
    """
```

**Parameter Description**:

- `*param_decls` (str): Variable number of parameter declaration strings that define the option names (e.g., '--verbose', '-v'). These are passed as positional arguments to the Option constructor.
- `cls` (Optional[Type[Option]]): The option class to instantiate. This defaults to `RichOption`. If None, uses `RichOption` as the default class.
- `**attrs` (Any): Additional keyword arguments passed to the Option constructor, including help text, type constraints, default values, and other Click parameter attributes.

**Return Value**: A decorator function that attaches a Rich-styled option to the command. The decorator returns the original function with the option parameter added to its parameter list.


#### 9. password_option() Function - Password Option Decorator

**Function**: Create password input options with Rich styling.

**Function Signature**:

```python
from rich_click.decorators import password_option

def password_option(*param_decls: str, **kwargs: Any) -> Callable[[FC], FC]:
    """
    Add a ``--password`` option which prompts for a password, hiding
    input and asking to enter the value again for confirmation.

    :param param_decls: One or more option names. Defaults to the single
        value ``"--password"``.
    :param kwargs: Extra arguments are passed to :func:`option`.
    """
```

**Parameter Description**:

- `*param_decls` (str): Variable number of parameter declaration strings that define the option names (e.g., '--password', '-p'). These are passed as positional arguments to the Option constructor.
- `**kwargs` (Any): Additional keyword arguments passed to the Option constructor, including help text, confirmation prompts, and other Click parameter attributes.

**Return Value**: A decorator function that attaches a Rich-styled password option to the command. The decorator returns the original function with the password option parameter added to its parameter list.

#### 10. confirmation_option() Function - Confirmation Option Decorator

**Function**: Create confirmation prompts with Rich styling.

**Function Signature**:

```python
def confirmation_option(*param_decls: str, **kwargs: Any) -> Callable[[FC], FC]:
    """
    Add a ``--yes`` option which shows a prompt before continuing if
    not passed. If the prompt is declined, the program will exit.

    :param param_decls: One or more option names. Defaults to the single
        value ``"--yes"``.
    :param kwargs: Extra arguments are passed to :func:`option`.
    """
```

**Parameter Description**:

- `*param_decls` (str): Variable number of parameter declaration strings that define the option names (e.g., '--yes', '-y'). These are passed as positional arguments to the Option constructor.
- `**kwargs` (Any): Additional keyword arguments passed to the Option constructor, including help text, confirmation prompts, and other Click parameter attributes.

**Return Value**: A decorator function that attaches a Rich-styled confirmation option to the command. The decorator returns the original function with the confirmation option parameter added to its parameter list.


#### 11. version_option() Function - Version Option Decorator

**Function**: Create version display options with Rich styling.

**Function Signature**:

```python
def version_option(
    version: Optional[str] = None,
    *param_decls: str,
    package_name: Optional[str] = None,
    prog_name: Optional[str] = None,
    message: Optional[str] = None,
    **kwargs: Any,
) -> Callable[[FC], FC]:
    """
    Add a ``--version`` option which immediately prints the version
    number and exits the program.

    If ``version`` is not provided, Click will try to detect it using
    :func:`importlib.metadata.version` to get the version for the
    ``package_name``. On Python < 3.8, the ``importlib_metadata``
    backport must be installed.

    If ``package_name`` is not provided, Click will try to detect it by
    inspecting the stack frames. This will be used to detect the
    version, so it must match the name of the installed package.

    :param version: The version number to show. If not provided, Click
        will try to detect it.
    :param param_decls: One or more option names. Defaults to the single
        value ``"--version"``.
    :param package_name: The package name to detect the version from. If
        not provided, Click will try to detect it.
    :param prog_name: The name of the CLI to show in the message. If not
        provided, it will be detected from the command.
    :param message: The message to show. The values ``%(prog)s``,
        ``%(package)s``, and ``%(version)s`` are available. Defaults to
        ``"%(prog)s, version %(version)s"``.
    :param kwargs: Extra arguments are passed to :func:`option`.
    :raise RuntimeError: ``version`` could not be detected.
    """
```

**Parameter Description**:

- `version` (Optional[str]): The version string to display when the option is used. If None, attempts to get version from the package. Defaults to None.
- `*param_decls` (str): Variable number of parameter declaration strings that define the option names (e.g., '--version', '-v'). These are passed as 
positional arguments to the Option constructor.
- `package_name` (Optional[str]): The package name to detect the version from. If not provided, Click will try to detect it by inspecting the stack frames. Defaults to None.
- `prog_name` (Optional[str]): The name of the CLI to show in the message. If not provided, it will be detected from the command. Defaults to None.
- `message` (Optional[str]): The message to show. The values %(prog)s, %(package)s, and %(version)s are available in the message. Defaults to None.
- `**kwargs` (Any): Additional keyword arguments passed to the Option constructor, including help text and other Click parameter attributes.

**Return Value**: A decorator function that attaches a Rich-styled version option to the command. The decorator returns the original function with the version option parameter added to its parameter list.

#### 12. get_theme() Function - Theme Retrieval

**Function**: Get a Rich-Click theme by name.

**Function Signature**:

```python
from rich_click.rich_click_theme import get_theme

def get_theme(theme: str, raise_key_error: bool = True) -> RichClickTheme:
    """Get the theme based on the string name."""
```

**Parameter Description**:

