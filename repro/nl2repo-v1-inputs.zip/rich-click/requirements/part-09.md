- `cli_runner` (CliRunner): The Click CLI test runner for executing commands.
- `cli` (click.Group): The Click group command to test.

**Return Value**: None. This function performs assertions to verify that advanced Rich markup functionality works correctly.

**Usage example**:

```python
# Test rich markup help turn off rich markup
result = cli_runner.invoke(cli, "--help")
assert "Rich Markup Text" in result.stdout
assert "[bold]" not in result.stdout  # Rich markup should be literal text
```

**Example CLI Functions**:

#### cmd1(), cmd2(), cmd3() Functions - Example Commands

**Function**: Example command functions used in tests and documentation.

**Function Signature**:

```python
def cmd1() -> None
def cmd2() -> None  
def cmd3() -> None
def cmd4() -> None
def cmd5() -> None
def cmd6() -> None
def cmd7() -> None
def cmd8() -> None
def cmd9() -> None
def cmd10() -> None
def cmd11() -> None
def cmd12() -> None
def cmd13() -> None
```

#### test_simple_help_no_such_command() Function - No Such Command Test

**Function**: Tests error handling when requesting help for non-existent commands.

**Function Signature**:

```python
def test_simple_help_no_such_command(cli_runner: CliRunner, cli: click.Group) -> None
```

**Parameter Description**:

- `cli_runner` (CliRunner): The Click CLI test runner for executing commands.
- `cli` (click.Group): The Click group command to test.

**Return Value**: None. This function performs assertions to verify that error handling works correctly when requesting help for non-existent commands.

**Usage example**:

```python
# Test simple help no such command
result = cli_runner.invoke(cli, "nonexistent", "--help")
assert "No such command" in result.stdout
assert "Usage:" in result.stdout
```

#### dummy(), dummy2() Functions - Example Dummy Commands

**Function**: Example dummy command functions for testing.

**Function Signature**:

```python
def dummy() -> None
def dummy2() -> None
```

#### click_command(), click_options() Functions - Example Click Functions

**Function**: Example Click command and option functions.

**Function Signature**:

```python
def click_command() -> None
def click_options() -> None
```

#### grp1() Function - Example Group Function

**Function**: Example group function for testing.

**Function Signature**:

```python
def grp1() -> None
```

#### footer_is_rich_text(), epilog_is_rich_text() Functions - Rich Text Examples

**Function**: Example functions for Rich text in footer and epilog.

**Function Signature**:

```python
def footer_is_rich_text() -> None
def epilog_is_rich_text() -> None
```

#### check(), get_latest(), update_item(), update_user() Functions - Example Utility Commands

**Function**: Example utility command functions.

**Function Signature**:

```python
def check() -> None
def get_latest() -> None
def update_item() -> None
def update_user() -> None
```

#### greetings_cli(), english(), french() Functions - Example Localization Commands

**Function**: Example command functions for localization testing.

**Function Signature**:

```python
def greetings_cli() -> None
def english() -> None
def french() -> None
```

#### user_cli() Function - Example User CLI Command

**Function**: Example user CLI command function.

**Function Signature**:

```python
def user_cli() -> None
```

### Node 14: Performance Optimization and Caching (Performance Optimization and Caching)

**Function description**: Implements rendering performance optimization and configuration caching mechanisms to improve the response speed of large applications.

**Optimization strategies**:

- Configuration object caching: Avoid repeated creation of configuration instances.
- Rendering result caching: Reuse of the same content.
- Lazy loading: Load heavy components on demand.

**Input and output example**:

```python
import rich_click as click
from rich_click.rich_help_formatter import RichHelpFormatter
from functools import cached_property

# Configuration caching example
class CachedConfiguration:
    @cached_property
    def help_config(self):
        return click.RichHelpConfiguration(
            style_option="cyan",
            style_command="green",
            width=100
        )

# Use cached configuration
cached_config = CachedConfiguration()

@click.group()
@rich_click.rich_config(help_config=cached_config.help_config)
def cli() -> None:
    """CLI with cached configuration."""
    pass

# Multiple subcommands share the configuration
for i in range(10):
    @cli.command(f"cmd{i}")
    @rich_click.rich_config(help_config=cached_config.help_config)
    def subcmd() -> None:
        f"""Subcommand {i}."""
        pass

# Performance test
import time

def performance_test():
    start_time = time.time()
    
    # Render multiple help pages
    for i in range(100):
        runner = click.testing.CliRunner()
        result = runner.invoke(cli, ["--help"])
    
    end_time = time.time()
    print(f"Time taken to render 100 help pages: {end_time - start_time:.3f} seconds")

performance_test()
```

**Expected output**: Display performance metrics to verify the effectiveness of the caching mechanism.

### Node 15: Internationalization and Localization Support (Internationalization and Localization)

**Function description**: Supports multi-language interfaces and localization configurations, adapting to the usage habits of different regions.

**Localization components**:

- String templates: Translatable text templates.
- Number formats: Localized number displays.
- Date and time: Region-related formats.

**Input and output example**:

```python
import rich_click as click
from rich_click import RichHelpConfiguration

# Multi-language string configuration
STRINGS_CN = {
    "arguments_panel_title": "Parameters",
    "options_panel_title": "Options", 
    "commands_panel_title": "Commands",
    "required_short_string": "Required",
    "default_string": "[Default: {}]",
    "help_option_help": "Show this message and exit."
}

STRINGS_EN = {
    "arguments_panel_title": "Arguments",
    "options_panel_title": "Options",
    "commands_panel_title": "Commands", 
    "required_short_string": "required",
    "default_string": "[default: {}]",
    "help_option_help": "Show this message and exit."
}

# Create a localized configuration
def create_localized_config(language="en"):
    strings = STRINGS_CN if language == "cn" else STRINGS_EN
    
    return RichHelpConfiguration(
        arguments_panel_title=strings["arguments_panel_title"],
        options_panel_title=strings["options_panel_title"],
        commands_panel_title=strings["commands_panel_title"],
        required_short_string=strings["required_short_string"],
        default_string=strings["default_string"]
    )

# Chinese interface
@click.command()
@rich_click.rich_config(help_config=create_localized_config("cn"))
@click.option("--input-file", required=True, help="Input file path")
@click.option("--output-format", default="json", help="Output format")
def process_command_cn(input_file: str, output_format: str) -> None:
    """Command to process files."""
    pass

# English interface
@click.command()
@rich_click.rich_config(help_config=create_localized_config("en"))
@click.option("--input-file", required=True, help="Input file path")
@click.option("--output-format", default="json", help="Output format")
def process_command_en(input_file: str, output_format: str) -> None:
    """Command to process files."""
    pass

# Test localization
cn_help = process_command_cn(["--help"])
en_help = process_command_en(["--help"])
```

**Expected output**: Display the corresponding localized interface text and labels according to the configured language.

### Node 16: Plugin and Extension System (Plugin and Extension System)

**Function description**: Provides a plugin mechanism and extension points, allowing third-party developers to extend the functions of Rich-Click.

**Extension interfaces**:

- Custom renderers: Inherit RichHelpFormatter.
- Style providers: Custom style themes.
- Configuration processors: Configuration loading and verification.

**Input and output example**:

```python
import rich_click as click
from rich_click.rich_help_formatter import RichHelpFormatter
from rich.panel import Panel
from rich.text import Text

# Custom renderer plugin
class CustomHelpFormatter(RichHelpFormatter):
    def write_usage(self, prog: str, args: str = "", prefix: str = None) -> None:
        """Custom usage instructions rendering."""
        if prefix is None:
            prefix = "Usage:"
        
        usage_text = Text()
        usage_text.append(prefix, style="bold yellow")
        usage_text.append(f" {prog} {args}", style="bold")
        
        panel = Panel(
            usage_text,
            border_style="yellow",
            title="Command Usage",
            title_align="left"
        )
        self.console.print(panel)

# Custom theme provider
class DarkTheme:
    @staticmethod
    def get_config():
        return {
            "style_option": "bright_cyan",
            "style_command": "bright_green", 
            "style_argument": "bright_yellow",
            "style_options_panel_border": "white",
            "style_commands_panel_border": "white",
            "color_system": "256"
        }

# Register a custom formatter
@click.command()
def test_custom_formatter() -> None:
    """Test the custom formatter."""
    pass

# Manually set the custom formatter
from rich_click import RichContext

with RichContext() as ctx:
    ctx.formatter_class = CustomHelpFormatter
    help_text = test_custom_formatter.get_help(ctx)
    print(help_text)

# Use the theme
@click.command()
@rich_click.rich_config(help_config=DarkTheme.get_config())
@click.option("--verbose", help="Verbose output")
def themed_command(verbose: bool) -> None:
    """Command using the dark theme."""
    pass

result = themed_command(["--help"])
```

**Expected output**: Display the beautified help output using the custom renderer and theme, demonstrating the flexibility of the extension system.

### Node 17: Advanced Table and Layout Control (Advanced Table and Layout Control)

**Function description**: Provides fine-grained table layout control and column width ratio adjustment functions, optimizing the help display effect of complex commands.

**Layout control**:

- Table column width ratio: `STYLE_COMMANDS_TABLE_COLUMN_WIDTH_RATIO`.
- Table padding and margins: `STYLE_OPTIONS_TABLE_PADDING`.
- Row style rotation: `STYLE_OPTIONS_TABLE_ROW_STYLES`.

**Input and output example**:

```python
import rich_click as click
import rich_click.rich_click as rc

# Configure advanced table styles
rc.STYLE_COMMANDS_TABLE_COLUMN_WIDTH_RATIO = (1, 2)  # Command name:Description = 1:2
rc.STYLE_OPTIONS_TABLE_PADDING = (0, 2)  # Padding: 0 top and bottom, 2 left and right
rc.STYLE_OPTIONS_TABLE_ROW_STYLES = ["bold", "dim"]  # Alternating row styles
rc.STYLE_OPTIONS_TABLE_SHOW_LINES = True
rc.STYLE_COMMANDS_TABLE_PAD_EDGE = True

@click.group()
def cli() -> None:
    """Advanced layout demonstration."""
    pass

@cli.command()
@click.option("--input-file", "-i", help="Input file path, supporting multiple formats including JSON, XML, CSV, etc.")
@click.option("--output-dir", "-o", help="Output directory path")
@click.option("--format", help="Output format")
@click.option("--verbose", "-v", help="Verbose output mode")
def process(input_file: str, output_dir: str, format: str, verbose: bool) -> None:
    """Process files and generate output, supporting multiple format conversions and batch processing functions."""
    pass

@cli.command()
@click.option("--config", help="Configuration file")
def setup(config: str) -> None:
    """Initialize and configure the system environment."""
    pass

# Test the advanced layout
result = cli(["--help"])
print(result)  # Output: Table layout with column width ratio and styles applied
```

**Expected output**: The command table is displayed with a 1:2 column width ratio, and the option table uses alternating row styles and custom padding.

### Node 18: Dynamic Configuration and Runtime Adjustment (Dynamic Configuration and Runtime Adjustment)

**Function description**: Supports dynamic modification of configurations at runtime, achieving hot updates of configurations and context-related style adjustments.

**Dynamic features**:

- Runtime configuration modification.
- Conditional style application.
- Configuration inheritance and merging.

**Input and output example**:

```python
import rich_click as click
from rich_click import RichHelpConfiguration, rich_config

# Dynamic configuration generator
def generate_config(context_type: str):
    base_config = {
        "style_option": "cyan",
        "style_command": "green"
    }
    
    if context_type == "production":
        base_config.update({
            "style_option": "red",
            "style_errors_panel_border": "bright_red",
            "errors_suggestion": "Contact the administrator for help"
        })
    elif context_type == "development":
        base_config.update({
            "style_option": "yellow",
            "show_arguments": True,
            "append_metavars_help": True
        })
    
    return RichHelpConfiguration(**base_config)

# Conditional configuration application
import os
environment = os.getenv("APP_ENV", "development")

@click.group()
@rich_config(help_config=generate_config(environment))
def app() -> None:
    f"""Application - {environment} environment"""
    pass

@app.command()
@click.option("--data-file", required=True, help="Data file path")
def deploy(data_file: str) -> None:
    """Deploy the application."""
    pass

# Runtime configuration modification
def modify_runtime_config():
    # Get the current configuration
    current_config = RichHelpConfiguration.load_from_globals()
    
    # Dynamic modification
    if click.get_current_context().resilient_parsing:
        current_config.width = 80
    else:
        current_config.width = 120
    
    return current_config

@click.command()
def runtime_command() -> None:
    """Example of runtime configuration adjustment."""
    config = modify_runtime_config()
    # Apply the configuration...

# Test dynamic configuration
os.environ["APP_ENV"] = "production"
prod_result = app(["--help"])
print("Production environment configuration:", prod_result)

os.environ["APP_ENV"] = "development"  
dev_result = app(["--help"])
print("Development environment configuration:", dev_result)
```

**Expected output**: Display different style configurations according to the environment variable. The production environment uses a red warning style, and the development environment displays more debugging information.

### Node 19: Complex Parameter Types and Validation (Complex Parameter Types and Validation)

**Function description**: Handles the display and validation of complex parameter types, including custom types, range limitations, and formatted displays.

**Parameter type support**:

- Numerical ranges: `IntRange`, `FloatRange`.
- File paths: Detailed display of the `Path` type.
- Custom types: User-defined parameter types.

**Input and output example**:

```python
import rich_click as click
from typing import List

# Custom parameter type
class EmailType(click.ParamType):
    name = "email"
    
    def convert(self, value, param, ctx):
        if "@" not in value:
            self.fail(f"{value} is not a valid email address", param, ctx)
        return value

# Complex parameter configuration
@click.command()
@click.option("--threads", 
              type=click.IntRange(1, 32), 
              default=4,
              help="Number of worker threads, range 1 - 32")
@click.option("--timeout",
              type=click.FloatRange(0.1, 60.0),
              default=5.0, 
              help="Timeout in seconds, range 0.1 - 60.0")
@click.option("--input-file",
              type=click.Path(exists=True, readable=True),
              help="Input file path (must exist and be readable)")
@click.option("--output-dir", 
              type=click.Path(file_okay=False, writable=True),
              help="Output directory path (must be writable)")
@click.option("--email",
              type=EmailType(),
              help="Notification email address")
@click.option("--formats",
              type=click.Choice(["json", "xml", "csv"], case_sensitive=False),
              multiple=True,
              help="Supported output formats (multiple selection allowed)")
def complex_command(threads: int, timeout: float, input_file: str, 
                   output_dir: str, email: str, formats: List[str]) -> None:
    """
    Demonstration command for complex parameter types.
    
    This command demonstrates the validation and display functions of various parameter types,
    including numerical ranges, file paths, custom types, etc.
    """
    pass

# Test the display of complex parameters
result = complex_command(["--help"])
print(result)

# Parameter validation test
try:
    # Test invalid parameters
    runner = click.testing.CliRunner()
    result = runner.invoke(complex_command, [
        "--threads", "50",  # Out of range
        "--email", "invalid-email",  # Invalid email
        "--input-file", "nonexistent.txt"  # Nonexistent file
    ])
    print("Validation error:", result.output)
except Exception as e:
    print("Parameter validation exception:", e)
```

**Expected output**: The help text displays detailed parameter type information, value ranges, and validation rules, and error messages are beautified.

### Node 20: Multi-level Commands and Subcommand Nesting (Multi-level Commands and Subcommand Nesting)

**Function description**: Supports complex multi-level command structures and deeply nested subcommand organizations, providing clear hierarchical navigation.

**Nesting features**:

- Deep nesting: Supports command nesting at any depth.
- Path display: Full command path display.
- Inherited configuration: Subcommands inherit the configuration of the parent command.

**Input and output example**:

```python
import rich_click as click

# Configure multi-level command grouping
click.rich_click.COMMAND_GROUPS = {
    "app": [
        {
            "name": "Core Functions",
            "commands": ["database", "server", "worker"]
        },
        {
            "name": "Management Tools", 
            "commands": ["admin", "monitor"]
        }
    ],
    "app database": [
        {
            "name": "Database Operations",
            "commands": ["migrate", "backup", "restore"]
        },
        {
            "name": "Maintenance Tools",
            "commands": ["vacuum", "analyze"]
        }
    ]
}

# Main application group
@click.group()
@click.option("--config", help="Configuration file path")
def app(config: str) -> None:
    """Main entry point for the multi-level application"""
    pass

# Database management group
@app.group()
@click.option("--connection", help="Database connection string")
def database(connection: str) -> None:
    """Database management functions"""
    pass

# Database subcommands
@database.command()
@click.option("--target-version", help="Target version number")
def migrate(target_version: str) -> None:
    """Perform database migration"""
    pass

@database.command()
@click.option("--output-file", help="Backup file path")
def backup(output_file: str) -> None:
    """Create a database backup"""
    pass

# Server management group
@app.group()
@click.option("--port", type=int, default=8000, help="Server port")
def server(port: int) -> None:
    """Server management functions"""
    pass

@server.command()
@click.option("--workers", type=int, default=4, help="Number of worker processes")
def start(workers: int) -> None:
    """Start the server"""
    pass

@server.command()
def stop() -> None:
    """Stop the server"""
    pass

# Management tool group
@app.group()
def admin() -> None:
    """Management tools"""
    pass

@admin.command()
@click.option("--user-id", type=int, help="User ID")
def create_user(user_id: int) -> None:
    """Create a user account"""
    pass

# Test the multi-level command structure
def test_multilevel():
    runner = click.testing.CliRunner()
    
    # Test the main help
    main_help = runner.invoke(app, ["--help"])
    print("Main command help:")
    print(main_help.output)
    
    # Test the database group help
    db_help = runner.invoke(app, ["database", "--help"])
    print("\nDatabase group help:")
    print(db_help.output)
    
    # Test the help of a specific command
    migrate_help = runner.invoke(app, ["database", "migrate", "--help"])
    print("\nMigration command help:")
    print(migrate_help.output)

test_multilevel()
```

**Expected output**: All levels of commands are clearly grouped and displayed, subcommands inherit the style configuration of the parent command, and the command path is fully displayed.

### Node 21: Performance Monitoring and Statistics (Performance Monitoring and Statistics)

**Function description**: Provides rendering performance monitoring and statistical functions, helping to optimize the user experience of large applications.

**Monitoring indicators**:

- Rendering time: Time taken to generate help text.
- Memory usage: Memory occupied by configuration objects.
- Cache hit rate: Efficiency of configuration and style caching.

**Input and output example**:

```python
import rich_click as click
import time
import tracemalloc
from functools import wraps

# Performance monitoring decorator
def monitor_performance(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Start memory tracing
        tracemalloc.start()
        start_time = time.time()
        
        try:
            result = func(*args, **kwargs)
            return result
        finally:
            # Calculate the elapsed time
            end_time = time.time()
            elapsed = end_time - start_time
            
            # Get memory usage
            current, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            
            print(f"Performance statistics for function {func.__name__}:")
            print(f"  Execution time: {elapsed:.3f} seconds")
            print(f"  Current memory: {current / 1024 / 1024:.2f} MB")
            print(f"  Peak memory: {peak / 1024 / 1024:.2f} MB")
    
    return wrapper

# Performance test of a large command group
@click.group()
def large_app() -> None:
    """Performance test for a large application"""
    pass

# Create a large number of subcommands
for i in range(50):
    @large_app.command(f"command_{i:03d}")
    @click.option(f"--option-{i}", help=f"Option {i}")
    @click.option(f"--flag-{i}", is_flag=True, help=f"Flag {i}")
    def dynamic_command(**kwargs) -> None:
        f"""Dynamically generated command {i}"""
        pass

# Performance test function
@monitor_performance
def test_large_help_rendering():
    """Test the rendering performance of large help text"""
    runner = click.testing.CliRunner()
    result = runner.invoke(large_app, ["--help"])
    return result.output

@monitor_performance  
def test_config_creation():
    """Test the performance of configuration object creation"""
    configs = []
    for i in range(1000):
        config = click.RichHelpConfiguration(
            style_option=f"color_{i % 16}",
            width=100 + i % 20
        )
        configs.append(config)
    return configs

# Cache performance test
class ConfigCache:
    def __init__(self):
        self._cache = {}
        self.hit_count = 0
        self.miss_count = 0
    
    def get_config(self, style_key: str):
        if style_key in self._cache:
            self.hit_count += 1
            return self._cache[style_key]
        else:
            self.miss_count += 1
            config = click.RichHelpConfiguration(style_option=style_key)
            self._cache[style_key] = config
            return config
    
    def get_stats(self):
        total = self.hit_count + self.miss_count
