- `theme` (str): The name of the theme to retrieve (e.g., "forest-box", "sleek", "dark").
- `raise_key_error` (bool): Whether to raise a KeyError if the theme is not found. If False, returns a default theme. Defaults to True.

**Return Value**: A RichClickTheme object containing the theme configuration with colors, styles, and formatting settings.


#### 13. list_themes() Function - Theme Listing

**Function**: List all available themes for CLI help.

**Function Signature**:

```python
from rich_click.cli import list_themes

def list_themes(ctx: RichContext, param: click.Parameter, value: bool) -> None:
    """Print all themes."""
 
```

**Parameter Description**:

- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `param` (click.Parameter): The Click parameter object that triggered this callback.
- `value` (bool): The boolean value indicating whether the option was used.

**Return Value**: None. This function prints the available themes to the console and exits the program.


#### 14. create_console() Function - Console Creation

**Function**: Create a Rich Console configured from Rich Help Configuration.

**Function Signature**:

```python
def create_console(
    config: RichHelpConfiguration,
    file: Optional[IO[str]] = None,
    width: Optional[int] = None,
    max_width: Optional[int] = None,
) -> "Console":
    """
    Create a Rich Console configured from Rich Help Configuration.

    Args:
    ----
        config: Rich Help Configuration instance
        file: Optional IO stream to write Rich Console output
            Defaults to None.
        width: Width of the Console; overrides config.width if set.
        max_width: Max width of the Console; overrides config.max_width if set.

    """
```

#### 15. help_option() Function - Help Option Decorator

**Function**: Create help options with Rich styling.

**Function Signature**:

```python
def help_option(*param_decls: str, **kwargs: Any) -> Callable[[FC], FC]:
    """
    Pre-configured ``--help`` option which immediately prints the help page
    and exits the program.

    :param param_decls: One or more option names. Defaults to the single
        value ``"--help"``.
    :param kwargs: Extra arguments are passed to :func:`option`.
    """
    def show_help(ctx: Context, param: Parameter, value: bool) -> None:
        """Callback that print the help page on ``<stdout>`` and exits."""
```

**Parameter Description**:

- `*param_decls` (str): Variable number of parameter declaration strings that define the option names (e.g., '--help', '-h'). These are passed as positional arguments to the Option constructor.
- `**kwargs` (Any): Additional keyword arguments passed to the Option constructor, including help text and other Click parameter attributes.
- `show_help`: It is an internal function of the help_option function that is responsible for printing the help page and exiting the program.
    - `ctx` (Context): The Click context object containing command information and configuration settings.
    - `param` (Parameter): The Click parameter object that triggered this callback.
    - `value` (bool): The boolean value indicating whether the option was used.
**Return Value**: A decorator function that attaches a Rich-styled help option to the command. The decorator returns the original function with the help option parameter added to its parameter list.

#### 16. pass_context() Function - Context Passing Decorator

**Function**: Pass Rich context to command functions.

**Function Signature**:

```python
def pass_context(f: Callable[Concatenate[RichContext, P], R]) -> Callable[P, R]:
    # flake8: noqa: D400,D401
    """Marks a callback as wanting to receive the current context object as first argument."""
    
```

**Parameter Description**:

- `f` (F): The function to be decorated. This function will receive a RichContext object as its first parameter.

**Return Value**: The original function with type casting to ensure the context parameter is properly typed as RichContext.

#### 17. get_rich_usage() Function - Rich Usage Formatting

**Function**: Get Rich-formatted usage text for commands.

**Function Signature**:

```python
def get_rich_usage(formatter: RichHelpFormatter, prog: str, args: str = "", prefix: Optional[str] = None) -> None:
    """Richly render usage text."""
  
```

**Parameter Description**:

- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the usage output.
- `prog` (str): The program name to display in the usage text.
- `args` (str): Optional arguments string to append to the usage text. Defaults to empty string.
- `prefix` (Optional[str]): Optional prefix text for the usage line. If None, defaults to "Usage:".

**Return Value**: None. This function renders the usage text directly to the formatter's output stream.

#### 18. get_rich_help_text() Function - Rich Help Text Formatting

**Function**: Get Rich-formatted help text for commands.

**Function Signature**:

```python
def get_rich_help_text(self: Command, ctx: RichContext, formatter: RichHelpFormatter) -> None:
    """Write rich help text to the formatter if it exists."""
```

**Parameter Description**:

- `self` (Command): The Command instance that this method belongs to.
- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the help output.

**Return Value**: None. This method writes the help text directly to the formatter's output stream.

#### 19. get_rich_epilog() Function - Rich Epilog Formatting

**Function**: Get Rich-formatted epilog text for commands.

**Function Signature**:

```python
def get_rich_epilog(
    self: Command,
    ctx: RichContext,
    formatter: RichHelpFormatter,
) -> None:
    """Richly render a click Command's epilog if it exists."""
```

**Parameter Description**:

- `self` (Command): The Command instance that this method belongs to.
- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the epilog output.

**Return Value**: None. This method writes the epilog text directly to the formatter's output stream if it exists.

#### 20. RichClickRichPanel Class - Internal Rich Panel

**Function**: A console renderable that draws a border around its contents. This is a patched version of rich.panel.Panel that has additional features useful for rendering help text with rich-click.

**Inheritance**: Inherits from Rich's `Panel` class.
```python 
class RichClickRichPanel(Panel):
    """
    A console renderable that draws a border around its contents.

    This is a patched version of rich.panel.Panel that has additional features useful
    for rendering help text with rich-click.
    """
    def __init__(self, *args: Any, title_padding: int = 1, **kwargs: Any) -> None: ...
    @property
    def _title(self) -> Optional[Text]: ...


```
**Main methods**:

- `__init__(*args: Any, title_padding: int = 1, **kwargs: Any) -> None`: Create RichClickRichPanel instance
  - `*args`: Args that get passed to rich.panel.Panel (Any)
  - `title_padding`: Controls padding on panel title (int)
  - `**kwargs`: Kwargs that get passed to rich.panel.Panel (Any)
  - Returns: None

- `_title` (property) -> Optional[Text]: Get the panel title with formatting
  - Returns: Optional[Text] - The formatted title text with padding applied, or None if no title exists

#### 21. get_box() Function - Box Style Retrieval

**Function**: Retrieve a Rich Box by name for styling.

**Function Signature**:

```python
from rich_click.rich_box import get_box

def get_box(box: Union[str, Box]) -> Box:
    """Retrieve a Rich Box by name."""
```

**Parameter Description**:

- `box` (Union[str, Box]): The box style name (e.g., "ROUNDED", "SQUARE", "DOUBLE") or an existing Box object to return as-is.

**Return Value**: A Rich Box object that can be used for styling panels, tables, and other Rich components.

#### 22. Box Style Constants

**Function**: Predefined box styles for custom rendering.
```python
HORIZONTALS_TOP: Box = Box(
    " ── \n"
    "    \n"
    "    \n"
    "    \n"
    "    \n"
    "    \n"
    "    \n"
    "    \n"
)

HORIZONTALS_DOUBLE_TOP: Box = Box(
    " ══ \n"
    "    \n"
    "    \n"
    "    \n"
    "    \n"
    "    \n"
    "    \n"
    "    \n"
)

BLANK: Box = Box(
    "    \n"
    "    \n"
    "    \n"
    "    \n"
    "    \n"
    "    \n"
    "    \n"
    "    \n"
)

```
- `HORIZONTALS_TOP`: Box with top horizontal lines
- `HORIZONTALS_DOUBLE_TOP`: Box with double top horizontal lines  
- `BLANK`: Blank box style with no borders

#### 23. get_help_parameter() Function - Parameter Help Generation

**Function**: Build primary help text for a click option or argument with Rich formatting.

**Function Signature**:

```python
from rich_click.rich_help_rendering import get_help_parameter

def get_help_parameter(
    param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter
) -> Columns:
    """
    Build primary help text for a click option or argument.
    Returns the prose help text for an option or argument, rendered either
    as a Rich Text object or as Markdown.
    Additional elements are appended to show the default and required status if applicable.

    Args:
    ----
        param (click.Argument or click.Option): Parameter to build help text for.
        ctx (click.Context): Click Context object.
        formatter (RichHelpFormatter): formatter object.

    Returns:
    -------
        Columns: A columns element with multiple styled objects (help, default, required)

    """
```

**Parameter Description**:

- `param` (Union[click.Argument, click.Option, RichParameter]): The parameter object to generate help text for. Can be a Click argument, option, or Rich-enhanced parameter.
- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the help output.

**Return Value**: A Rich Columns object containing the formatted help text for the parameter, ready for display in the terminal.


#### 24. get_parameter_rich_table_row() Function - Parameter Table Row

**Function**: Create a table row for Rich display corresponding with a parameter.

**Function Signature**:

```python
def get_parameter_rich_table_row(
    param: Union[click.Argument, click.Option, RichParameter],
    ctx: RichContext,
    formatter: RichHelpFormatter,
    panel: Optional["RichOptionPanel"],
) -> RichPanelRow:
    """Create a row for the rich table corresponding with this parameter."""

```

**Parameter Description**:

- `param` (Union[click.Argument, click.Option, RichParameter]): The parameter object to create a table row for. Can be a Click argument, option, or Rich-enhanced parameter.
- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the table output.
- `panel` (Optional[RichOptionPanel]): Optional panel object that provides additional context for the parameter display. Defaults to None.

**Return Value**: A RichPanelRow object (List[Optional[RenderableType]]) containing the formatted table row elements for the parameter, ready for display in a Rich table.

#### 25. get_command_rich_table_row() Function - Command Table Row

**Function**: Create a table row for Rich display corresponding with a command.

**Function Signature**:

```python
def get_command_rich_table_row(
    command: click.Command,
    ctx: RichContext,
    formatter: RichHelpFormatter,
    panel: Optional["RichCommandPanel"],
) -> RichPanelRow:
    """Create a row for the rich table corresponding with this command."""
```

**Parameter Description**:

- `command` (click.Command): The Click command object to create a table row for.
- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the table output.

**Return Value**: A RichPanelRow object (List[Optional[RenderableType]]) containing the formatted table row elements for the command, ready for display in a Rich table.

#### 26. create_console() Function - Console Creation

**Function**: Create a Rich Console configured from Rich Help Configuration.

**Function Signature**:

```python
def create_console(
    config: RichHelpConfiguration,
    file: Optional[IO[str]] = None,
    width: Optional[int] = None,
    max_width: Optional[int] = None,
) -> "Console":
    """
    Create a Rich Console configured from Rich Help Configuration.

    Args:
    ----
        config: Rich Help Configuration instance
        file: Optional IO stream to write Rich Console output
            Defaults to None.
        width: Width of the Console; overrides config.width if set.
        max_width: Max width of the Console; overrides config.max_width if set.

    """
```

**Parameter Description**:

- `config` (RichHelpConfiguration): The Rich help configuration object that contains styling and layout settings for the console.
- `file` (Optional[IO[str]]): Optional file object to write output to. If None, uses stdout. Defaults to None.
- `width` (Optional[int]): Optional width for the console. If None, uses the configuration default. Defaults to None.
- `max_width` (Optional[int]): Optional maximum width for the console. If None, uses the configuration default. Defaults to None.

**Return Value**: A Rich Console object configured with the specified settings, ready for rendering Rich content.

#### 27. construct_panels() Function - Panel Construction

**Function**: Construct Rich panels for options and commands.

**Function Signature**:

```python
from rich_click.rich_panel import RichPanel
def construct_panels(
    command: "RichCommand",
    ctx: "RichContext",
    formatter: "RichHelpFormatter",
) -> List[RichPanel[Any, Any]]:
    """Construct panels from the command as well as from the old groups config."""

```

**Parameter Description**:

- `command` (RichCommand): The Rich command object to construct panels for.
- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the panels.

**Return Value**: A list of RichPanel[Any, Any] objects containing the formatted panels for options and commands, ready for display in the terminal.

#### 28. _get_help_text() Function - Help Text Extraction

**Function**: Extract and format help text from Click objects.

**Function Signature**:

```python
@group()
def _get_help_text(
    obj: Union[Command, Group], formatter: RichHelpFormatter
) -> Iterable[Union[Padding, "Markdown", Text]]:
    """
    Build primary help text for a click command or group.
    Returns the prose help text for a command or group, rendered either as a
    Rich Text object or as Markdown.
    If the command is marked as depreciated, the depreciated string will be prepended.

    Args:
    ----
        obj (click.Command or click.Group): Command or group to build help text for.
        formatter: formatter object.

    Yields:
    ------
        Text or Markdown: Multiple styled objects (depreciated, usage)

    """
```

**Parameter Description**:

- `obj` (Union[Command, Group]): The Click command or group object to extract help text from.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the help text.

**Return Value**: An iterable of Union[Padding, Markdown, Text] objects containing the formatted help text elements, ready for display in the terminal.

#### 29. _get_deprecated_text() Function - Deprecated Text Formatting

**Function**: Format deprecated status text with Rich styling.

**Function Signature**:

```python
def _get_deprecated_text(
    deprecated: Union[bool, str],
    formatter: RichHelpFormatter
) -> Text
```

**Parameter Description**:

- `deprecated` (Union[bool, str]): The deprecated status - either a boolean indicating if the item is deprecated, or a string containing the deprecation reason.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the deprecated text.

**Return Value**: A Rich Text object containing the formatted deprecated status text.

#### 30. _get_parameter_env_var() Function - Environment Variable Display

**Function**: Get formatted environment variable information for parameters.

**Function Signature**:

```python
def _get_parameter_env_var(
    param: Union[click.Argument, click.Option, RichParameter],
    ctx: RichContext,
    formatter: RichHelpFormatter
) -> Optional[Text]
```

**Parameter Description**:

- `param` (Union[click.Argument, click.Option, RichParameter]): The parameter object to get environment variable information for.
- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the environment variable text.

**Return Value**: An optional Rich Text object containing the formatted environment variable information, or None if no environment variable is configured for the parameter.

#### 31. _get_parameter_default() Function - Default Value Display

**Function**: Get formatted default value information for parameters.

**Function Signature**:

```python
def _get_parameter_default(
    param: Union[click.Argument, click.Option, RichParameter],
    ctx: RichContext,
    formatter: RichHelpFormatter
) -> Optional[Text]
```

**Parameter Description**:

- `param` (Union[click.Argument, click.Option, RichParameter]): The parameter object to get default value information for.
- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the default value text.

**Return Value**: An optional Rich Text object containing the formatted default value information, or None if no default value is configured for the parameter.

#### 32. _get_parameter_required() Function - Required Status Display

**Function**: Get formatted required status for parameters.

**Function Signature**:

```python
def _get_parameter_required(
    param: Union[click.Argument, click.Option, RichParameter],
    ctx: RichContext,
    formatter: RichHelpFormatter
) -> Optional[Text]
```

**Parameter Description**:

- `param` (Union[click.Argument, click.Option, RichParameter]): The parameter object to get required status information for.
- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the required status text.

**Return Value**: An optional Rich Text object containing the formatted required status information, or None if the parameter is not required.

#### 33. _get_parameter_metavar() Function - Metavar Display

**Function**: Get formatted metavar information for parameters.

**Function Signature**:

```python
def _get_parameter_metavar(
    param: Union[click.Argument, click.Option, RichParameter],
    ctx: RichContext,
    formatter: RichHelpFormatter,
    append: bool = True,
    show_range: bool = False
) -> Optional[Text]
```

**Parameter Description**:

- `param` (Union[click.Argument, click.Option, RichParameter]): The parameter object to get metavar information for.
- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the metavar text.
- `append` (bool): Whether to append the metavar to the parameter name. Defaults to True.
- `show_range` (bool): Whether to include range information in the metavar. Defaults to False.

**Return Value**: An optional Rich Text object containing the formatted metavar information, or None if no metavar is configured for the parameter.

#### 34. _get_command_help() Function - Command Help Extraction

**Function**: Extract and format help text from commands.

**Function Signature**:

```python
def _get_command_help(
    command: click.Command,
    ctx: RichContext,
    formatter: RichHelpFormatter
) -> Union[Text, Markdown, Columns]
```

**Parameter Description**:

- `command` (click.Command): The Click command object to extract help text from.
- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the help text.

**Return Value**: A Union of Text, Markdown, or Columns object containing the formatted help text for the command.



#### 36. _resolve_panels_from_config() Function - Panel Resolution

**Function**: Resolve Rich panels from configuration groups.

**Function Signature**:

```python
from rich_click.rich_panel import _resolve_panels_from_config
def _resolve_panels_from_config(
    ctx: RichContext,
    formatter: RichHelpFormatter,
    groups: Dict[str, List[GroupType]],
    panel_cls: Type[RichPanel[CT, ColT]]
) -> List[RichPanel[CT, ColT]]
```

**Parameter Description**:

- `ctx` (RichContext): The Rich context object containing command information and configuration settings.
- `formatter` (RichHelpFormatter): The Rich help formatter instance that controls styling and layout of the panels.
- `groups` (Dict[str, List[GroupType]]): Dictionary containing panel groups configuration.
- `panel_cls` (Type[RichPanel[CT, ColT]]): The panel class type to instantiate.

**Return Value**: A list of RichPanel objects resolved from the configuration groups.

#### 37. _context_settings_memo() Function - Context Settings Helper

**Function**: Helper function to store context settings on function objects.

**Function Signature**:

```python
from rich_click.decorators import _context_settings_memo
def _context_settings_memo(f: Callable[..., Any], extra: Dict[str, Any]) -> None:
 
```

**Parameter Description**:

- `f` (Callable[..., Any]): The function object to store context settings on.
- `extra` (Dict[str, Any]): Dictionary containing additional context settings to store.

**Return Value**: None. This function modifies the function object by adding context settings as attributes.

#### 38. _rich_panel_memo() Function - Panel Memoization Helper

**Function**: Helper function to store Rich panel information on function objects.

**Function Signature**:

```python
from rich_click.decorators import _rich_panel_memo
def _rich_panel_memo(f: Callable[..., Any], panel: RichPanel[Any, Any]) -> None
```

**Parameter Description**:

- `f` (Callable[..., Any]): The function object to store panel information on.
- `panel` (RichPanel[Any, Any]): The Rich panel object to store.

**Return Value**: None. This function modifies the function object by adding panel information as attributes.

#### 39. prevent_incompatible_overrides() Function - Override Protection

**Function**: Prevent incompatible method overrides in Rich commands.

**Function Signature**:

```python
from rich_click.rich_command import prevent_incompatible_overrides
def prevent_incompatible_overrides(
    cmd: RichCommand, 
    class_name: str, 
    ctx: RichContext, 
    formatter: RichHelpFormatter
) -> None
```

**Parameter Description**:

