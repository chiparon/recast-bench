# Introduction and Goals of the Rich-Click Project

Rich-Click is a Python library **aimed at beautifying Click command-line interfaces**. It can use the Rich library to beautifully render the help output of Click command-line tools, providing a more appealing command-line interface experience. While maintaining compatibility with the original Click API, this tool offers rich style customization, grouping management, and theme configuration features. Its core functions include: **Rich style rendering** (automatically beautifying Click help output and error messages), **option and command grouping** (supporting custom panel grouping and sorting), and intelligent parsing support for Markdown and Rich markup languages. In short, Rich-Click is committed to providing a seamless Click upgrade solution, enabling developers to easily create command-line applications with excellent visual effects (for example, simply using `import rich_click as click` can achieve the beautification effect).

## Natural Language Instruction (Prompt)

Please create a Python project named Rich-Click to implement a Click command-line interface beautification library. The project should include the following functions:

1. **Rich rendering engine**: It can take over the rendering of Click's help output, use the Rich library to provide a beautified command-line interface, and support visual effects such as colors, tables, and panels. The rendering results should support multiple output formats (text, HTML, SVG).
2. **Compatibility wrapper**: Implement wrapper classes that are fully compatible with the Click API, including RichCommand, RichGroup, RichContext, etc., to ensure that users can seamlessly migrate from Click to Rich-Click.
3. **Style and theme system**: Provide a complete style configuration system, supporting the customization of visual elements such as colors, borders, and alignment. It should support a flexible combination of global and local configurations.
4. **Grouping and sorting functions**: Implement option grouping (OPTION_GROUPS) and command grouping (COMMAND_GROUPS) functions, supporting wildcard matching and priority sorting to make the command-line help more organized.
5. **Multiple markup support**: Integrate parsing support for Markdown and Rich markup languages, allowing the use of rich formatting markup in help texts.
6. **CLI tool integration**: Provide a command-line tool that can add Rich beautification effects to any third-party application using Click without modifying the original code.
7. **Core file requirements**: The project must include a well-defined pyproject.toml file. This file should not only configure the project as an installable package (supporting pip install) but also declare a complete list of dependencies (including core libraries such as click>=8, rich>=12, typing-extensions, etc.). At the same time, it needs to provide src/rich_click/__init__.py as a unified API entry, importing core classes such as RichCommand, RichGroup, and RichContext from various modules, and providing decorator functions such as command and group, so that users can access all major functions through a simple "import rich_click as click" statement. In rich_help_rendering.py, there should be functions such as rich_format_help() and rich_format_error() to handle various rendering scenarios.

## Environment Configuration

### Python Version
The Python version used in the current project is: Python 3.13.5

### Core Dependency Library Versions

```Plain
# Core Click compatibility library
click>=8                          # Basic library for the Click command-line framework
rich>=12                          # Rich terminal beautification rendering engine
typing-extensions>=4              # Type support for Python versions below 3.11

# Documentation generation dependencies
mkdocs>=1.6.1                    # Documentation generation tool
mkdocs-material>=9.5.18          # Material Design theme
mkdocstrings>=0.26.1             # Automatic API documentation generation

# Other tool dependencies
rich-codex>=1.2.11               # Code example rendering
pre-commit>=3.5                  # Pre-commit hooks
packaging>=25                    # Version parsing tool
inline-snapshot-0.30.0
colorama-0.4.6
pytest>=8
typer-0.19.2 
```

## Rich-Click Project Architecture

### Project Directory Structure

```Plain
workspace/
├── .coveragerc
├── .gitignore
├── .pre-commit-config.yaml
├── .prettierrc.yaml
├── .rich-codex.yml
├── .vscode
│   ├── settings.template.jsonc
├── CHANGELOG.md
├── CONTRIBUTING.md
├── LICENSE
├── README.md
├── docs
│   ├── _deploy.py
│   ├── assets
│   │   ├── fonts
│   │   │   └── pixelmix.ttf
│   ├── blog
│   │   ├── .authors.yml
│   │   ├── index.md
│   │   ├── posts
│   │   │   ├── pycon-sweden-2024.md
│   │   │   ├── three-pre-made-styles.md
│   │   │   ├── version-1.8.md
│   │   │   └── version-1.9.md
│   ├── changelog.md
│   ├── code_snippets
│   │   ├── accessibility
│   │   │   ├── colors.py
│   │   ├── introduction_to_click
│   │   │   ├── hello.py
│   │   │   ├── hello_rich.py
│   │   │   ├── hello_v2.py
│   │   │   ├── hello_v3.py
│   │   ├── panels
│   │   │   ├── panels_column_types.py
│   │   │   ├── panels_commands.py
│   │   │   ├── panels_defaults.py
│   │   │   ├── panels_defaults_override_config.py
│   │   │   ├── panels_defaults_renamed.py
│   │   │   ├── panels_defaults_stylized.py
│   │   │   ├── panels_extra_kwargs.py
│   │   │   ├── panels_handling_help_fix_1.py
│   │   │   ├── panels_handling_help_fix_2.py
│   │   │   ├── panels_handling_help_mistake.py
│   │   │   ├── panels_help_section_types.py
│   │   │   ├── panels_panel_order_explicit.py
│   │   │   ├── panels_panel_order_explicit_override.py
│   │   │   ├── panels_row_order.py
│   │   │   ├── panels_simple_arguments.py
│   │   │   ├── panels_simple_arguments_combined.py
│   │   │   ├── panels_simple_arguments_explicit.py
│   │   │   ├── panels_simple_arguments_help.py
│   │   │   ├── panels_simple_decorators.py
│   │   │   ├── panels_simple_kwargs.py
│   │   │   ├── panels_subclass.py
│   │   ├── rich_click_cli
│   │   │   ├── app.py
│   │   │   ├── typer_example.py
│   │   ├── text_markup_and_formatting
│   │   │   ├── emojis.py
│   │   │   ├── markup_with_help_style.py
│   │   │   ├── newline_control.py
│   │   │   ├── newline_control_base_click.py
│   │   │   ├── newline_control_double.py
│   │   │   ├── rich_markup.py
│   │   ├── themes
│   │   │   ├── cli.py
│   │   ├── typer_support
│   │   │   └── typer_example.py
│   ├── contributing.md
│   ├── css
│   │   ├── editor.css
│   │   ├── extra.css
│   │   ├── termynal.css
│   ├── documentation
│   │   ├── accessibility.md
│   │   ├── comparison_of_click_and_rich_click.md
│   │   ├── configuration.md
│   │   ├── custom_styles.md
│   │   ├── introduction_to_click.md
│   │   ├── panels.md
│   │   ├── rich_click_cli.md
│   │   ├── structure.md
│   │   ├── text_markup_and_formatting.md
│   │   ├── themes.md
│   │   ├── typer_support.md
│   ├── editor.md
│   ├── fonts
│   │   ├── LICENSE
│   │   ├── pixelmix.ttf
│   ├── images
│   │   ├── arguments.svg
│   │   ├── blog
│   │   │   ├── five-pre-made-styles
│   │   │   │   ├── example-1.svg
│   │   │   │   ├── example-2-dark.png
│   │   │   │   ├── example-2-light.png
│   │   │   │   ├── example-3.svg
│   │   │   ├── pycon-sweden-2024
│   │   │   │   ├── Ewels-PyCon-Sweden-2024.pdf
│   │   │   ├── version-1.8
│   │   │   │   ├── arguments_box_and_panel_styles.svg
│   │   │   │   ├── boxes_silly.svg
│   │   │   │   ├── boxes_sleek.svg
│   │   │   │   ├── daniels_example.svg
│   │   │   │   ├── execution_times.png
│   │   │   │   ├── memory_profiles.png
│   │   │   │   ├── output_to_svg.svg
│   │   │   │   ├── phils_example.svg
│   │   │   ├── version-1.9
│   │   │   │   ├── ide1.png
│   │   │   │   ├── ide2.png
│   │   │   │   ├── panels_complex.svg
│   │   │   │   └── panels_simple.svg
│   │   ├── code_snippets
│   │   │   ├── accessibility
│   │   │   │   ├── colors.svg
│   │   │   ├── introduction_to_click
│   │   │   │   ├── hello.svg
│   │   │   │   ├── hello_help.svg
│   │   │   │   ├── hello_rich.svg
│   │   │   │   ├── hello_v2.svg
│   │   │   │   ├── hello_v2_help.svg
│   │   │   │   ├── hello_v3_help.svg
│   │   │   │   ├── hello_v3_subcommand.svg
│   │   │   │   ├── hello_v3_subcommand_help.svg
│   │   │   ├── panels
│   │   │   │   ├── .gitkeep
│   │   │   │   ├── panels_column_types.svg
│   │   │   │   ├── panels_commands.svg
│   │   │   │   ├── panels_defaults_override_config.svg
│   │   │   │   ├── panels_defaults_renamed.svg
│   │   │   │   ├── panels_defaults_renamed_move_item.svg
│   │   │   │   ├── panels_extra_kwargs.svg
│   │   │   │   ├── panels_handling_help_fix_1.svg
│   │   │   │   ├── panels_handling_help_fix_2.svg
│   │   │   │   ├── panels_handling_help_mistake.svg
│   │   │   │   ├── panels_help_section_types.svg
│   │   │   │   ├── panels_panel_order_explicit.svg
│   │   │   │   ├── panels_panel_order_explicit_override.svg
│   │   │   │   ├── panels_row_order.svg
│   │   │   │   ├── panels_simple_arguments.svg
│   │   │   │   ├── panels_simple_arguments_combined.svg
│   │   │   │   ├── panels_simple_arguments_explicit.svg
│   │   │   │   ├── panels_simple_arguments_help.svg
│   │   │   │   ├── panels_simple_decorators.svg
│   │   │   │   ├── panels_simple_kwargs.svg
│   │   │   │   ├── panels_subclass.svg
│   │   │   ├── rich_click_cli
│   │   │   │   ├── output_to_html.svg
│   │   │   │   ├── output_to_svg.svg
│   │   │   │   ├── rich_click.svg
│   │   │   │   ├── typer_example.svg
│   │   │   ├── text_markup_and_formatting
│   │   │   │   ├── emojis.svg
│   │   │   │   ├── markup_with_help_style.svg
│   │   │   │   ├── newline_control.svg
│   │   │   │   ├── newline_control_base_click.svg
│   │   │   │   ├── newline_control_double.svg
│   │   │   │   ├── rich_markup.svg
│   │   │   ├── themes
│   │   │   │   ├── all_themes.svg
│   │   │   │   ├── flask_themed.svg
│   │   │   │   ├── flask_themed_2.svg
│   │   │   │   ├── flask_themed_3.svg
│   │   │   │   ├── themes_blue1_modern.svg
│   │   │   │   ├── themes_blue2_modern.svg
│   │   │   │   ├── themes_cargo_box.svg
│   │   │   │   ├── themes_cyan1_modern.svg
│   │   │   │   ├── themes_cyan2_modern.svg
│   │   │   │   ├── themes_default_box.svg
│   │   │   │   ├── themes_default_modern.svg
│   │   │   │   ├── themes_default_nu.svg
│   │   │   │   ├── themes_default_robo.svg
│   │   │   │   ├── themes_default_slim.svg
│   │   │   │   ├── themes_dracula2_box.svg
│   │   │   │   ├── themes_dracula_box.svg
│   │   │   │   ├── themes_ex1.svg
│   │   │   │   ├── themes_ex2.svg
│   │   │   │   ├── themes_ex3.svg
│   │   │   │   ├── themes_ex4.svg
│   │   │   │   ├── themes_ex5.svg
│   │   │   │   ├── themes_forest_box.svg
│   │   │   │   ├── themes_green1_modern.svg
│   │   │   │   ├── themes_green2_modern.svg
│   │   │   │   ├── themes_magenta1_modern.svg
│   │   │   │   ├── themes_magenta2_modern.svg
│   │   │   │   ├── themes_mono_box.svg
│   │   │   │   ├── themes_nord_box.svg
│   │   │   │   ├── themes_plain_box.svg
│   │   │   │   ├── themes_plain_slim.svg
│   │   │   │   ├── themes_quartz2_box.svg
│   │   │   │   ├── themes_quartz_box.svg
│   │   │   │   ├── themes_red1_modern.svg
│   │   │   │   ├── themes_red2_modern.svg
│   │   │   │   ├── themes_solarized_box.svg
│   │   │   │   ├── themes_star_box.svg
│   │   │   │   ├── themes_yellow1_modern.svg
│   │   │   │   ├── themes_yellow2_modern.svg
│   │   │   ├── typer_support
│   │   │   │   └── typer_example.svg
│   │   ├── command_groups.svg
│   │   ├── custom_error.svg
│   │   ├── error.svg
│   │   ├── favicon.png
│   │   ├── hello.svg
│   │   ├── logo-square-large.png
│   │   ├── markdown.svg
│   │   ├── metavars_appended.svg
│   │   ├── metavars_default.svg
│   │   ├── panels.svg
│   │   ├── rich-click-logo-darkmode.png
│   │   ├── rich-click-logo.png
│   │   ├── rich_click_cli_examples
│   │   │   ├── celery.svg
│   │   │   ├── dagster.svg
│   │   │   ├── flask.svg
│   │   ├── rich_markup.svg
│   │   ├── style_tables.svg
│   ├── index.md
│   ├── live_style_editor.py
│   ├── overrides
│   │   ├── editor.html
│   │   └── main.html
├── examples
│   ├── 01_simple.py
│   ├── 02_declarative.py
│   ├── 03_groups_sorting.py
│   ├── 04_rich_markup.py
│   ├── 05_markdown.py
│   ├── 06_arguments.py
│   ├── 07_custom_errors.py
│   ├── 08_metavars.py
│   ├── 08_metavars_default.py
│   ├── 09_envvar.py
│   ├── 10_table_styles.py
│   ├── 11_hello.py
│   ├── 12_theme_simple.py
├── mkdocs.yml
├── src
│   ├── rich_click
│   │   ├── __init__.py
│   │   ├── __main__.py
│   │   ├── _click_types_cache.py
│   │   ├── _compat_click.py
│   │   ├── _internal_types.py
│   │   ├── cli.py
│   │   ├── decorators.py
│   │   ├── decorators.pyi
│   │   ├── patch.py
│   │   ├── py.typed
│   │   ├── rich_box.py
│   │   ├── rich_click.py
│   │   ├── rich_click_theme.py
│   │   ├── rich_command.py
│   │   ├── rich_command.pyi
│   │   ├── rich_context.py
│   │   ├── rich_group.py
│   │   ├── rich_help_configuration.py
│   │   ├── rich_help_formatter.py
│   │   ├── rich_help_rendering.py
│   │   ├── rich_panel.py
│   │   ├── rich_parameter.py
│   │   └── utils.py
└── pyproject.toml

```

## API Usage Guide

### Core API

#### 1. Module Import

```python

import rich_click as click

import rich_click.rich_click as rc 
import rich_click.rich_command      
import rich_click.rich_context     

from rich_click import (
    RichCommand, RichGroup, RichContext,
    command, group, pass_context, rich_config,
    RichHelpConfiguration
)
```

#### 2. RichCommand Class - Rich Command Wrapper

**Function**: Provides a Click command class with Rich beautification. Inherits from `click.Command` and overrides help and error methods to print richly formatted output.

```python
from rich_click.rich_command import RichCommand

class RichCommand(Command):
    def __init__(
        self,
        *args: Any,
        aliases: Optional[Iterable[str]] = None,
        panels: Optional[List["RichPanel[Any, Any]"]] = None,
        panel: Optional[Union[str, List[str]]] = None,
        **kwargs: Any,
    ) -> None: ...
    @property
    def console(self) -> Optional["Console"]:  ...
    def to_info_dict(self, ctx: click.Context) -> Dict[str, Any]: ...
    @property
    def help_config(self) -> Optional[RichHelpConfiguration]:...
    def _error_formatter(self) -> RichHelpFormatter: ...
    def _generate_rich_help_config(self) -> RichHelpConfiguration: ...
     @overload
    def main(
        self,
        args: Sequence[str] | None = None,
        prog_name: str | None = None,
        complete_var: str | None = None,
        standalone_mode: Literal[True] = True,
        **extra: Any,
    ) -> NoReturn: ...
    @overload
    def main(
        self,
        args: Sequence[str] | None = None,
        prog_name: str | None = None,
        complete_var: str | None = None,
        standalone_mode: bool = ...,
        **extra: Any,
    ) -> Any: ...

    def main(
        self,
        args: Optional[Sequence[str]] = None,
        prog_name: Optional[str] = None,
        complete_var: Optional[str] = None,
        standalone_mode: bool = True,
        windows_expand_args: bool = True,
        **extra: Any,
    ) -> Any:...
     def format_help(self, ctx: RichContext, formatter: RichHelpFormatter) -> None: ...
    def format_help_text(self, ctx: RichContext, formatter: RichHelpFormatter) -> None: ...
    def format_options(self, ctx: click.Context, formatter: click.HelpFormatter) -> None: ...
    def format_epilog(self, ctx: RichContext, formatter: RichHelpFormatter) -> None:...
    def get_help_option(self, ctx: click.Context) -> Union[click.Option, None]: ...
    def get_rich_table_row(
        self,
        ctx: "RichContext",
        formatter: "RichHelpFormatter",
        panel: Optional["RichCommandPanel"] = None,
    ) -> "RichPanelRow": ...
    def add_panel(self, panel: "RichPanel[Any, Any]") -> None: ...
```
**Main methods**:

- `__init__`: Create Rich Command instance with optional aliases and panels
  - `*args`: Arguments passed to the parent Command class
  - `aliases`: Optional iterable of command aliases (Optional[Iterable[str]])
  - `panels`: Optional list of RichPanel instances (Optional[List[RichPanel[Any, Any]]])
  - `panel`: Optional panel assignment for the command (Optional[Union[str, List[str]]])
  - `**kwargs`: Additional keyword arguments passed to the parent Command class
- `format_help`: Format the complete help text including usage, help text, options, and epilog
  - `ctx`: Rich context object (RichContext)
  - `formatter`: Rich help formatter instance (RichHelpFormatter)
- `format_help_text`: Format the help text section with Rich markup support
- `format_options`: Format the option display with Rich tables and panels
- `format_epilog`: Format the epilog section with Rich markup support
- `main`: The main execution method with complex overloads for different execution modes. Handles shell completion, error formatting, and proper exit codes. Returns NoReturn when standalone_mode=True, otherwise returns Any.
  - `args`: Optional sequence of command line arguments (Optional[Sequence[str]])
  - `prog_name`: Optional program name (Optional[str])
  - `complete_var`: Optional completion variable (Optional[str])
  - `standalone_mode`: Whether to run in standalone mode (bool, default=True)
  - `windows_expand_args`: Whether to expand arguments on Windows (bool, default=True)
  - `**extra`: Additional keyword arguments
  - Returns: NoReturn when standalone_mode=True, otherwise Any
- `get_help_option`: Return the help option object with caching support
  - `ctx`: Click context object (click.Context)
  - Returns: Help option object or None (Union[click.Option, None])
- `get_rich_table_row`: Create a row for the rich table corresponding with this command (returns RichPanelRow)
  - `ctx`: Rich context object (RichContext)
  - `formatter`: Rich help formatter instance (RichHelpFormatter)
  - `panel`: Optional rich command panel (Optional[RichCommandPanel])
  - Returns: Rich panel row (RichPanelRow)
- `add_panel`: Add a RichPanel to the RichCommand (panel: RichPanel[Any, Any])
  - `panel`: RichPanel instance to add (RichPanel[Any, Any])
- `to_info_dict`: Gather information that could be useful for documentation generation, returns Dict with panels and aliases info
  - `ctx`: Click context object (click.Context)
  - Returns: Dictionary with command information (Dict[str, Any])
- `console`: Deprecated property that returns Rich Console instance from context settings (returns Optional[Console])
  - Returns: Rich console instance or None (Optional[Console])
- `help_config`: Deprecated property that returns Rich Help Configuration from context settings (returns Optional[RichHelpConfiguration])
  - Returns: Rich help configuration or None (Optional[RichHelpConfiguration])
- `_error_formatter`: Create formatter for error messages (returns RichHelpFormatter)
  - Returns: Rich help formatter for errors (RichHelpFormatter)
- `_generate_rich_help_config`: Generate help configuration for error handling when Context is not available (returns RichHelpConfiguration)
  - Returns: Rich help configuration instance (RichHelpConfiguration)

**Main attributes**:

- `context_class`: Type of context class to use (Type[RichContext])
- `_formatter`: Optional Rich help formatter instance (Optional[RichHelpFormatter])
- `panel`: Panel assignment for the command (Optional[Union[str, List[str]]])
- `panels`: List of RichPanel instances (List[RichPanel[Any, Any]])
- `aliases`: Iterable of command aliases (Iterable[str])
- `_help_option`: Cached help option instance (Optional[click.Option])


#### 3. RichGroup Class - Rich Command Group Wrapper

**Function**: Provides a Click command group class with Rich beautification. Inherits from both `RichCommand` and `click.Group`, providing richly formatted output for command groups.
```python
from rich_click.rich_command import RichGroup

class RichGroup(RichCommand, Group):
     """
    Richly formatted click Group.

    Inherits click.Group and overrides help and error methods
    to print richly formatted output.
    """
    def __init__(self, *args: Any, **kwargs: Any) -> None: ...
    def format_commands(self, ctx: click.Context, formatter: click.HelpFormatter) -> None: ...
    def format_help(self, ctx: RichContext, formatter: RichHelpFormatter) -> None: ...
    def __call__(self, *args: Any, **kwargs: Any) -> Any: ...
    @overload
    def command(self, __func: Callable[..., Any]) -> RichCommand: ...
    @overload
    def command(self, *args: Any, **kwargs: Any) -> Callable[[Callable[..., Any]], RichCommand]: ...
    def command(self, *args: Any, **kwargs: Any) -> Union[Callable[[Callable[..., Any]], RichCommand], RichCommand]: ...
        def decorator(f: Callable[..., Any]) -> RichGroup: ...
    @overload
    def group(self, __func: Callable[..., Any]) -> "RichGroup": ...

    @overload
    def group(self, *args: Any, **kwargs: Any) -> Callable[[Callable[..., Any]], "RichGroup"]: ...

    def group(self, *args: Any, **kwargs: Any) -> Union[Callable[[Callable[..., Any]], "RichGroup"], "RichGroup"]:
         def decorator(f: Callable[..., Any]) -> RichGroup: ...
    def _handle_extras_add_command(
        self,
        cmd: click.Command,
        name: Optional[str] = None,
        aliases: Optional[Iterable[str]] = None,
        panel: Optional[Union[str, List[str]]] = None,
    ) -> None: ...
    def get_command(self, ctx: click.Context, cmd_name: str) -> Optional[click.Command]: ...  
    def add_command(
        self,
        cmd: click.Command,
        name: Optional[str] = None,
        aliases: Optional[Iterable[str]] = None,
        panel: Optional[Union[str, List[str]]] = None,
    ) -> None: ... 
    def add_command_to_panel(
        self,
        command: click.Command,
        panel_name: Union[str, Iterable[str]],
    ) -> None: ...
```
**Main methods**:

- `__init__`: Create RichGroup instance with alias and panel mappings
- `format_commands`: Format the display of subcommands (currently not used)
  - `ctx`: Click context object (click.Context)
  - `formatter`: Click help formatter instance (click.HelpFormatter)
- `format_help`: Format the complete help text including usage, help text, options, and epilog
- `command`: Decorator for declaring and attaching commands to the group with overloads for direct function application
  - `def decorator(f: Callable[..., Any]) -> RichGroup: ...`: Internal functions of command function
        - `f`: Function to decorate (Callable[..., Any])
        - Returns: RichGroup instance (RichGroup)

  - Returns: RichCommand instance or decorator function (Union[RichCommand, Callable])
- `group`: Decorator for declaring and attaching groups to the group with overloads for direct function application
    - `def decorator(f: Callable[..., Any]) -> RichGroup: ...`: Internal functions of group function
        - `f`: Function to decorate (Callable[..., Any])
        - Returns: RichGroup instance (RichGroup)

  - Returns: RichGroup instance or decorator function (Union[RichGroup, Callable])
- `add_command`: Register a Command with the group, supporting aliases and panel assignments
  - `cmd`: Click command instance to add (click.Command)
  - `name`: Optional command name override (Optional[str])
  - `aliases`: Optional list of command aliases (Optional[Iterable[str]])
  - `panel`: Optional panel assignment (Optional[Union[str, List[str]]])
  - Returns: None
- `add_command_to_panel`: Add a command to a specific panel
  - `command`: Click command instance (click.Command)
  - `panel_name`: Panel name or list of panel names (Union[str, Iterable[str]])
  - Returns: None
- `get_command`: Get the specified subcommand, resolving aliases
  - `ctx`: Click context object (click.Context)
  - `cmd_name`: Command name to look up (str)
  - Returns: Command instance or None (Optional[click.Command])
