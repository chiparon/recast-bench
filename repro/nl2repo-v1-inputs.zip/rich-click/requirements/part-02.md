- `_handle_extras_add_command`: Handle backwards compatibility for add_command interfaces
  - `cmd`: Click command instance (click.Command)
  - `name`: Optional command name (Optional[str])
  - `aliases`: Optional command aliases (Optional[Iterable[str]])
  - `panel`: Optional panel assignment (Optional[Union[str, List[str]]])
  - Returns: None
- `__call__`: Alias for main() method
  - `*args`: Variable positional arguments
  - `**kwargs`: Variable keyword arguments
  - Returns: Any (delegates to parent main() method)

**Main attributes**:

- `command_class`: Class attribute - Type of command class to use (Optional[Type[RichCommand]], defaults to RichCommand)
- `group_class`: Class attribute - Type of group class to use for subgroups (Optional[Union[Type[Group], Type[type]]], defaults to type)
- `_alias_mapping`: Instance attribute - Dictionary mapping aliases to command names (Dict[str, str])
- `_panel_command_mapping`: Instance attribute - Dictionary mapping command names to panel names (Dict[str, List[str]])



#### 4. RichMultiCommand Class - Multi-Command Wrapper

**Function**: Alias for RichGroup class to maintain compatibility with Click's MultiCommand interface.

```python
from rich_click.rich_command import RichMultiCommand

RichMultiCommand = RichGroup

class RichMultiCommand(RichGroup, click.CommandCollection):
    pass
```

#### 5. RichCommandCollection Class - Command Collection Wrapper

**Function**: Richly formatted click CommandCollection. Inherits click.CommandCollection and overrides help and error methods to print richly formatted output.

```python
from rich_click.rich_command import RichCommandCollection
class RichCommandCollection(CommandCollection, RichGroup):
    """
    Richly formatted click CommandCollection.

    Inherits click.CommandCollection and overrides help and error methods
    to print richly formatted output.
    """

    def format_help(self, ctx: RichContext, formatter: RichHelpFormatter) -> None: ...

```
**Main methods**:

- `format_help`: Format help text for the command collection
  - `ctx`: Rich context object (RichContext)
  - `formatter`: Rich help formatter instance (RichHelpFormatter)
  - Returns: None

#### 6. RichContext Class - Rich Context Management

**Function**: Click Context class endowed with Rich superpowers. Extends the Click Context and integrates Rich configuration and console.

```python
from rich_click.rich_context import RichContext

class RichContext(click.Context):
    """Click Context class endowed with Rich superpowers."""

    def __init__(
            self,
            *args: Any,
            rich_console: Optional["Console"] = None,
            rich_help_config: Optional[Union[Mapping[str, Any], RichHelpConfiguration]] = None,
            export_console_as: Optional[Literal["html", "svg", "text"]] = None,
            errors_in_output_format: Optional[bool] = None,
            help_to_stderr: Optional[bool] = None,
            **kwargs: Any,
        ) -> None: ...
    def make_formatter(self, error_mode: bool = False) -> RichHelpFormatter: ...

```
**Main methods**:

- `__init__(*args, rich_console=None, rich_help_config=None, export_console_as=None, errors_in_output_format=None, help_to_stderr=None, **kwargs)`: Create Rich Context instance with Rich configuration
  - `*args`: Variable positional arguments passed to click.Context
  - `rich_console`: Rich Console instance (Optional[Console])
  - `rich_help_config`: Rich help configuration (Optional[Union[Mapping[str, Any], RichHelpConfiguration]])
  - `export_console_as`: Output format for console export (Optional[Literal["html", "svg", "text"]])
  - `errors_in_output_format`: Whether to use output format for error messages (Optional[bool])
  - `help_to_stderr`: Whether to print help to stderr (Optional[bool])
  - `**kwargs`: Variable keyword arguments passed to click.Context
  - Returns: None
- `make_formatter(error_mode=False)`: Create the Rich Help Formatter
  - `error_mode`: Whether formatter is in error mode (bool)
  - Returns: Rich help formatter instance (RichHelpFormatter)
    - `__enter__()`: Context manager entry
        - Returns: RichContext instance (RichContext)
    - `__exit__(exc_type, exc_value, tb)`: Context manager exit
      - `exc_type`: Exception type (Optional[Type[BaseException]])
      - `exc_value`: Exception value (Optional[BaseException])
      - `tb`: Traceback object (Optional[TracebackType])
      - Returns: None

**Main attributes**:

- `formatter_class`: Class attribute - Type of formatter class to use (Type[RichHelpFormatter], defaults to RichHelpFormatter)
- `console`: Rich console instance (Optional[Console])
- `export_console_as`: Output format (Optional[Literal["html", "svg", "text"]])
- `errors_in_output_format`: Whether to use output format for errors (bool)
- `help_to_stderr`: Whether to print help to stderr (bool)
- `help_config`: Rich help configuration object (RichHelpConfiguration)


#### 7. RichHelpConfiguration Class - Help Configuration Management

**Function**: Manages all visual and behavioral configurations of Rich-Click.

```python
from rich_click.rich_help_configuration import RichHelpConfiguration
@dataclass
class RichHelpConfiguration:
    """
    Rich Help Configuration class.

    When merging multiple RichHelpConfigurations together, user-defined values always
    take precedence over the class's defaults. When there are multiple user-defined values
    for a given field, the right-most field is used.
    """
    def __post_init__(self) -> None: ...
    @classmethod
    def load_from_globals(cls, module: Optional[ModuleType] = None, **extra: Any) -> "RichHelpConfiguration":
    def apply_theme(self, force_default: bool = False) -> None: ...
    def to_theme(self, **kwargs: Any) -> RichClickTheme: ...
    def dump_to_globals(self, module: Optional[ModuleType] = None) -> None:
    
```
**Main methods**:

- `__post_init__`: Post-initialization method that applies theme and handles deprecated warnings
- `load_from_globals(module=None, **extra)`: Class method to build a RichHelpConfiguration from globals in rich_click.rich_click
  - `module`: Module to load globals from (Optional[ModuleType])
  - `**extra`: Additional keyword arguments
  - Returns: RichHelpConfiguration instance (RichHelpConfiguration)
- `apply_theme(force_default=False)`: Apply heat theme configuration to the configuration instance
  - `force_default`: Whether to force default theme (bool)
  - Returns: None
- `to_theme(**kwargs)`: Convert configuration to RichClickTheme instance
  - `**kwargs`: Additional keyword arguments for theme creation
  - Returns: RichClickTheme instance (RichClickTheme)
- `dump_to_globals(module=None)`: Dump configuration values to global module variables
  - `module`: Module to dump globals to (Optional[ModuleType])
  - Returns: None

**Main configuration categories**:

- **Style configuration**: Visual styles such as colors, fonts, and borders.
- **Layout configuration**: Panel alignment, table styles, column widths, etc.
- **Behavior configuration**: Whether to display parameters, grouping methods, etc.
- **Text configuration**: Markup language type, string templates, etc.


#### 8. rich_config Decorator - Configuration Application

**Function**: Applies Rich configuration to a command or group.

**Function signature**:

```python
from rich_click.decorators import rich_config
'''filepath: rich-click/src/rich_click/decorators.pyi'''
@overload
def rich_config(
    help_config: RichHelpConfigurationDict,
    *,
    console: Optional[Console] = ...,
) -> Callable[[FC], FC]: ...
@overload
def rich_config(
    help_config: Optional[Union[Dict[str, Any], RichHelpConfigurationDict, RichHelpConfiguration]] = ...,
    *,
    console: Optional[Console] = ...,
) -> Callable[[FC], FC]: ...
def rich_config(
    help_config: Optional[Union[Dict[str, Any], RichHelpConfigurationDict, RichHelpConfiguration]] = None,
    *,
    console: Optional[Console] = None,
) -> Callable[[FC], FC]: ...

'''filepath: rich-click/src/rich_click/decorators.py'''

def rich_config(
    help_config: Optional[Union[Dict[str, Any], RichHelpConfiguration]] = None,
    *,
    console: Optional["Console"] = None,
) -> Callable[[FC], FC]:
```

**Parameter Description**:

- `help_config` (Optional[Union[Mapping[str, Any], RichHelpConfiguration]]): Optional configuration dictionary or RichHelpConfiguration object to apply to the command. Defaults to None.
- `console` (Optional[Console]): Optional Rich Console object to use for output. Defaults to None.

**Return Value**: A decorator function that applies Rich configuration to the command or group.


#### 9. RichParameter Class - Rich Parameter Base Class

**Function**: Base class for Rich-enhanced Click parameters with additional styling capabilities.
```python
from rich_click.rich_parameter import RichParameter

class RichParameter(click.Parameter):
    r"""
    A parameter to a command comes in two versions: they are either
    :class:`Option`\s or :class:`Argument`\s.  Other subclasses are currently
    not supported by design as some of the internals for parsing are
    intentionally not finalized.
    """
     def __init__(
        self,
        *args: Any,
        panel: Optional[Union[str, List[str]]] = None,
        help: Optional[str] = None,
        help_style: Optional["StyleType"] = None,
        **kwargs: Any,
    ): ...
    def to_info_dict(self) -> dict[str, Any]: ...
    def get_rich_help(self, ctx: "RichContext", formatter: "RichHelpFormatter") -> "Columns":
    def get_rich_table_row(
        self,
        ctx: "RichContext",
        formatter: "RichHelpFormatter",
        panel: Optional["RichOptionPanel"] = None,
    ) -> "RichPanelRow": ...    
```
**Main methods**:

- `__init__(*args, panel=None, help=None, help_style=None, **kwargs)`: Create RichParameter instance with panel and styling support
  - `*args`: Variable positional arguments passed to click.Parameter
  - `panel`: Panel assignment for the parameter (Optional[Union[str, List[str]]])
  - `help`: Help text for the parameter (Optional[str])
  - `help_style`: Style for help text (Optional[StyleType])
  - `**kwargs`: Variable keyword arguments passed to click.Parameter
  - Returns: None
- `get_rich_help(ctx, formatter)`: Get Rich-formatted help for the parameter
  - `ctx`: Rich context object (RichContext)
  - `formatter`: Rich help formatter instance (RichHelpFormatter)
  - Returns: Rich columns object (Columns)
- `get_rich_table_row(ctx, formatter, panel)`: Get table row representation for Rich display
  - `ctx`: Rich context object (RichContext)
  - `formatter`: Rich help formatter instance (RichHelpFormatter)
  - `panel`: Optional rich option panel (Optional[RichOptionPanel])
  - Returns: Rich panel row (RichPanelRow)
- `to_info_dict()`: Convert parameter to dictionary representation
  - Returns: Dictionary with parameter information (dict[str, Any])

**Main attributes**:

- `panel`: Panel assignment for the parameter (Optional[Union[str, List[str]]])
- `help`: Help text for the parameter (Optional[str])
- `help_style`: Style for help text (Optional[StyleType])



#### 10. RichArgument Class - Rich Argument Parameter

**Function**: Rich-enhanced Click Argument parameter with styling support.

```python 
from rich_click.rich_parameter import RichParameter
class RichArgument(RichParameter, click.Argument):
    """
    Arguments are positional parameters to a command.  They generally
    provide fewer features than options but can have infinite ``nargs``
    and are required by default.

    All parameters are passed onwards to the constructor of :class:`Parameter`.
    """
```

**Inheritance**: Inherits from both `RichParameter` and `click.Argument`.

**Main methods**:

- Inherits all methods from `RichParameter` and `click.Argument`

**Main attributes**:

- Inherits all attributes from `RichParameter` and `click.Argument`


#### 11. RichOption Class - Rich Option Parameter

**Function**: Rich-enhanced Click Option parameter with styling and formatting capabilities.

```python
from rich_click.rich_parameter import RichOption
class RichOption(RichParameter, click.Option):
    """
    Options are usually optional values on the command line and
    have some extra features that arguments don't have.

    All other parameters are passed onwards to the parameter constructor.
    """
```
**Inheritance**: Inherits from both `RichParameter` and `click.Option`.

**Main methods**:

- Inherits all methods from `RichParameter` and `click.Option`

**Main attributes**:

- Inherits all attributes from `RichParameter` and `click.Option`



#### 12. RichPanel Class - Panel Management Base Class

**Function**: Base class for managing Rich panels that group commands or options.

```python
from rich_click.rich_panel import RichPanel

class RichPanel(Generic[CT, ColT]):
    """RichPanel base class."""
     def __init__(
        self,
        name: str,
        *,
        help: Optional[str] = None,
        help_style: Optional["StyleType"] = None,
        table_styles: Optional[Dict[str, Any]] = None,
        panel_styles: Optional[Dict[str, Any]] = None,
        column_types: Optional[List[ColT]] = None,
        inline_help_in_title: Optional[bool] = None,
        title_style: Optional["StyleType"] = None,
    ) -> None: ...
     @property
    def objects(self) -> List[str]: ...
    def add_object(self, o: str) -> None: ...
    def get_box(self, box: Optional[Union[str, "Box"]]) -> Optional["Box"]: ...
    def to_info_dict(self, ctx: Context) -> Dict[str, Any]: ...
    @classmethod
    def list_all_objects(cls, ctx: Context) -> List[Tuple[str, CT]]: ...
    def get_objects(self, command: Command, ctx: Context) -> Generator[CT, None, None]: ...
    def _get_base_table(self, **defaults: Any) -> "Table": ...
    def get_table(
        self,
        command: "RichCommand",
        ctx: "RichContext",
        formatter: "RichHelpFormatter",
    ) -> "Table": ...
    def _get_base_panel(self, table: "Table", **defaults: Any) -> "Panel": ...
    def render(
        self,
        command: "RichCommand",
        ctx: "RichContext",
        formatter: "RichHelpFormatter",
    ) -> "Panel": ...
    def __repr__(self) -> str: ...
``` 
**Main methods**:

- `__init__`: Initialize a RichPanel
  - `name`: Panel name (str)
  - `help`: Panel help text (Optional[str])
  - `help_style`: Style for help text (Optional[StyleType])
  - `table_styles`: Styles for the table (Optional[Dict[str, Any]])
  - `panel_styles`: Styles for the panel (Optional[Dict[str, Any]])
  - `column_types`: Column type definitions (Optional[List[ColT]])
  - `inline_help_in_title`: Whether to show help inline in title (Optional[bool])
  - `title_style`: Style for the title (Optional[StyleType])
  - Returns: None
- `objects`: Property to get objects list (returns List[str])
- `add_object`: Add an object to the panel
  - `o`: Object name to add (str)
  - Returns: None
- `get_box`: Get box instance from string or Box object
  - `box`: Box string or Box instance (Optional[Union[str, Box]])
  - Returns: Box instance or None (Optional[Box])
- `get_objects`: Get objects belonging to this panel
  - `command`: Rich command instance (RichCommand)
  - `ctx`: Rich context object (RichContext)
  - Returns: Generator of objects (Generator[CT, None, None])
- `_get_base_table`: Get base table instance
  - `**defaults`: Default table configuration (Any)
  - Returns: Table instance (Table)
- `get_table`: Get table representation of panel contents
  - `command`: Rich command instance (RichCommand)
  - `ctx`: Rich context object (RichContext)
  - `formatter`: Rich help formatter instance (RichHelpFormatter)
  - Returns: Table instance (Table)
- `_get_base_panel`: Get base panel instance
  - `table`: Table instance (Table)
  - `**defaults`: Default panel configuration (Any)
  - Returns: Panel instance (Panel)
- `render`: Render the panel with Rich formatting
  - `command`: Rich command instance (RichCommand)
  - `ctx`: Rich context object (RichContext)
  - `formatter`: Rich help formatter instance (RichHelpFormatter)
  - Returns: Panel instance (Panel)
- `to_info_dict`: Get panel information for documentation
  - `ctx`: Click context object (Context)
  - Returns: Dictionary with panel information (Dict[str, Any])
- `list_all_objects`: Class method to list all objects of the command that this panel type works with
  - `ctx`: Click context object (Context)
  - Returns: List of object tuples (List[Tuple[str, CT]])
- `__repr__`: Get string representation of the panel
  - Returns: String representation (str)

#### 13. RichOptionPanel Class - Options Panel Management

**Function**: Manages panels containing option parameters with Rich formatting.
```python

from rich_click.rich_panel import OptionColumnType

class RichOptionPanel(RichPanel[Parameter, OptionColumnType]):
    """Panel for parameters."""
     def __init__(
        self,
        name: str,
        options: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None: ...
    @classmethod
    def list_all_objects(cls, ctx: Context) -> List[Tuple[str, Parameter]]: ...
    def get_objects(self, command: Command, ctx: Context) -> Generator[Parameter, None, None]: ...
    def get_table(
        self,
        command: "RichCommand",
        ctx: "RichContext",
        formatter: "RichHelpFormatter",
    ) -> "Table": ...
    def render(
        self,
        command: "RichCommand",
        ctx: "RichContext",
        formatter: "RichHelpFormatter",
    ) -> "Panel": ...

```
**Inheritance**: Inherits from `RichPanel`.

**Main methods**:

- `__init__`: Initialize a RichOptionPanel with specific options
  - `name`: Panel name (str)
  - `options`: List of option names (Optional[List[str]])
  - `**kwargs`: Additional keyword arguments passed to parent RichPanel
  - Returns: None
- `list_all_objects`: Class method to list all available option objects
  - `ctx`: Click context object (Context)
  - Returns: List of option tuples (List[Tuple[str, Parameter]])
- `get_objects`: Get options for this panel
  - `command`: Rich command instance (RichCommand)
  - `ctx`: Rich context object (RichContext)
  - Returns: Generator of parameters (Generator[Parameter, None, None])
- `render`: Render options panel
  - `command`: Rich command instance (RichCommand)
  - `ctx`: Rich context object (RichContext)
  - `formatter`: Rich help formatter instance (RichHelpFormatter)
  - Returns: Panel instance (Panel)
- `get_table`: Create a rich table for displaying parameters
  - `command`: Rich command instance (RichCommand)
  - `ctx`: Rich context object (RichContext)
  - `formatter`: Rich help formatter instance (RichHelpFormatter)
  - Returns: Table instance (Table)

#### 14. RichCommandPanel Class - Commands Panel Management

**Function**: Manages panels containing command groups with Rich formatting.
``` python
from rich_click.rich_panel import CommandColumnType

class RichCommandPanel(RichPanel[Command, CommandColumnType]):
    """Panel for parameters."""
    def __init__(
        self,
        name: str,
        commands: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None: ...
    @classmethod
    def list_all_objects(cls, ctx: Context) -> List[Tuple[str, Command]]: ...
    def get_objects(self, command: Command, ctx: Context) -> Generator[Command, None, None]: ...
    def get_table(
        self,
        command: "RichCommand",
        ctx: "RichContext",
        formatter: "RichHelpFormatter",
    ) -> "Table": ...
     def render(
        self,
        command: "RichCommand",
        ctx: "RichContext",
        formatter: "RichHelpFormatter",
    ) -> "Panel": ...


```
**Inheritance**: Inherits from `RichPanel`.

**Main methods**:

- `__init__`: Initialize a RichCommandPanel with specific commands
  - `name`: Panel name (str)
  - `commands`: List of command names (Optional[List[str]])
  - `**kwargs`: Additional keyword arguments passed to parent RichPanel
  - Returns: None
- `list_all_objects`: Class method to list all available command objects
  - `ctx`: Click context object (Context)
  - Returns: List of command tuples (List[Tuple[str, Command]])
- `get_objects`: Get commands for this panel
  - `command`: Rich command instance (RichCommand)
  - `ctx`: Rich context object (RichContext)
  - Returns: Generator of commands (Generator[Command, None, None])
- `render`: Render commands panel
  - `command`: Rich command instance (RichCommand)
  - `ctx`: Rich context object (RichContext)
  - `formatter`: Rich help formatter instance (RichHelpFormatter)
  - Returns: Panel instance (Panel)
- `get_table`: Create a rich table for displaying commands
  - `command`: Rich command instance (RichCommand)
  - `ctx`: Rich context object (RichContext)
  - `formatter`: Rich help formatter instance (RichHelpFormatter)
  - Returns: Table instance (Table)


#### 15. RichHelpFormatter Class - Help Text Formatting

**Function**: Rich-enhanced help formatter that handles console output and styling.
```python
from rich_click.rich_help_formatting import RichHelpFormatter

class RichHelpFormatter(click.HelpFormatter):
    """
    Rich Help Formatter.

    This class is a container for the help configuration and Rich Console that
    are used internally by the help and error printing methods.
    """
     def __init__(
        self,
        indent_increment: int = 2,
        width: Optional[int] = None,
        max_width: Optional[int] = None,
        *args: Any,
        console: Optional["Console"] = None,
        config: Optional[RichHelpConfiguration] = None,
        export_console_as: Literal[None, "html", "svg", "text"] = None,
        export_kwargs: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None: ...
    @property
    def width(self) -> int: ...
    @width.setter
    def width(self, v: int) -> None: ...
    @cached_property
    def highlighter(self) -> "Highlighter": ...
    def write(self, *objects: Any, **kwargs: Any) -> None: ...
    def write_usage(self, prog: str, args: str = "", prefix: Optional[str] = None) -> None: ...
    def write_error(self, e: click.ClickException) -> None: ...
    def write_abort(self) -> None: ...
    def rich_text(
        self,
        text: Union[str, "Text", "Markdown"],
        style: "StyleType" = "",
    ) -> Union["Text", "Markdown"]: ...
    def getvalue(self) -> str: ...
    def indent(self) -> None: ...
    def dedent(self) -> None: ...
    def write_heading(self, heading: str) -> None: ...
    def write_paragraph(self) -> None: ...
    def write_text(self, text: str) -> None: ...
    def write_dl(
        self,
        rows: Sequence[Tuple[str, str]],
        col_max: int = 30,
        col_spacing: int = 2,
    ) -> None: ...
     @contextmanager
    def section(self, name: str) -> Iterator[None]: ...
    @contextmanager
    def indentation(self) -> Iterator[None]: ...


```
**Inheritance**: Inherits from `click.HelpFormatter`.

**Main methods**:

- `__init__`: Initialize RichHelpFormatter
  - `indent_increment`: Indent increment for formatting (int)
  - `width`: Console width (Optional[int])
  - `max_width`: Maximum content width (Optional[int])
  - `*args`: Variable positional arguments
  - `console`: Rich console instance (Optional[Console])
  - `config`: Rich help configuration (Optional[RichHelpConfiguration])
  - `export_console_as`: Output format (Optional[Literal["html", "svg", "text"]])
  - `export_kwargs`: Export keyword arguments (Optional[Dict[str, Any]])
  - `**kwargs`: Variable keyword arguments
  - Returns: None
- `width`: Property to get console width (returns int)
- `width(value)`: Property setter for console width (value: int)
- `highlighter`: Property to get highlighter instance (returns Highlighter)
- `write`: Write objects to console
  - `*objects`: Objects to write (Any)
  - `**kwargs`: Additional keyword arguments
  - Returns: None
- `write_usage`: Write usage information with Rich styling
  - `prog`: Program name (str)
  - `args`: Command arguments (str)
