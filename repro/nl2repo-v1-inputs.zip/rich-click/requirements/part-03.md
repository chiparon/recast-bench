  - `prefix`: Optional prefix (Optional[str])
  - Returns: None
- `write_error`: Write error messages with Rich formatting
  - `e`: Click exception (click.ClickException)
  - Returns: None
- `write_abort`: Print richly formatted abort error
  - Returns: None
- `rich_text`: Create Rich text with specified styling
  - `text`: Text to format (str)
  - `style`: Style to apply (str)
  - Returns: Rich text object (Union[Text, Markdown])
- `getvalue`: Get formatted output as string
  - Returns: Formatted string (str)
- `indent`: Indent text (deprecated, not implemented)
  - Returns: None
- `dedent`: Dedent text (deprecated, not implemented)
  - Returns: None
- `write_heading`: Write section headings with Rich styling (deprecated, not implemented)
  - `heading`: Heading text (str)
  - Returns: None
- `write_paragraph`: Write paragraph (deprecated, not implemented)
- `write_text`: Write text (deprecated, not implemented)
  - `text`: Text to write (str)
  - Returns: None
- `write_dl`: Write definition list (deprecated, not implemented)
  - `rows`: Definition list rows (List[Tuple[str, str]])
  - `col_max`: Maximum column width (int)
  - `col_spacing`: Column spacing (int)
  - Returns: None
- `section`: Create a section context (deprecated, not implemented)
  - `name`: Section name (str)
  - Returns: Iterator context (Iterator[None])
- `indentation()`: Create an indentation context (deprecated, not implemented)
  - Returns: Iterator context (Iterator[None])

**Main attributes**:

- `config`: Rich help configuration (RichHelpConfiguration)
- `console`: Rich console instance (Optional[Console])
- `export_console_as`: Output format (Optional[Literal["html", "svg", "text"]])
- `width`: Terminal width (Optional[int])
- `option_panel_class: Type[RichOptionPanel]`: Option panel class (Type[RichOptionPanel])
- `command_panel_class: Type[RichCommandPanel]`: Command panel class (Type[RichCommandPanel])

#### 16. RichClickTheme Class - Theme Management

**Function**: Manages Rich-Click themes for consistent styling across commands.
```python
class RichClickTheme:
    """Rich theme. This sets defaults styling for the CLI."""
    def __init__(
            self,
            name: str,
            *,
            description: Optional[str] = None,
            hidden: bool = False,
            styles: Optional[Dict[str, Any]] = None,
            primary_colors: Optional[List["StyleType"]] = None,
            post_combine_callback: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None,
        ) -> None: ...
    def __repr__(self) -> str: ...
    def combine(self, other: "RichClickTheme") -> "RichClickTheme": ...
    def __add__(self, other: "RichClickTheme") -> "RichClickTheme": ...
    def __radd__(self, other: "RichClickTheme") -> "RichClickTheme": ...

```
**Main methods**:

- `__init__`: Initialize RichClickTheme with theme configuration
  - `name`: Theme name (str)
  - `description`: Theme description (Optional[str])
  - `hidden`: Whether theme is hidden from rich-click --themes (bool)
  - `styles`: Dictionary of styles applied by the theme (Optional[Dict[str, Any]])
  - `primary_colors`: Primary colors for the theme (Optional[List[str]])
  - `post_combine_callback`: Callback function for post-combine processing (Optional[Callable])
  - Returns: None

- `__repr__`: String representation of the theme
  - Returns: String representation (str)

- `combine`: Combine with another theme
  - `other`: Other theme to combine with (RichClickTheme)
  - Returns: Combined theme (RichClickTheme)

- `__add__`: Add themes together using + operator
  - `other`: Other theme to add (RichClickTheme)
  - Returns: Combined theme (RichClickTheme)

- `__radd__`: Right addition operator for theme combination
  - `other`: Other theme for right addition (RichClickTheme)
  - Returns: Combined theme (RichClickTheme)

**Main attributes**:

- `name`: Theme name (str)
- `description`: Theme description (Optional[str])
- `hidden`: Whether theme is hidden from rich-click --themes (bool)
- `styles`: Dictionary of styles applied by the theme (Dict[str, Any])
- `primary_colors`: List of primary colors used (List[StyleType])
- `post_combine_callback`: Callback function for post-combination adjustments (Optional[Callable[[Dict[str, Any]], Dict[str, Any]]])


### Type Definitions

#### 1. RichContextSettingsDict Class - Context Settings Type

**Function**: TypedDict defining the structure for Rich context settings.
```python
from rich_click._internal_types import RichContextSettingsDict
class RichContextSettingsDict(TypedDict): ...

```
**Keys**:
- `obj`: Context object (NotRequired[Any | None])
- `auto_envvar_prefix`: Environment variable prefix (NotRequired[Optional[str]])
- `default_map`: Default configuration mapping (NotRequired[MutableMapping[str, Any] | None])
- `terminal_width`: Terminal width setting (NotRequired[Optional[int]])
- `max_content_width`: Maximum content width (NotRequired[Optional[int]])
- `resilient_parsing`: Whether to use resilient parsing (NotRequired[bool])
- `allow_extra_args`: Whether to allow extra arguments (NotRequired[Optional[bool]])
- `allow_interspersed_args`: Whether to allow interspersed arguments (NotRequired[Optional[bool]])
- `ignore_unknown_options`: Whether to ignore unknown options (NotRequired[Optional[bool]])
- `help_option_names`: List of help option names (NotRequired[Optional[List[str]]])
- `token_normalize_func`: Token normalization function (NotRequired[Callable[[str], str] | None])
- `color`: Whether to use colors (NotRequired[Optional[bool]])
- `show_default`: Whether to show default values (NotRequired[Optional[bool]])
- `rich_console`: Rich console instance (NotRequired[Optional[Console]])
- `rich_help_config`: Rich help configuration (NotRequired[Optional[Union[Mapping[str, Any], RichHelpConfiguration]]])
- `export_console_as`: Export format (NotRequired[Optional[Literal["html", "svg", "text"]]])
- `errors_in_output_format`: Whether to use output format for errors (NotRequired[Optional[bool]])
- `help_to_stderr`: Whether to print help to stderr (NotRequired[Optional[bool]])


#### 2. TableKwargs Class - Table Configuration Type

**Function**: TypedDict defining the structure for Rich table styling options.
```python
from rich_click._internal_types import TableKwargs
class TableKwargs(TypedDict): ...

```
**Keys**:
- `title`: Table title (NotRequired[Optional[TextType]])
- `caption`: Table caption (NotRequired[Optional[TextType]])
- `width`: Table width (NotRequired[Optional[int]])
- `min_width`: Minimum table width (NotRequired[Optional[int]])
- `box`: Table box style (NotRequired[Optional[Union[str, Box]]])
- `safe_box`: Whether to use safe box (NotRequired[Optional[bool]])
- `padding`: Table padding (NotRequired[PaddingDimensions])
- `collapse_padding`: Whether to collapse padding (NotRequired[bool])
- `pad_edge`: Whether to pad edges (NotRequired[bool])
- `expand`: Whether to expand table (NotRequired[bool])
- `show_header`: Whether to show header (NotRequired[bool])
- `show_footer`: Whether to show footer (NotRequired[bool])
- `show_edge`: Whether to show edges (NotRequired[bool])
- `show_lines`: Whether to show lines (NotRequired[bool])
- `leading`: Leading spacing (NotRequired[int])
- `style`: Table style (NotRequired[StyleType])
- `row_styles`: Row styles (NotRequired[Optional[Iterable[StyleType]]])
- `header_style`: Header style (NotRequired[Optional[StyleType]])
- `footer_style`: Footer style (NotRequired[Optional[StyleType]])
- `border_style`: Border style (NotRequired[Optional[StyleType]])
- `title_style`: Title style (NotRequired[Optional[StyleType]])
- `caption_style`: Caption style (NotRequired[Optional[StyleType]])
- `title_justify`: Title justification (NotRequired[JustifyMethod])
- `caption_justify`: Caption justification (NotRequired[JustifyMethod])
- `highlight`: Whether to highlight (NotRequired[bool])


#### 3. PanelKwargs Class - Panel Configuration Type

**Function**: TypedDict defining the structure for Rich panel styling options.
```python
from rich_click._internal_types import PanelKwargs
class PanelKwargs(TypedDict): ...

```
**Keys**:
- `box`: Panel box style (NotRequired[Union[str, Box]])
- `title`: Panel title (NotRequired[Optional[TextType]])
- `title_align`: Title alignment (NotRequired[AlignMethod])
- `subtitle`: Panel subtitle (NotRequired[Optional[TextType]])
- `subtitle_align`: Subtitle alignment (NotRequired[AlignMethod])
- `safe_box`: Whether to use safe box (NotRequired[Optional[bool]])
- `expand`: Whether to expand panel (NotRequired[bool])
- `style`: Panel style (NotRequired[StyleType])
- `border_style`: Border style (NotRequired[StyleType])
- `width`: Panel width (NotRequired[Optional[int]])
- `height`: Panel height (NotRequired[Optional[int]])
- `padding`: Panel padding (NotRequired[PaddingDimensions])
- `highlight`: Whether to highlight (NotRequired[bool])


#### 4. RichHelpConfigurationDict Class - Help Configuration Type

**Function**: TypedDict defining the complete structure for Rich help configuration.
```python
from rich_click._internal_types import RichHelpConfigurationDict

class RichHelpConfigurationDict(TypedDict):
    """Typed dict for rich_config() kwargs."""
```

**Keys**:
- `theme`: Theme configuration (NotRequired[Optional[Union[str, RichClickTheme]]])
- `enable_theme_env_var`: Enable theme environment variable (NotRequired[bool])
- `style_option`: Option style (NotRequired[StyleType])
- `style_option_negative`: Negative option style (NotRequired[Optional[StyleType]])
- `style_argument`: Argument style (NotRequired[StyleType])
- `style_command`: Command style (NotRequired[StyleType])
- `style_command_aliases`: Command aliases style (NotRequired[StyleType])
- `style_switch`: Switch style (NotRequired[StyleType])
- `style_switch_negative`: Negative switch style (NotRequired[Optional[StyleType]])
- `style_metavar`: Metavar style (NotRequired[StyleType])
- `style_metavar_append`: Metavar append style (NotRequired[StyleType])
- `style_metavar_separator`: Metavar separator style (NotRequired[StyleType])
- `style_range_append`: Range append style (NotRequired[StyleType])
- `style_header_text`: Header text style (NotRequired[StyleType])
- `style_epilog_text`: Epilog text style (NotRequired[StyleType])
- `style_footer_text`: Footer text style (NotRequired[StyleType])
- `style_usage`: Usage style (NotRequired[StyleType])
- `style_usage_command`: Usage command style (NotRequired[StyleType])
- `style_usage_separator`: Usage separator style (NotRequired[StyleType])
- `style_deprecated`: Deprecated style (NotRequired[StyleType])
- `style_helptext_first_line`: Help text first line style (NotRequired[StyleType])
- `style_helptext`: Help text style (NotRequired[StyleType])
- `style_helptext_aliases`: Help text aliases style (NotRequired[Optional[StyleType]])
- `style_option_help`: Option help style (NotRequired[StyleType])
- `style_command_help`: Command help style (NotRequired[StyleType])
- `style_option_default`: Option default style (NotRequired[StyleType])
- `style_option_envvar`: Option environment variable style (NotRequired[StyleType])
- `style_required_short`: Required short style (NotRequired[StyleType])
- `style_required_long`: Required long style (NotRequired[StyleType])
- `style_options_panel_border`: Options panel border style (NotRequired[StyleType])
- `style_options_panel_box`: Options panel box style (NotRequired[Optional[Union[str, Box]]])
- `style_options_panel_help_style`: Options panel help style (NotRequired[StyleType])
- `style_options_panel_title_style`: Options panel title style (NotRequired[StyleType])
- `style_options_panel_padding`: Options panel padding (NotRequired[PaddingDimensions])
- `style_options_panel_style`: Options panel style (NotRequired[StyleType])
- `align_options_panel`: Options panel alignment (NotRequired[AlignMethod])
- `style_options_table_show_lines`: Options table show lines (NotRequired[bool])
- `style_options_table_leading`: Options table leading (NotRequired[int])
- `style_options_table_pad_edge`: Options table pad edge (NotRequired[bool])
- `style_options_table_padding`: Options table padding (NotRequired[PaddingDimensions])
- `style_options_table_expand`: Options table expand (NotRequired[bool])
- `style_options_table_box`: Options table box style (NotRequired[Optional[Union[str, Box]]])
- `style_options_table_row_styles`: Options table row styles (NotRequired[Optional[List[StyleType]]])
- `style_options_table_border_style`: Options table border style (NotRequired[Optional[StyleType]])
- `style_commands_panel_border`: Commands panel border style (NotRequired[StyleType])
- `panel_inline_help_in_title`: Panel inline help in title (NotRequired[bool])
- `panel_inline_help_delimiter`: Panel inline help delimiter (NotRequired[str])
- `style_commands_panel_box`: Commands panel box style (NotRequired[Optional[Union[str, Box]]])
- `style_commands_panel_help_style`: Commands panel help style (NotRequired[StyleType])
- `style_commands_panel_title_style`: Commands panel title style (NotRequired[StyleType])
- `style_commands_panel_padding`: Commands panel padding (NotRequired[PaddingDimensions])
- `style_commands_panel_style`: Commands panel style (NotRequired[StyleType])
- `align_commands_panel`: Commands panel alignment (NotRequired[AlignMethod])
- `style_commands_table_show_lines`: Commands table show lines (NotRequired[bool])
- `style_commands_table_leading`: Commands table leading (NotRequired[int])
- `style_commands_table_pad_edge`: Commands table pad edge (NotRequired[bool])
- `style_commands_table_padding`: Commands table padding (NotRequired[PaddingDimensions])
- `style_commands_table_expand`: Commands table expand (NotRequired[bool])
- `style_commands_table_box`: Commands table box style (NotRequired[Optional[Union[str, Box]]])
- `style_commands_table_row_styles`: Commands table row styles (NotRequired[Optional[List[StyleType]]])
- `style_commands_table_border_style`: Commands table border style (NotRequired[Optional[StyleType]])
- `style_commands_table_column_width_ratio`: Commands table column width ratio (NotRequired[Optional[Union[Tuple[None, None], Tuple[int, int]]]])
- `style_errors_panel_border`: Errors panel border style (NotRequired[StyleType])
- `style_errors_panel_box`: Errors panel box style (NotRequired[Optional[Union[str, Box]]])
- `align_errors_panel`: Errors panel alignment (NotRequired[AlignMethod])
- `style_errors_suggestion`: Errors suggestion style (NotRequired[Optional[StyleType]])
- `style_errors_suggestion_command`: Errors suggestion command style (NotRequired[Optional[StyleType]])
- `style_padding_errors`: Padding errors style (NotRequired[StyleType])
- `style_aborted`: Aborted style (NotRequired[StyleType])
- `style_padding_usage`: Padding usage style (NotRequired[StyleType])
- `style_padding_helptext`: Padding help text style (NotRequired[StyleType])
- `style_padding_epilog`: Padding epilog style (NotRequired[StyleType])
- `panel_title_padding`: Panel title padding (NotRequired[int])
- `width`: Width (NotRequired[Optional[int]])
- `max_width`: Maximum width (NotRequired[Optional[int]])
- `color_system`: Color system (NotRequired[Optional[Literal["auto", "standard", "256", "truecolor", "windows"]]])
- `force_terminal`: Force terminal (NotRequired[Optional[bool]])
- `options_table_column_types`: Options table column types (NotRequired[List[OptionColumnType]])
- `commands_table_column_types`: Commands table column types (NotRequired[List[CommandColumnType]])
- `options_table_help_sections`: Options table help sections (NotRequired[List[OptionHelpSectionType]])
- `commands_table_help_sections`: Commands table help sections (NotRequired[List[CommandHelpSectionType]])
- `header_text`: Header text (NotRequired[Optional[Union[str, Text]]])
- `footer_text`: Footer text (NotRequired[Optional[Union[str, Text]]])
- `panel_title_string`: Panel title string (NotRequired[str])
- `deprecated_string`: Deprecated string (NotRequired[str])
- `deprecated_with_reason_string`: Deprecated with reason string (NotRequired[str])
- `default_string`: Default string (NotRequired[str])
- `envvar_string`: Environment variable string (NotRequired[str])
- `required_short_string`: Required short string (NotRequired[str])
- `required_long_string`: Required long string (NotRequired[str])
- `range_string`: Range string (NotRequired[str])
- `append_metavars_help_string`: Append metavars help string (NotRequired[str])
- `append_range_help_string`: Append range help string (NotRequired[str])
- `helptext_aliases_string`: Help text aliases string (NotRequired[str])
- `arguments_panel_title`: Arguments panel title (NotRequired[str])
- `options_panel_title`: Options panel title (NotRequired[str])
- `commands_panel_title`: Commands panel title (NotRequired[str])
- `errors_panel_title`: Errors panel title (NotRequired[str])
- `delimiter_comma`: Delimiter comma (NotRequired[str])
- `delimiter_slash`: Delimiter slash (NotRequired[str])
- `errors_suggestion`: Errors suggestion (NotRequired[Optional[Union[str, Text]]])
- `errors_epilogue`: Errors epilogue (NotRequired[Optional[Union[str, Text]]])
- `aborted_text`: Aborted text (NotRequired[str])
- `padding_header_text`: Padding header text (NotRequired[PaddingDimensions])
- `padding_helptext`: Padding help text (NotRequired[PaddingDimensions])
- `padding_helptext_deprecated`: Padding help text deprecated (NotRequired[PaddingDimensions])
- `padding_helptext_first_line`: Padding help text first line (NotRequired[PaddingDimensions])
- `padding_usage`: Padding usage (NotRequired[PaddingDimensions])
- `padding_epilog`: Padding epilog (NotRequired[PaddingDimensions])
- `padding_footer_text`: Padding footer text (NotRequired[PaddingDimensions])
- `padding_errors_panel`: Padding errors panel (NotRequired[PaddingDimensions])
- `padding_errors_suggestion`: Padding errors suggestion (NotRequired[PaddingDimensions])
- `padding_errors_epilogue`: Padding errors epilogue (NotRequired[PaddingDimensions])
- `show_arguments`: Show arguments (NotRequired[Optional[bool]])
- `show_metavars_column`: Show metavars column (NotRequired[Optional[bool]])
- `commands_before_options`: Commands before options (NotRequired[bool])
- `append_metavars_help`: Append metavars help (NotRequired[Optional[bool]])
- `group_arguments_options`: Group arguments options (NotRequired[bool])
- `option_envvar_first`: Option environment variable first (NotRequired[Optional[bool]])
- `text_markup`: Text markup (NotRequired[Literal["ansi", "rich", "markdown", None]])
- `text_kwargs`: Text kwargs (NotRequired[Optional[Dict[str, Any]]])
- `text_emojis`: Text emojis (NotRequired[bool])
- `text_paragraph_linebreaks`: Text paragraph linebreaks (NotRequired[Optional[Literal["\n", "\n\n"]]])
- `use_markdown`: Use markdown (NotRequired[Optional[bool]])
- `use_markdown_emoji`: Use markdown emoji (NotRequired[Optional[bool]])
- `use_rich_markup`: Use rich markup (NotRequired[Optional[bool]])
- `command_groups`: Command groups (NotRequired[Dict[str, List[CommandGroupDict]]])
- `option_groups`: Option groups (NotRequired[Dict[str, List[OptionGroupDict]]])
- `use_click_short_help`: Use click short help (NotRequired[bool])
- `helptext_show_aliases`: Help text show aliases (NotRequired[bool])
- `highlighter_patterns`: Highlighter patterns (NotRequired[List[str]])
- `legacy_windows`: Legacy windows (NotRequired[Optional[bool]])


#### 5. CommandGroupDict Class - Command Group Type Definition

**Function**: TypedDict defining the structure for command group configurations.
```python
from rich_click.utils import CommandGroupDict

class CommandGroupDict(TypedDict):
    """Typed dict for command_groups() kwargs."""
```

**Structure**: Dictionary with keys for command grouping metadata.

**Keys**:
- `name`: Group name (NotRequired[str])
- `commands`: List of command names (NotRequired[List[str]])
- `help`: Group help text (NotRequired[Optional[str]])
- `help_style`: Help text style (NotRequired[Optional[StyleType]])
- `table_styles`: Table styling options (NotRequired[Optional[Dict[str, Any]]])
- `panel_styles`: Panel styling options (NotRequired[Optional[Dict[str, Any]]])
- `column_types`: Column type specifications (NotRequired[Optional[List[CommandColumnType]]])
- `inline_help_in_title`: Inline help in title (NotRequired[Optional[bool]])
- `title_style`: Title style (NotRequired[Optional[StyleType]])
- `deduplicate`: Deduplicate commands (NotRequired[bool])


#### 6. OptionGroupDict Class - Option Group Type Definition

**Function**: TypedDict defining the structure for option group configurations.
```python
from rich_click.utils import OptionGroupDict

class OptionGroupDict(TypedDict):
    """Typed dict for option_groups() kwargs."""
```

**Structure**: Dictionary with keys for option grouping metadata.

**Keys**:
- `name`: Group name (NotRequired[str])
- `options`: List of option names (NotRequired[List[str]])
- `help`: Group help text (NotRequired[Optional[str]])
- `help_style`: Help text style (NotRequired[Optional[StyleType]])
- `table_styles`: Table styling options (NotRequired[Optional[Dict[str, Any]]])
- `panel_styles`: Panel styling options (NotRequired[Optional[Dict[str, Any]]])
- `column_types`: Column type specifications (NotRequired[Optional[List[OptionColumnType]]])
- `inline_help_in_title`: Inline help in title (NotRequired[Optional[bool]])
- `title_style`: Title style (NotRequired[Optional[StyleType]])
- `deduplicate`: Deduplicate options (NotRequired[bool])


### Type Aliases

#### 1. OptionColumnType - Option Column Type Alias

**Function**: Type alias defining the available column types for option tables.

**Definition**:

```python
from rich_click.rich_help_configuration import OptionColumnType

OptionColumnType = Literal[
    'required', 'opt_primary', 'opt_secondary', 'opt_long', 'opt_short', 
    'opt_all', 'opt_all_metavar', 'opt_long_metavar', 'metavar', 
    'metavar_short', 'help'
]
```

#### 2. CommandColumnType - Command Column Type Alias

**Function**: Type alias defining the available column types for command tables.

**Definition**:

```python
from rich_click.rich_help_configuration import CommandColumnType

CommandColumnType = Literal['name', 'aliases', 'name_with_aliases', 'help']
```

#### 3. OptionHelpSectionType - Option Help Section Type Alias

**Function**: Type alias defining the available help section types for options.

**Definition**:

```python
from rich_click.rich_help_configuration import OptionHelpSectionType

OptionHelpSectionType = Literal[
    'help', 'required', 'envvar', 'default', 'range', 
    'metavar', 'metavar_short', 'deprecated'
]
```

#### 4. CommandHelpSectionType - Command Help Section Type Alias

**Function**: Type alias defining the available help section types for commands.

**Definition**:

```python
from rich_click.rich_help_configuration import CommandHelpSectionType

CommandHelpSectionType = Literal['aliases', 'help', 'deprecated']
```

#### 5. ColumnType - Generic Column Type Alias

**Function**: Union type alias for all column types.

**Definition**:

```python
from rich_click.rich_help_configuration import ColumnType

ColumnType = Union[OptionColumnType, CommandColumnType, str]
```

#### 6. RichPanelRow - Panel Row Type Alias

**Function**: Type alias for Rich panel row representation.

**Definition**:

```python
from rich_click.rich_help_rendering import RichPanelRow

RichPanelRow = List[Optional[RenderableType]]
```

#### 7. ThemeType - Theme Type Alias

**Function**: Type alias defining available theme types.

**Definition**:

```python
from rich_click.rich_help_rendering import ThemeType

ThemeType = Literal['color', 'format', 'combined']
```

#### 8. StyleType - Style Type Alias

**Function**: Type alias for Rich style strings.

**Definition**:

```python
'''filepath: src/rich_click/decorators.pyi'''
StyleType = str
```

#### 9. _AnyCallable - Generic Callable Type Alias

**Function**: Type alias for any callable function.

**Definition**:

```python
_AnyCallable = Callable[..., Any]
```

