        hit_rate = self.hit_count / total if total > 0 else 0
        return {
            "hits": self.hit_count,
            "misses": self.miss_count, 
            "hit_rate": hit_rate
        }

# Execute the performance tests
print("=== Rich-Click Performance Test ===")

# Test large help rendering
help_output = test_large_help_rendering()
print(f"Help text length: {len(help_output)} characters")

# Test configuration creation
configs = test_config_creation()
print(f"Number of configurations created: {len(configs)}")

# Test cache performance
cache = ConfigCache()
for i in range(1000):
    style = f"style_{i % 10}"  # Reuse 10 styles
    config = cache.get_config(style)

stats = cache.get_stats()
print(f"Cache statistics: {stats}")
```

**Expected output**: Display detailed performance indicators, including rendering time, memory usage, and cache efficiency statistics.

### Node 22: Error Recovery and Fault Tolerance (Error Recovery and Fault Tolerance)

**Function description**: Provides a robust error recovery mechanism, ensuring normal operation even in the case of configuration errors or environmental exceptions.

**Fault tolerance strategies**:

- Configuration degradation: Use default values when the configuration is invalid.
- Style fallback: Alternative solutions when styles are not supported.
- Rendering fallback: Plain text output when rendering fails.

**Input and output example**:

```python
import rich_click as click
from rich_click import RichHelpConfiguration
import logging

# Configure logging
logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)

# Fault-tolerant configuration class
class FaultTolerantConfig(RichHelpConfiguration):
    def __init__(self, **kwargs):
        try:
            super().__init__(**kwargs)
        except Exception as e:
            logger.warning(f"Configuration initialization failed, using default configuration: {e}")
            # Use the default configuration
            super().__init__()
    
    def __getattribute__(self, name):
        try:
            return super().__getattribute__(name)
        except AttributeError:
            logger.warning(f"Configuration attribute {name} does not exist, returning default value")
            return ""  # Return a safe default value

# Fault-tolerant rendering function
def safe_render_help(command, ctx=None):
    """Safe help rendering function with error recovery"""
    try:
        if ctx is None:
            ctx = click.Context(command)
        return command.get_help(ctx)
    except Exception as e:
        logger.error(f"Rich rendering failed: {e}")
        # Degrade to plain text mode
        try:
            import click
            formatter = click.HelpFormatter()
            command.format_help(ctx, formatter)
            return formatter.getvalue()
        except Exception as fallback_error:
            logger.error(f"Plain text rendering also failed: {fallback_error}")
            return f"Help text rendering failed: {command.name}"

# Test error scenarios
@click.command()
@click.option("--input", help="Input file")
def test_command(input: str) -> None:
    """Test error recovery function"""
    pass

# Simulate various error scenarios
def test_error_scenarios():
    print("=== Error Recovery Test ===")
    
    # 1. Invalid configuration test
    try:
        invalid_config = FaultTolerantConfig(
            invalid_option="invalid_value",  # Invalid option
            style_option=123,  # Wrong type
            width="not_a_number"  # Wrong type
        )
        print(f"Invalid configuration handled successfully: {invalid_config.style_option}")
    except Exception as e:
        print(f"Invalid configuration handling failed: {e}")
    
    # 2. Rendering error recovery
    try:
        # Simulate a rendering environment problem
        import os
        old_term = os.environ.get("TERM")
        os.environ["TERM"] = "unknown"  # Unsupported terminal type
        
        help_text = safe_render_help(test_command)
        print(f"Error recovery rendering successful, length: {len(help_text)}")
        
        # Restore the environment
        if old_term:
            os.environ["TERM"] = old_term
        else:
            del os.environ["TERM"]
            
    except Exception as e:
        print(f"Error recovery test failed: {e}")
    
    # 3. Configuration conflict handling
    try:
        # Simulate a configuration conflict
        conflicting_config = {
            "width": 100,
            "max_width": 50,  # max_width < width, logical conflict
            "style_option": None,  # Null value
        }
        
        config = FaultTolerantConfig(**conflicting_config)
        # Check configuration self-repair
        effective_width = min(config.width or 80, config.max_width or 100)
        print(f"Configuration conflict automatically resolved: Effective width {effective_width}")
        
    except Exception as e:
        print(f"Configuration conflict handling failed: {e}")

# Execute the error recovery test
test_error_scenarios()

# Robustness test command
@click.command()
@rich_click.rich_config(help_config=FaultTolerantConfig(
    style_option="invalid_color",  # Invalid color
    width=-1,  # Invalid width
))
def robust_command() -> None:
    """Robustness test command"""
    pass

try:
    result = safe_render_help(robust_command)
    print("Robustness test passed")
except Exception as e:
    print(f"Robustness test failed: {e}")
```

**Expected output**: Demonstrate the recovery mechanism in various error scenarios, ensuring that the application can still provide basic functions in abnormal situations.