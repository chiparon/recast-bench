# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class RichParameter:

    def __init__(self, *args: Any, panel: Optional[Union[str, List[str]]]=..., help: Optional[str]=..., help_style: Optional['StyleType']=..., **kwargs: Any):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_info_dict(self) -> dict[str, Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_rich_help(self, ctx: 'RichContext', formatter: 'RichHelpFormatter') -> 'Columns':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_rich_table_row(self, ctx: 'RichContext', formatter: 'RichHelpFormatter', panel: Optional['RichOptionPanel']=...) -> 'RichPanelRow':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class RichArgument:
    pass

class RichOption:
    pass
