# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
_AnyCallable = ...
F = ...
FC = ...
C = ...
G = ...

def group(name: _AnyCallable) -> RichGroup:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def group(name: Optional[str], cls: Type[G], **attrs: Any) -> Callable[[_AnyCallable], G]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def group(name: None=..., *, cls: Type[G], **attrs: Any) -> Callable[[_AnyCallable], G]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def group(name: Optional[str]=..., cls: None=..., **attrs: Any) -> Callable[[_AnyCallable], RichGroup]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def group(name: Union[str, _AnyCallable, None]=..., cls: Optional[Type[G]]=..., **attrs: Any) -> Union[Group, Callable[[_AnyCallable], Union[RichGroup, G]]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
CmdType = ...

def command(name: _AnyCallable) -> RichCommand:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def command(name: Optional[str], cls: Type[CmdType], **attrs: Any) -> Callable[[_AnyCallable], CmdType]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def command(name: None=..., *, cls: Type[CmdType], **attrs: Any) -> Callable[[_AnyCallable], CmdType]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def command(name: Optional[str]=..., cls: None=..., **attrs: Any) -> Callable[[_AnyCallable], RichCommand]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def command(name: Union[Optional[str], _AnyCallable]=..., cls: Optional[Type[CmdType]]=..., **attrs: Any) -> Union[Command, Callable[[_AnyCallable], Union[RichCommand, CmdType]]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _context_settings_memo(f: Callable[..., Any], extra: Dict[str, Any]) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _rich_panel_memo(f: Callable[..., Any], panel: RichPanel[Any, Any]) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def rich_config(help_config: Optional[Union[Dict[str, Any], RichHelpConfiguration]]=..., *, console: Optional['Console']=...) -> Callable[[FC], FC]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _panel(name: str, cls: Type[RichPanel[Any, Any]], **attrs: Any) -> Callable[[FC], FC]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def option_panel(name: str, cls: Type[RichPanel[Parameter, Any]]=..., **attrs: Any) -> Callable[[FC], FC]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def command_panel(name: str, cls: Type[RichPanel[Command, Any]]=..., **attrs: Any) -> Callable[[FC], FC]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
P = ...
R = ...

def pass_context(f: Callable[Concatenate[RichContext, P], R]) -> Callable[P, R]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def help_option(*param_decls: str, **kwargs: Any) -> Callable[[FC], FC]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def argument(*param_decls: str, cls: Optional[Type[Argument]]=..., **attrs: Any) -> Callable[[FC], FC]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def option(*param_decls: str, cls: Optional[Type[Option]]=..., **attrs: Any) -> Callable[[FC], FC]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def confirmation_option(*param_decls: str, **kwargs: Any) -> Callable[[FC], FC]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def password_option(*param_decls: str, **kwargs: Any) -> Callable[[FC], FC]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def version_option(version: Optional[str]=..., *param_decls: str, package_name: Optional[str]=..., prog_name: Optional[str]=..., message: Optional[str]=..., **kwargs: Any) -> Callable[[FC], FC]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
__all__ = ...
