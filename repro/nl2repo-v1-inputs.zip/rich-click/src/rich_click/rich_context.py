# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class RichContext:
    formatter_class = ...
    console = ...
    export_console_as = ...
    errors_in_output_format = ...
    help_to_stderr = ...

    def __init__(self, *args: Any, rich_console: Optional['Console']=..., rich_help_config: Optional[Union[Mapping[str, Any], RichHelpConfiguration]]=..., export_console_as: Optional[Literal['html', 'svg', 'text']]=..., errors_in_output_format: Optional[bool]=..., help_to_stderr: Optional[bool]=..., **kwargs: Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def make_formatter(self, error_mode: bool=...) -> RichHelpFormatter:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __enter__(self) -> 'RichContext':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc_value: Optional[BaseException], tb: Optional[TracebackType]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def get_current_context(silent: bool=...) -> Optional[RichContext]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
