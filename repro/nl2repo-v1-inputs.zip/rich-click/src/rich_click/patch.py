# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
__TyperGroup = ...
__TyperCommand = ...
__TyperArgument = ...
__TyperOption = ...

class _PatchedTyperContext:

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def make_formatter(self, error_mode: bool=...) -> RichHelpFormatter:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_help(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def _typer_command_init(self: Any, *args: Any, rich_help_panel: Union[str, None]=..., rich_markup_mode: Any=..., **kwargs: Any) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _typer_group_init(self: Any, *args: Any, rich_help_panel: Union[str, None]=..., rich_markup_mode: Any=..., **kwargs: Any) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _patch_typer_group(cls: Type[Group]) -> Type[Group]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _patch_typer_command(cls: Type[Command]) -> Type[Command]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _patch_typer_argument(cls: Type[Argument]) -> Type[Argument]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _patch_typer_option(cls: Type[Option]) -> Type[Option]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class PatchMeta:

    def __init__(cls, name: str, bases: Tuple[type, ...], namespace: Dict[str, Any]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class _PatchedRichCommand:
    pass

class _PatchedRichMultiCommand:
    pass

class _PatchedRichCommandCollection:
    pass

class _PatchedRichGroup:
    pass

class _PatchedOption:
    pass

class _PatchedArgument:
    pass

def rich_command(*args, **kwargs):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def rich_group(*args, **kwargs):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def patch(rich_config: Optional[RichHelpConfiguration]=..., *, patch_rich_click: bool=..., patch_typer: bool=...) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def patch_typer(rich_config: Optional[RichHelpConfiguration]=...) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
__all__ = ...
