# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
RP = ...

def create_console(config: RichHelpConfiguration, file: Optional[IO[str]]=..., width: Optional[int]=..., max_width: Optional[int]=...) -> 'Console':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class RichHelpFormatter:
    console = ...
    export_console_as = ...
    option_panel_class = ...
    command_panel_class = ...

    def __init__(self, indent_increment: int=..., width: Optional[int]=..., max_width: Optional[int]=..., *args: Any, console: Optional['Console']=..., config: Optional[RichHelpConfiguration]=..., export_console_as: Literal[None, 'html', 'svg', 'text']=..., export_kwargs: Optional[Dict[str, Any]]=..., **kwargs: Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def width(self) -> int:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def width(self, v: int) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def highlighter(self) -> 'Highlighter':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write(self, *objects: Any, **kwargs: Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write_usage(self, prog: str, args: str=..., prefix: Optional[str]=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write_error(self, e: click.ClickException) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write_abort(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def rich_text(self, text: Union[str, 'Text', 'Markdown'], style: 'StyleType'=...) -> Union['Text', 'Markdown']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getvalue(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def indent(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dedent(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write_heading(self, heading: str) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write_paragraph(self) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write_text(self, text: str) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write_dl(self, rows: Sequence[Tuple[str, str]], col_max: int=..., col_spacing: int=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def section(self, name: str) -> Iterator[None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def indentation(self) -> Iterator[None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
