# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
DISABLE_WARNINGS_NOTE = ...

def entry_points(*, group: str) -> 'metadata.EntryPoints':
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def patch(*args: Any, **kwargs: Any) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class _RichHelpConfigurationParamType:
    name = ...

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def convert(self, value: Optional[str], param: Optional[click.Parameter], ctx: Optional[click.Context]) -> Optional[Dict[str, Any]]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_module_path_and_function_name(script: str, suppress_warnings: bool) -> Tuple[str, str]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def list_themes(ctx: RichContext, param: click.Parameter, value: bool) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def main(ctx: RichContext, script_and_args: Tuple[str, ...], theme: str, output: Literal[None, 'html', 'svg'], errors_in_output_format: bool, suppress_warnings: bool, patch_rich_click: bool, rich_config: Optional[Dict[str, Any]], show_help: bool) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
