# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
__version__ = ...

def __getattr__(name: str) -> object:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
