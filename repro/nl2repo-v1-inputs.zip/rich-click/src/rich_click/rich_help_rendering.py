# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
RichPanelRow = ...

class RichClickRichPanel:

    def __init__(self, *args: Any, title_padding: int=..., **kwargs: Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _title(self) -> Optional[Text]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_help_text(obj: Union[Command, Group], formatter: RichHelpFormatter) -> Iterable[Union[Padding, 'Markdown', Text]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_deprecated_text(deprecated: Union[bool, str], formatter: RichHelpFormatter) -> Text:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_parameter_env_var(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter) -> Optional[Text]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_parameter_deprecated(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter) -> Optional[Text]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_parameter_help(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter) -> Optional[Union['Markdown', Text]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_parameter_range(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter, mode: Literal['metavar_append']) -> Optional[str]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_parameter_range(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter, mode: Literal['metavar_column', 'help']) -> Optional[Text]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_parameter_range(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter, mode: Literal['metavar_append', 'metavar_column', 'help']) -> Optional[Union[Text, str]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_parameter_metavar(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter, append: bool=..., show_range: bool=...) -> Optional[Text]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_parameter_help_metavar_col(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter, show_range: bool=...) -> Optional[Text]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_parameter_help_opt(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter) -> Tuple[Optional[Text], Optional[Text], Optional[Text], Optional[Text], Optional[Text]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_parameter_default(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter) -> Optional[Text]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_parameter_required(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter) -> Optional[Text]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_parameter_help_required_short(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter) -> Optional[Text]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def get_help_parameter(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter) -> Columns:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def get_parameter_rich_table_row(param: Union[click.Argument, click.Option, RichParameter], ctx: RichContext, formatter: RichHelpFormatter, panel: Optional['RichOptionPanel']) -> RichPanelRow:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_command_name_help(command: click.Command, ctx: RichContext, formatter: RichHelpFormatter) -> Text:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_command_aliases_help(command: click.Command, ctx: RichContext, formatter: RichHelpFormatter, include_name: bool=...) -> Optional[Text]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def get_command_rich_table_row(command: click.Command, ctx: RichContext, formatter: RichHelpFormatter, panel: Optional['RichCommandPanel']) -> RichPanelRow:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_command_help(command: click.Command, ctx: RichContext, formatter: RichHelpFormatter) -> Union[Text, 'Markdown', Columns]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def get_rich_usage(formatter: RichHelpFormatter, prog: str, args: str=..., prefix: Optional[str]=...) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def get_rich_help_text(self: Command, ctx: RichContext, formatter: RichHelpFormatter) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def get_rich_epilog(self: Command, ctx: RichContext, formatter: RichHelpFormatter) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def rich_format_error(self: click.ClickException, formatter: RichHelpFormatter, export_console_as: Literal[None, 'html', 'svg']=...) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
