# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
OVERRIDES_GUARD = ...

class RichCommand:
    context_class = ...
    _formatter = ...

    def __init__(self, *args: Any, aliases: Optional[Iterable[str]]=..., panels: Optional[List['RichPanel[Any, Any]']]=..., panel: Optional[Union[str, List[str]]]=..., **kwargs: Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def console(self) -> Optional['Console']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_info_dict(self, ctx: click.Context) -> Dict[str, Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def help_config(self) -> Optional[RichHelpConfiguration]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _generate_rich_help_config(self) -> RichHelpConfiguration:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _error_formatter(self) -> RichHelpFormatter:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def main(self, args: Sequence[str] | None=..., prog_name: str | None=..., complete_var: str | None=..., standalone_mode: Literal[True]=..., **extra: Any) -> NoReturn:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def main(self, args: Sequence[str] | None=..., prog_name: str | None=..., complete_var: str | None=..., standalone_mode: bool=..., **extra: Any) -> Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def main(self, args: Optional[Sequence[str]]=..., prog_name: Optional[str]=..., complete_var: Optional[str]=..., standalone_mode: bool=..., windows_expand_args: bool=..., **extra: Any) -> Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def format_help(self, ctx: RichContext, formatter: RichHelpFormatter) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def format_help_text(self, ctx: RichContext, formatter: RichHelpFormatter) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def format_options(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def format_epilog(self, ctx: RichContext, formatter: RichHelpFormatter) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_help_option(self, ctx: click.Context) -> Union[click.Option, None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_rich_table_row(self, ctx: 'RichContext', formatter: 'RichHelpFormatter', panel: Optional['RichCommandPanel']=...) -> 'RichPanelRow':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add_panel(self, panel: 'RichPanel[Any, Any]') -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class RichGroup:
    command_class = ...
    group_class = ...

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def format_commands(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def format_help(self, ctx: RichContext, formatter: RichHelpFormatter) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def command(self, __func: Callable[..., Any]) -> RichCommand:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def command(self, *args: Any, **kwargs: Any) -> Callable[[Callable[..., Any]], RichCommand]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def command(self, *args: Any, **kwargs: Any) -> Union[Callable[[Callable[..., Any]], RichCommand], RichCommand]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def group(self, __func: Callable[..., Any]) -> 'RichGroup':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def group(self, *args: Any, **kwargs: Any) -> Callable[[Callable[..., Any]], 'RichGroup']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def group(self, *args: Any, **kwargs: Any) -> Union[Callable[[Callable[..., Any]], 'RichGroup'], 'RichGroup']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _handle_extras_add_command(self, cmd: click.Command, name: Optional[str]=..., aliases: Optional[Iterable[str]]=..., panel: Optional[Union[str, List[str]]]=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_command(self, ctx: click.Context, cmd_name: str) -> Optional[click.Command]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add_command(self, cmd: click.Command, name: Optional[str]=..., aliases: Optional[Iterable[str]]=..., panel: Optional[Union[str, List[str]]]=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add_command_to_panel(self, command: click.Command, panel_name: Union[str, Iterable[str]]) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')
RichMultiCommand = ...

class RichCommandCollection:

    def format_help(self, ctx: RichContext, formatter: RichHelpFormatter) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def prevent_incompatible_overrides(cmd: RichCommand, class_name: str, ctx: RichContext, formatter: RichHelpFormatter) -> None:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
