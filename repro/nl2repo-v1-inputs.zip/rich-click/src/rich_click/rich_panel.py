# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
ColT = ...
CT = ...
GroupType = ...

class RichPanel:
    panel_class = ...
    table_class = ...
    _highlight = ...
    _object_attr = ...

    def __init__(self, name: str, *, help: Optional[str]=..., help_style: Optional['StyleType']=..., table_styles: Optional[Dict[str, Any]]=..., panel_styles: Optional[Dict[str, Any]]=..., column_types: Optional[List[ColT]]=..., inline_help_in_title: Optional[bool]=..., title_style: Optional['StyleType']=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def objects(self) -> List[str]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add_object(self, o: str) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_box(self, box: Optional[Union[str, 'Box']]) -> Optional['Box']:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_info_dict(self, ctx: Context) -> Dict[str, Any]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def list_all_objects(cls, ctx: Context) -> List[Tuple[str, CT]]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_objects(self, command: Command, ctx: Context) -> Generator[CT, None, None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_base_table(self, **defaults: Any) -> 'Table':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_table(self, command: 'RichCommand', ctx: 'RichContext', formatter: 'RichHelpFormatter') -> 'Table':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_base_panel(self, table: 'Table', **defaults: Any) -> 'Panel':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def render(self, command: 'RichCommand', ctx: 'RichContext', formatter: 'RichHelpFormatter') -> 'Panel':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class RichOptionPanel:
    _highlight = ...
    _object_attr = ...

    def __init__(self, name: str, options: Optional[List[str]]=..., **kwargs: Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def list_all_objects(cls, ctx: Context) -> List[Tuple[str, Parameter]]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_objects(self, command: Command, ctx: Context) -> Generator[Parameter, None, None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_table(self, command: 'RichCommand', ctx: 'RichContext', formatter: 'RichHelpFormatter') -> 'Table':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def render(self, command: 'RichCommand', ctx: 'RichContext', formatter: 'RichHelpFormatter') -> 'Panel':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class RichCommandPanel:
    _object_attr = ...

    def __init__(self, name: str, commands: Optional[List[str]]=..., **kwargs: Any) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def list_all_objects(cls, ctx: Context) -> List[Tuple[str, Command]]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_objects(self, command: Command, ctx: Context) -> Generator[Command, None, None]:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_table(self, command: 'RichCommand', ctx: 'RichContext', formatter: 'RichHelpFormatter') -> 'Table':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def render(self, command: 'RichCommand', ctx: 'RichContext', formatter: 'RichHelpFormatter') -> 'Panel':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def _resolve_panels_from_config(ctx: 'RichContext', formatter: 'RichHelpFormatter', groups: Dict[str, List[GroupType]], panel_cls: Type[RichPanel[CT, ColT]]) -> List[RichPanel[CT, ColT]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def construct_panels(command: 'RichCommand', ctx: 'RichContext', formatter: 'RichHelpFormatter') -> List[RichPanel[Any, Any]]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
