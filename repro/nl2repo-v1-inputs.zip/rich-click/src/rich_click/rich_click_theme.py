# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
ThemeType = ...

class RichClickTheme:

    def __init__(self, name: str, *, description: Optional[str]=..., hidden: bool=..., styles: Optional[Dict[str, Any]]=..., primary_colors: Optional[List['StyleType']]=..., post_combine_callback: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]]=...) -> None:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self) -> str:
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def combine(self, other: 'RichClickTheme') -> 'RichClickTheme':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __add__(self, other: 'RichClickTheme') -> 'RichClickTheme':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __radd__(self, other: 'RichClickTheme') -> 'RichClickTheme':
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def _spaced_delimiters_callback(d: Dict[str, Any]) -> Dict[str, Any]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _not_dim_title_callback(d: Dict[str, Any]) -> Dict[str, Any]:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
COLORS = ...
FORMATS = ...
_THEME_CACHE = ...

class RichClickThemeNotFound:
    pass

def get_theme(theme: str, raise_key_error: bool=...) -> RichClickTheme:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
