# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
NO_DEFAULT = ...
NO_DEFAULT = ...

def inspect_formatargspec(args, varargs=..., varkw=..., defaults=..., kwonlyargs=..., kwonlydefaults=..., annotations=..., formatarg=..., formatvarargs=..., formatvarkw=..., formatvalue=..., formatreturns=..., formatannotation=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def get_module_callables(mod, ignore=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def mro_items(type_obj):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def dir_dict(obj, raise_exc=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def copy_function(orig, copy_dict=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def partial_ordering(cls):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class InstancePartial:

    def _partialmethod(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __partialmethod__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __get__(self, obj, obj_type):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class CachedInstancePartial:

    def _partialmethod(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __partialmethod__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __set_name__(self, obj_type, name):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __get__(self, obj, obj_type):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
partial = ...

def format_invocation(name=..., args=..., kwargs=..., **kw):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def format_exp_repr(obj, pos_names, req_names=..., opt_names=..., opt_key=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def format_nonexp_repr(obj, req_names=..., opt_names=..., opt_key=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def wraps(func, injected=..., expected=..., **kw):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def update_wrapper(wrapper, func, injected=..., expected=..., build_from=..., **kw):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _parse_wraps_expected(expected):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class FunctionBuilder:
    _argspec_defaults = ...

    def _argspec_to_dict(cls, f):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    _defaults = ...
    _compile_count = ...

    def __init__(self, name, **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_sig_str(self, with_annotations=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    _KWONLY_MARKER = ...

    def get_invocation_str(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_func(cls, func):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_func(self, execdict=..., add_source=..., with_dict=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_defaults_dict(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_arg_names(self, only_required=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add_arg(self, arg_name, default=..., kwonly=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def remove_arg(self, arg_name):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _compile(self, src, execdict):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class MissingArgument:
    pass

class ExistingArgument:
    pass

def _indent(text, margin, newline=..., key=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def noop(*args, **kwargs):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
