# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
_issubclass = ...

def make_sentinel(name=..., var_name=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def issubclass(subclass, baseclass):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def get_all_subclasses(cls):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class classproperty:

    def __init__(self, fn):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __get__(self, instance, cls):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
