# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
_MISSING = ...
_MISSING = ...
__all__ = ...

class BarrelList:
    _size_factor = ...

    def __init__(self, iterable=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _cur_size_limit(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _translate_index(self, index):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _balance_list(self, list_idx):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def insert(self, index, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def append(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def extend(self, iterable):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pop(self, *a):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def iter_slice(self, start, stop, step=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def del_slice(self, start, stop, step=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __delslice__ = ...

    def from_iterable(cls, it):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __reversed__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __contains__(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, index):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __delitem__(self, index):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __setitem__(self, index, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getslice__(self, start, stop):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __setslice__(self, start, stop, sequence):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def sort(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def reverse(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def count(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def index(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
BList = ...

class SplayList:

    def shift(self, item_index, dest_index=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def swap(self, item_index, dest_index):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
