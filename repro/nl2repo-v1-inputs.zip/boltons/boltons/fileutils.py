# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
__all__ = ...
FULL_PERMS = ...
RW_PERMS = ...
_SINGLE_FULL_PERM = ...

def mkdir_p(path):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class FilePerms:

    class _FilePermProperty:
        _perm_chars = ...
        _perm_set = ...
        _perm_val = ...

        def __init__(self, attribute, offset):
            raise NotImplementedError('NL2Repo skeleton: implement this API')

        def __get__(self, fp_obj, type_=...):
            raise NotImplementedError('NL2Repo skeleton: implement this API')

        def __set__(self, fp_obj, value):
            raise NotImplementedError('NL2Repo skeleton: implement this API')

        def _update_integer(self, fp_obj, value):
            raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __init__(self, user=..., group=..., other=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_int(cls, i):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_path(cls, path):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __int__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    user = ...
    group = ...
    other = ...

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
_TEXT_OPENFLAGS = ...
_BIN_OPENFLAGS = ...

def set_cloexec(fd):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def set_cloexec(fd):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def atomic_save(dest_path, **kwargs):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def path_to_unicode(path):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_ReplaceFile = ...
_ReplaceFile = ...

def replace(src, dst):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def atomic_rename(src, dst, overwrite=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def replace(src, dst):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def atomic_rename(src, dst, overwrite=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_atomic_rename = ...
replace = ...

class AtomicSaver:
    _default_file_perms = ...

    def __init__(self, dest_path, **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _open_part_file(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def setup(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __enter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __exit__(self, exc_type, exc_val, exc_tb):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def iter_find_files(directory, patterns, ignored=..., include_dirs=..., max_depth=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def copy_tree(src, dst, symlinks=..., ignore=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
copytree = ...

class DummyFile:

    def __init__(self, path, mode=..., buffering=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def close(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def fileno(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def flush(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def next(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def read(self, size=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def readline(self, size=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def readlines(self, size=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def seek(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def tell(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def truncate(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write(self, string):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def writelines(self, list_of_strings):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __next__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __enter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __exit__(self, exc_type, exc_val, exc_tb):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def rotate_file(filename, *, keep: int=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
