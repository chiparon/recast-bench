# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
_UNRESERVED_CHARS = ...
_URL_RE = ...
_HEX_CHAR_MAP = ...
_ASCII_RE = ...
SCHEME_PORT_MAP = ...
NO_NETLOC_SCHEMES = ...
_GEN_DELIMS = ...
_SUB_DELIMS = ...
_ALL_DELIMS = ...
_USERINFO_SAFE = ...
_USERINFO_DELIMS = ...
_PATH_SAFE = ...
_PATH_DELIMS = ...
_FRAGMENT_SAFE = ...
_FRAGMENT_DELIMS = ...
_QUERY_SAFE = ...
_QUERY_DELIMS = ...

class URLParseError:
    pass
DEFAULT_ENCODING = ...

def to_unicode(obj):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_FIND_ALL_URL_RE = ...

def find_all_links(text, with_text=..., default_scheme=..., schemes=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _make_quote_map(safe_chars):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_USERINFO_PART_QUOTE_MAP = ...
_PATH_PART_QUOTE_MAP = ...
_QUERY_PART_QUOTE_MAP = ...
_FRAGMENT_QUOTE_MAP = ...

def quote_path_part(text, full_quote=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def quote_query_part(text, full_quote=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def quote_fragment_part(text, full_quote=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def quote_userinfo_part(text, full_quote=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def unquote(string, encoding=..., errors=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def unquote_to_bytes(string):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def register_scheme(text, uses_netloc=..., default_port=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def resolve_path_parts(path_parts):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class cachedproperty:

    def __init__(self, func):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __get__(self, obj, objtype=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class URL:
    _cmp_attrs = ...

    def __init__(self, url=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_parts(cls, scheme=..., host=..., path_parts=..., query_params=..., fragment=..., port=..., username=..., password=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def query_params(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    qp = ...

    def path(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def path(self, path_text):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def uses_netloc(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def default_port(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def normalize(self, with_case=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def navigate(self, dest):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_authority(self, full_quote=..., with_userinfo=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_text(self, full_quote=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __unicode__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __eq__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ne__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class _sockaddr:
    _fields_ = ...
WSAStringToAddressA = ...
WSAAddressToStringA = ...

def inet_pton(address_family, ip_string):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def parse_host(host):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def parse_url(url_text):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
DEFAULT_PARSED_URL = ...

def parse_qsl(qs, keep_blank_values=..., encoding=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_MISSING = ...
_MISSING = ...
PREV = ...
NEXT = ...
KEY = ...
VALUE = ...
SPREV = ...
SNEXT = ...

class OrderedMultiDict:

    def __new__(cls, *a, **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __init__(self, *args, **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getstate__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __setstate__(self, state):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _clear_ll(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _insert(self, k, v):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add(self, k, v):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def addlist(self, k, v):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get(self, k, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getlist(self, k, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def clear(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def setdefault(self, k, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def copy(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def fromkeys(cls, keys, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def update(self, E, **F):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def update_extend(self, E, **F):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __setitem__(self, k, v):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, k):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __delitem__(self, k):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __eq__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ne__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ior__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pop(self, k, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def popall(self, k, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def poplast(self, k=..., default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _remove(self, k):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _remove_all(self, k):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def iteritems(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def iterkeys(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def itervalues(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def todict(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def sorted(self, key=..., reverse=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def sortedvalues(self, key=..., reverse=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def inverted(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def counts(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def keys(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def values(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def items(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __reversed__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def viewkeys(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def viewvalues(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def viewitems(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
OMD = ...

class QueryParamDict:

    def from_text(cls, query_string):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_text(self, full_quote=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
