# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
__all__ = ...
_punct_ws_str = ...
_punct_re = ...
_camel2under_re = ...

def camel2under(camel_string):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def under2camel(under_string):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def slugify(text, delim=..., lower=..., ascii=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def split_punct_ws(text):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def unit_len(sized_iterable, unit_noun=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_ORDINAL_MAP = ...

def ordinalize(number, ext_only=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def cardinalize(unit_noun, count):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def singularize(word):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def pluralize(word):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _match_case(master, disciple):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_IRR_S2P = ...
_IRR_P2S = ...
HASHTAG_RE = ...

def find_hashtags(string):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def a10n(string):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
ANSI_SEQUENCES = ...

def strip_ansi(text):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def asciify(text, ignore=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def is_ascii(text):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class DeaccenterDict:

    def __missing__(self, key):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
_BASE_DEACCENT_MAP = ...
DEACCENT_MAP = ...
_SIZE_SYMBOLS = ...
_SIZE_BOUNDS = ...
_SIZE_RANGES = ...

def bytes2human(nbytes, ndigits=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class HTMLTextExtractor:

    def __init__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def handle_data(self, d):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def handle_charref(self, number):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def handle_entityref(self, name):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_text(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def html2text(html):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_EMPTY_GZIP_BYTES = ...
_NON_EMPTY_GZIP_BYTES = ...

def gunzip_bytes(bytestring):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def gzip_bytes(bytestring, level=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_line_ending_re = ...

def iter_splitlines(text):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def indent(text, margin, newline=..., key=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def is_uuid(obj, version=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def escape_shell_args(args, sep=..., style=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_find_sh_unsafe = ...

def args2sh(args, sep=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def args2cmd(args, sep=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def parse_int_list(range_string, delim=..., range_delim=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def format_int_list(int_list, delim=..., range_delim=..., delim_space=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def complement_int_list(range_string, range_start=..., range_end=..., delim=..., range_delim=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def int_ranges_from_int_list(range_string, delim=..., range_delim=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class MultiReplace:

    def __init__(self, sub_map, **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_value(self, match):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def sub(self, text):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def multi_replace(text, sub_map, **kwargs):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def unwrap_text(text, ending=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def removeprefix(text: str, prefix: str) -> str:
    raise NotImplementedError('NL2Repo skeleton: implement this API')
