# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
__all__ = ...

def augpath(path, suffix=..., prefix=..., ext=..., base=..., dpath=..., multidot=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def shrinkuser(path, home=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def expandpath(path):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
