# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

def clamp(x, lower=..., upper=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def ceil(x, options=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def floor(x, options=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class Bits:
    __slots__ = ...

    def __init__(self, val=..., len_=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, k):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __eq__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __or__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __and__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __lshift__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __rshift__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __hash__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def as_list(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def as_bin(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def as_hex(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def as_int(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def as_bytes(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_list(cls, list_):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_bin(cls, bin):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_hex(cls, hex):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_int(cls, int_, len_=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_bytes(cls, bytes_):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
