# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
__all__ = ...

class Callpoint:
    __slots__ = ...

    def __init__(self, module_name, module_path, func_name, lineno, lasti, line=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_dict(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_current(cls, level=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_frame(cls, frame):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_tb(cls, tb):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def tb_frame_str(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class _DeferredLine:
    __slots__ = ...

    def __init__(self, filename, lineno, module_globals=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __eq__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ne__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TracebackInfo:
    callpoint_type = ...

    def __init__(self, frames):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_frame(cls, frame=..., level=..., limit=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_traceback(cls, tb=..., limit=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_dict(cls, d):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_dict(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_formatted(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class ExceptionInfo:
    tb_info_type = ...

    def __init__(self, exc_type, exc_msg, tb_info):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_exc_info(cls, exc_type, exc_value, traceback):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_current(cls):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_dict(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_formatted(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_formatted_exception_only(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class ContextualCallpoint:

    def __init__(self, *a, **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_frame(cls, frame):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_tb(cls, tb):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _populate_context_lines(self, pivot=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _populate_local_reprs(self, f_locals):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_dict(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class ContextualTracebackInfo:
    callpoint_type = ...

class ContextualExceptionInfo:
    tb_info_type = ...

def format_exception_only(etype, value):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _some_str(value):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _format_final_exc_line(etype, value):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def print_exception(etype, value, tb, limit=..., file=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def fix_print_exception():
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_frame_re = ...
_se_frame_re = ...
_underline_re = ...

class ParsedException:

    def __init__(self, exc_type_name, exc_msg, frames=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def source_file(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_dict(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_string(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_string(cls, tb_str):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
ParsedTB = ...
