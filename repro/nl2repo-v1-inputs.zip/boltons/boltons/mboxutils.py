# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
DEFAULT_MAXMEM = ...

class mbox_readonlydir:

    def __init__(self, path, factory=..., create=..., maxmem=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def flush(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
