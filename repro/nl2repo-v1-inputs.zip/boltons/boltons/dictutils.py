# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
_MISSING = ...
_MISSING = ...
PREV = ...
NEXT = ...
KEY = ...
VALUE = ...
SPREV = ...
SNEXT = ...
__all__ = ...

class OrderedMultiDict:

    def __new__(cls, *a, **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __init__(self, *args, **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getstate__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __setstate__(self, state):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _clear_ll(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _insert(self, k, v):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add(self, k, v):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def addlist(self, k, v):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get(self, k, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getlist(self, k, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def clear(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def setdefault(self, k, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def copy(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def fromkeys(cls, keys, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def update(self, E, **F):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def update_extend(self, E, **F):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __setitem__(self, k, v):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, k):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __delitem__(self, k):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __eq__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ne__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ior__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pop(self, k, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def popall(self, k, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def poplast(self, k=..., default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _remove(self, k):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _remove_all(self, k):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def iteritems(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def iterkeys(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def itervalues(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def todict(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def sorted(self, key=..., reverse=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def sortedvalues(self, key=..., reverse=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def inverted(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def counts(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def keys(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def values(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def items(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __reversed__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def viewkeys(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def viewvalues(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def viewitems(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
OMD = ...
MultiDict = ...

class FastIterOrderedMultiDict:

    def _clear_ll(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _insert(self, k, v):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _remove(self, k):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _remove_all(self, k):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def iteritems(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def iterkeys(self, multi=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __reversed__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
_OTO_INV_MARKER = ...
_OTO_UNIQUE_MARKER = ...

class OneToOne:
    __slots__ = ...

    def __init__(self, *a, **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def unique(cls, *a, **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __setitem__(self, key, val):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __delitem__(self, key):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def clear(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def copy(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pop(self, key, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def popitem(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def setdefault(self, key, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def update(self, dict_or_iterable, **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
_PAIRING = ...

class ManyToMany:

    def __init__(self, items=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get(self, key, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, key):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __setitem__(self, key, vals):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __delitem__(self, key):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def update(self, iterable):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add(self, key, val):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def remove(self, key, val):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def replace(self, key, newkey):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def iteritems(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def keys(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __contains__(self, key):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __eq__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def subdict(d, keep=..., drop=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class FrozenHashError:
    pass

class FrozenDict:
    __slots__ = ...

    def updated(self, *a, **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def fromkeys(cls, keys, value=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __reduce_ex__(self, protocol):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __hash__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __copy__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _raise_frozen_typeerror(self, *a, **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __ior__ = ...
    __setitem__ = ...
    __delitem__ = ...
    update = ...
    setdefault = ...
    pop = ...
    popitem = ...
    clear = ...
