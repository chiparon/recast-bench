# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class RLock:

    def __enter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __exit__(self, exctype, excinst, exctb):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
_UNSET = ...
_UNSET = ...
DEFAULT_TIMEOUT = ...
DEFAULT_MAXSIZE = ...
_RECV_LARGE_MAXSIZE = ...

class BufferedSocket:

    def __init__(self, sock, timeout=..., maxsize=..., recvsize=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def settimeout(self, timeout):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def gettimeout(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def setblocking(self, blocking):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def setmaxsize(self, maxsize):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getrecvbuffer(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getsendbuffer(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def recv(self, size, flags=..., timeout=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def peek(self, size, timeout=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def recv_close(self, timeout=..., maxsize=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def recv_until(self, delimiter, timeout=..., maxsize=..., with_delimiter=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def recv_size(self, size, timeout=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def send(self, data, flags=..., timeout=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def sendall(self, data, flags=..., timeout=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def flush(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def buffer(self, data):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getsockname(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getpeername(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getsockopt(self, level, optname, buflen=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def setsockopt(self, level, optname, value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def type(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def family(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def proto(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def fileno(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def close(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def shutdown(self, how):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Error:
    pass

class ConnectionClosed:
    pass

class MessageTooLong:

    def __init__(self, bytes_read=..., delimiter=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Timeout:

    def __init__(self, timeout, extra=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class NetstringSocket:

    def __init__(self, sock, timeout=..., maxsize=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def fileno(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def settimeout(self, timeout):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def setmaxsize(self, maxsize):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _calc_msgsize_maxsize(self, maxsize):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def read_ns(self, timeout=..., maxsize=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write_ns(self, payload):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class NetstringProtocolError:
    pass

class NetstringInvalidSize:

    def __init__(self, msg):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class NetstringMessageTooLong:

    def __init__(self, size, maxsize):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
