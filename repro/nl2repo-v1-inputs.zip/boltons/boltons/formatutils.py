# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
__all__ = ...
_pos_farg_re = ...

def construct_format_field_str(fname, fspec, conv):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def split_format_str(fstr):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def infer_positional_format_args(fstr):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_INTCHARS = ...
_FLOATCHARS = ...
_TYPE_MAP = ...
_TYPE_MAP = ...

def get_format_args(fstr):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def tokenize_format_str(fstr, resolve_pos=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class BaseFormatField:

    def __init__(self, fname, fspec=..., conv=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def set_fname(self, fname):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def set_fspec(self, fspec):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def set_conv(self, conv):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def fstr(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
_UNSET = ...

class DeferredValue:

    def __init__(self, func, cache_value=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_value(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __int__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __float__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __unicode__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __format__(self, fmt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
