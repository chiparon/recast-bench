# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
__all__ = ...

def get_all(type_obj, include_subtypes=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_IS_PYPY = ...

class GCToggler:

    def __init__(self, postcollect=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __enter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __exit__(self, exc_type, exc_val, exc_tb):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
toggle_gc = ...
toggle_gc_postcollect = ...
