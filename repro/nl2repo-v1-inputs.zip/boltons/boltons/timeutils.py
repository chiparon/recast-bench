# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
total_seconds = ...

def dt_to_timestamp(dt):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_NONDIGIT_RE = ...

def isoparse(iso_str):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_BOUNDS = ...
_BOUNDS = ...
_BOUND_DELTAS = ...
_FLOAT_PATTERN = ...
_PARSE_TD_RE = ...
_PARSE_TD_KW_MAP = ...

def parse_timedelta(text):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
parse_td = ...

def _cardinalize_time_unit(unit, value):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def decimal_relative_time(d, other=..., ndigits=..., cardinalize=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def relative_time(d, other=..., ndigits=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def strpdate(string, format):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def daterange(start, stop, step=..., inclusive=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
ZERO = ...
HOUR = ...

class ConstantTZInfo:

    def __init__(self, name=..., offset=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def utcoffset_hours(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def utcoffset(self, dt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def tzname(self, dt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dst(self, dt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
UTC = ...
EPOCH_AWARE = ...

class LocalTZInfo:
    _std_offset = ...
    _dst_offset = ...
    _dst_offset = ...

    def is_dst(self, dt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def utcoffset(self, dt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dst(self, dt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def tzname(self, dt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
LocalTZ = ...

def _first_sunday_on_or_after(dt):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
DSTSTART_2007 = ...
DSTEND_2007 = ...
DSTSTART_1987_2006 = ...
DSTEND_1987_2006 = ...
DSTSTART_1967_1986 = ...
DSTEND_1967_1986 = ...

class USTimeZone:

    def __init__(self, hours, reprname, stdname, dstname):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def tzname(self, dt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def utcoffset(self, dt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def dst(self, dt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
Eastern = ...
Central = ...
Mountain = ...
Pacific = ...
