# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
_MISSING = ...
_MISSING = ...
__all__ = ...
_COMPACTION_FACTOR = ...

class IndexedSet:

    def __init__(self, other=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _dead_index_count(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _compact(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _cull(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_real_index(self, index):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_apparent_index(self, index):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _add_dead(self, start, stop=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __contains__(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __reversed__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __eq__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_iterable(cls, it):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def remove(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def discard(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def clear(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def isdisjoint(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def issubset(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def issuperset(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def union(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def iter_intersection(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def intersection(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def iter_difference(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def difference(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def symmetric_difference(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __or__ = ...
    __ror__ = ...
    __and__ = ...
    __rand__ = ...
    __sub__ = ...
    __xor__ = ...
    __rxor__ = ...

    def __rsub__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def update(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def intersection_update(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def difference_update(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def symmetric_difference_update(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ior__(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iand__(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __isub__(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ixor__(self, *others):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def iter_slice(self, start, stop, step=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, index):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pop(self, index=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def count(self, val):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def reverse(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def sort(self, **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def index(self, val):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def complement(wrapped):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _norm_args_typeerror(other):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _norm_args_notimplemented(other):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class _ComplementSet:
    __slots__ = ...

    def __init__(self, included=..., excluded=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def complemented(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __invert__ = ...

    def complement(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __contains__(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def remove(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pop(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def intersection(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __and__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __rand__ = ...

    def __iand__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def union(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __or__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __ror__ = ...

    def __ior__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def update(self, items):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def discard(self, items):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def symmetric_difference(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __xor__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    __rxor__ = ...

    def symmetric_difference_update(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def isdisjoint(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def issubset(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __le__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __lt__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def issuperset(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ge__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __gt__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def difference(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __sub__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __rsub__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def difference_update(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __isub__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __eq__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __hash__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __bool__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
