# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
READ_CHUNK_SIZE = ...

class SpooledIOBase:
    __metaclass__ = ...

    def __init__(self, max_size=..., dir=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _checkClosed(self, msg=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def read(self, n=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write(self, s):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def seek(self, pos, mode=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def readline(self, length=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def readlines(self, sizehint=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def writelines(self, lines):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def rollover(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def tell(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def buffer(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _rolled(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def len(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_softspace(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _set_softspace(self, val):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    softspace = ...

    def _file(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def close(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def flush(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def isatty(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def closed(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pos(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def buf(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def fileno(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def truncate(self, size=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def getvalue(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def seekable(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def readable(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def writable(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __next__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    next = ...

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __enter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __exit__(self, *args):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __eq__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ne__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __bool__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __del__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class SpooledBytesIO:

    def read(self, n=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write(self, s):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def seek(self, pos, mode=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def readline(self, length=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def readlines(self, sizehint=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def rollover(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _rolled(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def buffer(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def len(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def tell(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class SpooledStringIO:

    def __init__(self, *args, **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def read(self, n=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def write(self, s):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _traverse_codepoints(self, current_position, n):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def seek(self, pos, mode=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def readline(self, length=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def readlines(self, sizehint=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def buffer(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _rolled(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def rollover(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def tell(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def len(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def is_text_fileobj(fileobj):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class MultiFileReader:

    def __init__(self, *fileobjs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def read(self, amt=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def seek(self, offset, whence=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
