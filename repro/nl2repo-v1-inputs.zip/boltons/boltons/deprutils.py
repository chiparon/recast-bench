# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class DeprecatableModule:

    def __init__(self, module):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getattribute__(self, name):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def deprecate_module_member(mod_name, name, message):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
