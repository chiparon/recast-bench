# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
_MISSING = ...
_MISSING = ...
__all__ = ...

def to_text(obj, maxlen=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def escape_html(obj, maxlen=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_DNR = ...

class UnsupportedData:
    pass

class InputType:

    def __init__(self, *a, **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_entry_seq(self, data_seq, headers):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class DictInputType:

    def check_type(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def guess_headers(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_entry(self, obj, headers):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_entry_seq(self, obj, headers):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class ObjectInputType:

    def check_type(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def guess_headers(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_entry(self, obj, headers):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class ListInputType:

    def check_type(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def guess_headers(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_entry(self, obj, headers):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_entry_seq(self, obj_seq, headers):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TupleInputType:

    def check_type(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def guess_headers(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_entry(self, obj, headers):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_entry_seq(self, obj_seq, headers):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class NamedTupleInputType:

    def check_type(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def guess_headers(self, obj):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_entry(self, obj, headers):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_entry_seq(self, obj_seq, headers):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Table:
    _input_types = ...
    _html_tr = ...
    _html_tr_close = ...
    _html_th = ...
    _html_th_close = ...
    _html_td = ...
    _html_td_close = ...
    _html_thead = ...
    _html_thead_close = ...
    _html_tbody = ...
    _html_tbody_close = ...
    _html_table_tag = ...
    _html_table_tag_close = ...

    def __init__(self, data=..., headers=..., metadata=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def extend(self, data):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _set_width(self, reset=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _fill(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_dict(cls, data, headers=..., max_depth=..., metadata=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_list(cls, data, headers=..., max_depth=..., metadata=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_object(cls, data, headers=..., max_depth=..., metadata=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def from_data(cls, data, headers=..., max_depth=..., **kwargs):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, idx):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_html(self, orientation=..., wrapped=..., with_headers=..., with_newlines=..., with_metadata=..., max_depth=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_cell_html(self, value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _add_horizontal_html_lines(self, lines, headers, max_depth):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _add_vertical_html_lines(self, lines, headers, max_depth):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def to_text(self, with_headers=..., maxlen=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
