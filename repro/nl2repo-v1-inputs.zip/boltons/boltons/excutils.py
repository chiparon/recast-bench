# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
__all__ = ...

class ExceptionCauseMixin:
    cause = ...

    def __new__(cls, *args, **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_str(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_message(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_trace_str(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_exc_str(self, incl_name=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def _format_exc(exc, message=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_BaseTBItem = ...

class _TBItem:

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class _DeferredLine:

    def __init__(self, filename, lineno, module_globals=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __eq__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __ne__(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def strip(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def _extract_from_frame(f=..., limit=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _extract_from_tb(tb, limit=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class MathError:
    pass

def whoops_math():
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def math_lol(n=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def main():
    raise NotImplementedError('NL2Repo skeleton: implement this API')
