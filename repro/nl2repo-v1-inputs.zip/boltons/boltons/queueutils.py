# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
_REMOVED = ...
_REMOVED = ...
BList = ...
__all__ = ...

class BasePriorityQueue:
    _default_priority_key = ...
    _backend_type = ...

    def __init__(self, **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _push_entry(backend, entry):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _pop_entry(backend):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add(self, task, priority=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def remove(self, task):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _cull(self, raise_exc=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def peek(self, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def pop(self, default=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class HeapPriorityQueue:

    def _pop_entry(backend):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _push_entry(backend, entry):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class SortedPriorityQueue:
    _backend_type = ...

    def _pop_entry(backend):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _push_entry(backend, entry):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
PriorityQueue = ...
