# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

def gobs_program():
    raise NotImplementedError('NL2Repo skeleton: implement this API')
