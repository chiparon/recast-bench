# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
_UNSET = ...
_REMAP_EXIT = ...
_REMAP_EXIT = ...
_UNSET = ...

def is_iterable(obj):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def is_scalar(obj):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def is_collection(obj):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def split(src, sep=..., maxsplit=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def split_iter(src, sep=..., maxsplit=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def lstrip(iterable, strip_value=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def lstrip_iter(iterable, strip_value=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def rstrip(iterable, strip_value=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def rstrip_iter(iterable, strip_value=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def strip(iterable, strip_value=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def strip_iter(iterable, strip_value=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def chunked(src, size, count=..., **kw):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _validate_positive_int(value, name, strictly_positive=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def chunked_iter(src, size, **kw):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def chunk_ranges(input_size, chunk_size, input_offset=..., overlap_size=..., align=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def pairwise(src, end=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def pairwise_iter(src, end=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def windowed(src, size, fill=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def windowed_iter(src, size, fill=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def xfrange(stop, start=..., step=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def frange(stop, start=..., step=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def backoff(start, stop, count=..., factor=..., jitter=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def backoff_iter(start, stop, count=..., factor=..., jitter=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def bucketize(src, key=..., value_transform=..., key_filter=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def partition(src, key=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def unique(src, key=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def unique_iter(src, key=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def redundant(src, key=..., groups=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def one(src, default=..., key=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def first(iterable, default=..., key=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def flatten_iter(iterable):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def flatten(iterable):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def same(iterable, ref=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def default_visit(path, key, value):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
_orig_default_visit = ...

def default_enter(path, key, value):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def default_exit(path, key, old_parent, new_parent, new_items):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def remap(root, visit=..., enter=..., exit=..., **kwargs):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class PathAccessError:

    def __init__(self, exc, seg, path):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def get_path(root, path, default=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def research(root, query=..., reraise=..., enter=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

class GUIDerator:

    def __init__(self, size=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def reseed(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __next__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    next = ...

class SequentialGUIDerator:

    def reseed(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __next__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    next = ...
guid_iter = ...
seq_guid_iter = ...

def soft_sorted(iterable, first=..., last=..., key=..., reverse=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def untyped_sorted(iterable, key=..., reverse=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
