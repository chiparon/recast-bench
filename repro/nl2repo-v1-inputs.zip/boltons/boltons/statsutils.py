# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class _StatsProperty:

    def __init__(self, name, func):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __get__(self, obj, objtype=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Stats:

    def __init__(self, data, default=..., use_copy=..., is_sorted=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __len__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_sorted_data(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def clear_cache(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _calc_count(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    count = ...

    def _calc_mean(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    mean = ...

    def _calc_max(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    max = ...

    def _calc_min(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    min = ...

    def _calc_median(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    median = ...

    def _calc_iqr(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    iqr = ...

    def _calc_trimean(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    trimean = ...

    def _calc_variance(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    variance = ...

    def _calc_std_dev(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    std_dev = ...

    def _calc_median_abs_dev(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    median_abs_dev = ...
    mad = ...

    def _calc_rel_std_dev(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    rel_std_dev = ...

    def _calc_skewness(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    skewness = ...

    def _calc_kurtosis(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    kurtosis = ...

    def _calc_pearson_type(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
    pearson_type = ...

    def _get_quantile(sorted_data, q):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_quantile(self, q):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_zscore(self, value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def trim_relative(self, amount=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_pow_diffs(self, power):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_bin_bounds(self, count=..., with_max=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_histogram_counts(self, bins=..., **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def format_histogram(self, bins=..., **kw):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def describe(self, quantiles=..., format=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def describe(data, quantiles=..., format=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _get_conv_func(attr_name):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def format_histogram_counts(bin_counts, width=..., format_bin=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
