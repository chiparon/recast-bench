# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

def create_parser():
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def _error(msg):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def main(args=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
