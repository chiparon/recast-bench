# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
__version__ = ...
__all__ = ...

def parse(sql, encoding=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def parsestream(stream, encoding=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def format(sql, encoding=..., **options):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def split(sql, encoding=..., strip_semicolon=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
