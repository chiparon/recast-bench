# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class FilterStack:

    def __init__(self, strip_semicolon=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def enable_grouping(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def run(self, sql, encoding=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
