# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class StatementSplitter:

    def __init__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _reset(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _change_splitlevel(self, ttype, value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def process(self, stream):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
