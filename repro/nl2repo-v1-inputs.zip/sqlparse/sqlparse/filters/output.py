# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class OutputFilter:
    varname_prefix = ...

    def __init__(self, varname=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _process(self, stream, varname, has_nl):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def process(self, stmt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class OutputPythonFilter:

    def _process(self, stream, varname, has_nl):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class OutputPHPFilter:
    varname_prefix = ...

    def _process(self, stream, varname, has_nl):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
