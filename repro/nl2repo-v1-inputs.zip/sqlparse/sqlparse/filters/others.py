# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class StripCommentsFilter:

    def _process(tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def process(self, stmt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class StripWhitespaceFilter:

    def _stripws(self, tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _stripws_default(tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _stripws_identifierlist(self, tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _stripws_parenthesis(self, tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def process(self, stmt, depth=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class SpacesAroundOperatorsFilter:

    def _process(tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def process(self, stmt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class StripTrailingSemicolonFilter:

    def process(self, stmt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class SerializerUnicode:

    def process(stmt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
