# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class AlignedIndentFilter:
    join_words = ...
    by_words = ...
    split_words = ...

    def __init__(self, char=..., n=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def nl(self, offset=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _process_statement(self, tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _process_parenthesis(self, tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _process_identifierlist(self, tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _process_case(self, tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _next_token(self, tlist, idx=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _split_kwds(self, tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _process_default(self, tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _process(self, tlist):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def process(self, stmt):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
