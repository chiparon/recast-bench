# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class RightMarginFilter:
    keep_together = ...

    def __init__(self, width=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _process(self, group, stream):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def process(self, group):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
