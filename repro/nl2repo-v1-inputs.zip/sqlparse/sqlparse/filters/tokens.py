# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class _CaseFilter:
    ttype = ...

    def __init__(self, case=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def process(self, stream):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class KeywordCaseFilter:
    ttype = ...

class IdentifierCaseFilter:
    ttype = ...

    def process(self, stream):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TruncateStringFilter:

    def __init__(self, width, char):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def process(self, stream):
        raise NotImplementedError('NL2Repo skeleton: implement this API')
