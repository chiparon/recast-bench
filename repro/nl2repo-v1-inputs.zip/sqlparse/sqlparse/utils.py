# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations
SPLIT_REGEX = ...
LINE_MATCH = ...

def split_unquoted_newlines(stmt):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def remove_quotes(val):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def recurse(*cls):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def imt(token, i=..., m=..., t=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def consume(iterator, n):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def offset(filter_, n=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def indent(filter_, n=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
