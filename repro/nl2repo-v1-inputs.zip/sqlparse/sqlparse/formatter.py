# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

def validate_options(options):
    raise NotImplementedError('NL2Repo skeleton: implement this API')

def build_filter_stack(stack, options):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
