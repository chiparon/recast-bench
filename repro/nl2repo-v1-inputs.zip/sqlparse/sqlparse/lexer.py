# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class Lexer:
    _default_instance = ...
    _lock = ...

    def get_default_instance(cls):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def default_initialization(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def clear(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def set_SQL_REGEX(self, SQL_REGEX):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def add_keywords(self, keywords):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def is_keyword(self, value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_tokens(self, text, encoding=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

def tokenize(sql, encoding=...):
    raise NotImplementedError('NL2Repo skeleton: implement this API')
