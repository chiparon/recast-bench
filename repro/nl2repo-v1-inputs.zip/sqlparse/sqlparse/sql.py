# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class NameAliasMixin:

    def get_real_name(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_alias(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Token:
    __slots__ = ...

    def __init__(self, ttype, value):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __repr__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_repr_name(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_repr_value(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def flatten(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def match(self, ttype, values, regex=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def within(self, group_cls):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def is_child_of(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def has_ancestor(self, other):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TokenList:
    __slots__ = ...

    def __init__(self, tokens=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __str__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __iter__(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def __getitem__(self, item):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_repr_name(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _pprint_tree(self, max_depth=..., depth=..., f=..., _pre=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_token_at_offset(self, offset):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def flatten(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_sublists(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _groupable_tokens(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _token_matching(self, funcs, start=..., end=..., reverse=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def token_first(self, skip_ws=..., skip_cm=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def token_next_by(self, i=..., m=..., t=..., idx=..., end=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def token_not_matching(self, funcs, idx):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def token_matching(self, funcs, idx):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def token_prev(self, idx, skip_ws=..., skip_cm=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def token_next(self, idx, skip_ws=..., skip_cm=..., _reverse=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def token_index(self, token, start=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def group_tokens(self, grp_cls, start, end, include_end=..., extend=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def insert_before(self, where, token):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def insert_after(self, where, token, skip_ws=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def has_alias(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_alias(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_name(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_real_name(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_parent_name(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def _get_first_name(self, idx=..., reverse=..., keywords=..., real_name=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Statement:

    def get_type(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Identifier:

    def is_wildcard(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_typecast(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_ordering(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_array_indices(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class IdentifierList:

    def get_identifiers(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class TypedLiteral:
    M_OPEN = ...
    M_CLOSE = ...
    M_EXTEND = ...

class Parenthesis:
    M_OPEN = ...
    M_CLOSE = ...

    def _groupable_tokens(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class SquareBrackets:
    M_OPEN = ...
    M_CLOSE = ...

    def _groupable_tokens(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Assignment:
    pass

class If:
    M_OPEN = ...
    M_CLOSE = ...

class For:
    M_OPEN = ...
    M_CLOSE = ...

class Comparison:

    def left(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def right(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Comment:

    def is_multiline(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Where:
    M_OPEN = ...
    M_CLOSE = ...

class Over:
    M_OPEN = ...

class Having:
    M_OPEN = ...
    M_CLOSE = ...

class Case:
    M_OPEN = ...
    M_CLOSE = ...

    def get_cases(self, skip_ws=...):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Function:

    def get_parameters(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

    def get_window(self):
        raise NotImplementedError('NL2Repo skeleton: implement this API')

class Begin:
    M_OPEN = ...
    M_CLOSE = ...

class Operation:
    pass

class Values:
    pass

class Command:
    pass
