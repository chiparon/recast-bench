# Declaration skeleton. Reconstruct imports, inheritance, constants and behavior.
from __future__ import annotations

class SQLParseError:
    pass
