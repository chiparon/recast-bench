# Common NL2Repo requirements

The complete sanitized upstream specification is split in order below. Read the introduction and the sections relevant to the module you are implementing. Every part is available to both methods.

- [requirements/part-01.md](requirements/part-01.md)
- [requirements/part-02.md](requirements/part-02.md)
- [requirements/part-03.md](requirements/part-03.md)
- [requirements/part-04.md](requirements/part-04.md)
- [requirements/part-05.md](requirements/part-05.md)
